#pragma once
#include"Vendedor.h"
#include"Venta.h"
#include"fecha.h"


class ArchivoVenta{
  private:
      char nombreRuta[30];
      int tamanioRegistro;

  public:
      ArchivoVenta(); ///"archivoVenta.dat"

      bool VerificarDuplicado(const char*); /// LO USA LA FUNCION AGREGAR REGISTRO
      void AgregarRegistroModificado(Venta&); /// LO USA LA FUNCION MENU MODIFICAR VENDEDOR
      bool BuscarVentaporID(int, Vendedor&); /// Funcion para corroborar si existe, LO USA LA FUNCION MOSTRAR VENDEDOR X LEGAJO
      int ObtainNewID();
      int CantidadRegistros();

      void AgregarRegistro(Venta); /// OPCION 1
      bool BajaLogica(int); /// OPCION 2
      void MenuModificarVenta(int); /// OPCION 3
      bool ListarRegistros(); /// OPCION 4
      void ListarPorAnio(Fecha); /// OPCION 5
      void RecaudacionTotalPorAnio(Fecha); /// OPCION 6

};
