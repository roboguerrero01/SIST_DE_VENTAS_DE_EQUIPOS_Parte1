#pragma once

class Fecha {
  private:
      int Dia;
      int Mes;
      int Anio;

  public:
      Fecha();
      Fecha(int, int, int);

      int GetDia();
      int GetMes();
      int GetAnio();

      bool SetDia(int);
      bool SetMes(int);
      bool SetAnio(int);

      void Cargar();
      void Mostrar();
      void CargarConFechaDeHoy();


};

