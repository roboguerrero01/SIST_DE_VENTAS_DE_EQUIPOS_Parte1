#pragma once
#include "Vendedor.h"
#include "equipo.h"

class ArchivoVendedor{
  private:
      char nombreRuta[30];
      int tamanioRegistro;

  public:
      ArchivoVendedor();

      bool VerificarDuplicado(const char*); /// LO USA LA FUNCION AGREGAR REGISTRO
      void AgregarRegistroModificado(Vendedor&); /// LO USA LA FUNCION MENU MODIFICAR VENDEDOR
      bool BuscarVendedorporLegajo(int, Vendedor&); /// Funcion para corroborar si existe, LO USA LA FUNCION MOSTRAR VENDEDOR X LEGAJO
      int ObtainNewLegajo();
      int CantidadRegistros();

      void AgregarRegistro(); /// OPCION 1
      bool BajaLogica(int); /// OPCION 2
      bool MenuModificarVendedor(int); /// OPCION 3
      bool ListarRegistros(); /// OPCION 4
      bool ListarPorLegajo(int); /// OPCION 5
      void VendedorMasRecaudo(); /// OPCION 6
      void VendedorMasVendioUnEquipo(int, Equipo); /// OPCION 7


};
