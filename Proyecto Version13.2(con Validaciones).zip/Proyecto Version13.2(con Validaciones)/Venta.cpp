#include<iostream>
#include"Venta.h"

using namespace std;

Venta::Venta(){}

void Venta::setEstado(bool _Estado){ Estado = _Estado; }
void Venta::setFechadeVenta(Fecha _FechaDeVenta){ FechaDeVenta = _FechaDeVenta;}

bool Venta::getEstado(){ return Estado; }
Fecha Venta::getFechadeVenta(){ return FechaDeVenta; }

bool Venta::Cargar(int id){
    bool exit = false;
    int caso = -1;

    DetalleDeVentas detalle;
    ArchivoEquipo equipo;
    int idEquipo = -1;

    FechaDeVenta.Cargar();

    IdVenta = id;
    cout << "ID: " << IdVenta << endl;

    cout << "Quiere cargar detalles de venta? [ 0 - Parar, 1 - Seguir, 2 - Cancelar Venta]" << endl;
    cin >> caso;
    while(!exit){
        switch(caso){
        case 0:
            exit = true;
            break;
        case 1:
//Pedir id de equipo
            while(!equipo.VerificarDuplicado(idEquipo)){
                cout << "Ingrese el id del equipo que desea adquirir" << endl;
                cin >> idEquipo;
                if (equipo.VerificarDuplicado(idEquipo)) {
                    cout << "Error: el id no esta vinculado a ningun equipo" << endl;
                }
            }
            detalle.Cargar(IdVenta, idEquipo);

            break;
        case 2:
////Cancelar Venta
            detalle.CancelarDetallesDeVenta(IdVenta);
            cout << "Venta cancelada exitosamente" << endl;
            Estado = false;
            return false;
            break;
        default:
            cout << "Error: Ingrese una opcion valida. " << endl;
            break;
        }

        if (!exit){
            cout << "Quiere seguir cargando detalles de venta? [ 0 - Parar, 1 - Seguir]" << endl;
            cin >> caso;
        }
    }

    Estado = true;

    cout << "Estado: Activo por default " << endl;

    return true;
}
void Venta::Mostrar(){
    cout << "\n--- Datos de la Venta ---" << endl;
    cout << IdVenta << endl;
    cout << "Fecha de Venta: ";
    FechaDeVenta.Mostrar();

    if (Estado){ cout << "Estado: Activo" << endl; }
    else { cout << "Estado: Inactivo" << endl; }
}


