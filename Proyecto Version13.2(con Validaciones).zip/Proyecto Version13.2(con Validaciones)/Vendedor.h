#pragma once
#include "personas.h"
#include "fecha.h"

class Vendedor : public Persona{
  private:
      Fecha FechaDeIngreso;
      float Sueldo;

  public:
      Vendedor();

      void setIngreso(Fecha);
      void setSueldo();

      Fecha getIngreso();
      float getSueldo();

      void Cargar();
      void Mostrar();
};

