#include"Vendedor.h"
# include<iostream>
using namespace std;

Vendedor::Vendedor(){}
