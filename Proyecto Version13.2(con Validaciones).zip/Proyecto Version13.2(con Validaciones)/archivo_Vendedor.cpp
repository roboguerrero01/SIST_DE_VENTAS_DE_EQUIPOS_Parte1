#include"archivo_Vendedor.h"
#include<iostream>
#include <cstring>
using namespace std;

ArchivoVendedor::ArchivoVendedor(){
    strcpy(nombreRuta, "archivoVendedor.dat");
    tamanioRegistro = sizeof(Vendedor);
}
