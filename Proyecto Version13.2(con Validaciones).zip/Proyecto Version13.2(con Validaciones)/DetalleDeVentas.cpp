#include<iostream>
#include"DetalleDeVentas.h"
#include"archivo_equipo.h"
#include"equipo.h"
#include"archivo_Venta.h"
using namespace std;

DetalleDeVentas::DetalleDeVentas(){ }

void DetalleDeVentas::setIdDetalleDeVenta(int){}
void DetalleDeVentas::setCantidad(int){}
void DetalleDeVentas::setPrecioUnitario(float){}

int DetalleDeVentas::getIdDetalleDeVenta(){ return IdDetalleDeVenta; }
int DetalleDeVentas::getIdVenta(){ return IdVenta; }
int DetalleDeVentas::getIdEquipo(){ return IdEquipo; }
int DetalleDeVentas::getCantidad(){ return Cantidad; }
float DetalleDeVentas::getPrecioUnitario(){ return PrecioUnitario; }

void DetalleDeVentas::Mostrar(){}
bool DetalleDeVentas::Cargar(int idVenta, int idEquipo){
    bool confirmarCompra = false;

    ArchivoEquipo gestorEquipo;
    Equipo equipo;
    gestorEquipo.BuscarPosicionPorId(idEquipo, equipo);

    IdVenta = idVenta;
    IdEquipo = idEquipo;

////Reviso que haya stock disponible
    if (equipo.getStock() == 0){
        cout << "Error: No hay Stock disponible" << endl;
        system("pause");
        return false;
    }

    PrecioUnitario = equipo.getPrecio();
    cout << "Precio Unitario: " << PrecioUnitario << endl;

////Pido Cantidad a comprar
    do{
        if (Cantidad <= equipo.getStock()){ cout << "Error: Stock insuficiente, Elija una cantidad disponible"; }
        cout << "Unidades disponibles: " << equipo.getStock() << endl;
        cout << "Cuantas unidades desea comprar? " << endl;
        cin >> Cantidad;

    } while (Cantidad <= equipo.getStock());

    cout << "Precio Total: $" << Cantidad * PrecioUnitario << endl;

////Muestro coste total del detalle de venta y pregunto si se arrepienten
    do {
        if (cin.fail()){ cout << "Error: Ingrese un valor valido." << endl; }

        cin.clear();
        cin.ignore(10000, '\n');

        cout << "Desea confirmar el detalle de venta? [ 0 - Cancelar, 1 - Aceptar] " << endl;
        cin >> confirmarCompra;

    } while (cin.fail());

    if (!confirmarCompra){
        cout << "Detalle de venta cancelado exitosamente. " << endl;
        return false;
    }

////Guardo los cambios realizados
    equipo.setStock(equipo.getStock() - Cantidad);
    gestorEquipo.AgregarRegistroModificado(equipo);
    GuardarEnArchivo();

    return true;
} /// RECIBE EL ID DE LA VENTA Y EL ID DEL EQUIPO

void DetalleDeVentas::GuardarEnArchivo(){
    const char* ruta = "DetalleDeVentas.dat";
    int tamanioRegistro = sizeof(DetalleDeVentas);

    FILE *p;
    p = fopen(ruta, "ab");

    if (p == nullptr){
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    fwrite(this, tamanioRegistro, 1, p);

    fclose(p);
}

void DetalleDeVentas::DevolverStock(int idVenta){
    ArchivoEquipo GestorEquipo;
    Equipo equipo;
    DetalleDeVentas obj;
    const char* ruta = "DetalleDeVentas.dat";
    int tamanioRegistro = sizeof(DetalleDeVentas);

    FILE *p;
    p = fopen(ruta, "rb");

    if (p == nullptr){
        cout<<"no hay detalles de venta cargado"<<endl;
        system("pause");
        return;
    }

    while(fread(&obj, tamanioRegistro, 1, p)){
        if (idVenta = obj.getIdVenta()){
            GestorEquipo.BuscarPosicionPorId(obj.getIdEquipo(), equipo);
            equipo.setStock(equipo.getStock() + obj.getCantidad());
        }
    }

    fclose(p);

}
// "DetalleDeVentas.dat"
// "DetalleDeVentasCopia.dat"

void DetalleDeVentas::CopiaDeSeguridad(){
    DetalleDeVentas obj;
    int peso = sizeof(DetalleDeVentas);

    FILE *pDTV;
    FILE *pDTVC;

    pDTV = fopen("DetalleDeVentas.dat", "rb"); /// Original lee
    pDTVC = fopen("DetalleDeVentasCopia.dat", "ab"); /// Copia escribe
    if (pDTV == nullptr) { exit(1); }
    if (pDTVC == nullptr) { exit(1); }

    fseek(pDTVC, 0, SEEK_CUR);

    while(fread(&obj, peso, 1, pDTV)){
        fwrite(&obj, peso, 1, pDTVC);
    }

    fclose(pDTV);
    fclose(pDTVC);
}
void DetalleDeVentas::CargarCopiaDeSeguridad(){
    DetalleDeVentas obj;
    int peso = sizeof(DetalleDeVentas);

    FILE *pDTVC;
    FILE *pDTV;

    pDTVC = fopen("DetalleDeVentasCopia.dat", "rb"); /// Copia lee
    pDTV = fopen("DetalleDeVentas.dat", "wb"); /// Original escribe
    if (pDTVC == nullptr) { exit(1); }
    if (pDTV == nullptr) { exit(1); }

    fseek(pDTV, 0, SEEK_CUR);

    while(fread(&obj, peso, 1, pDTVC)){
        fwrite(&obj, peso, 1, pDTV);
    }

    fclose(pDTVC);
    fclose(pDTV);
}

void DetalleDeVentas::CancelarDetallesDeVenta(int idVenta){
    DevolverStock(idVenta);
    CopiaDeSeguridad();
    CargarCopiaDeSeguridad();
}
