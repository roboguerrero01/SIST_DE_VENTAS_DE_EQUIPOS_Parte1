#include"archivo_Venta.h"
#include<iostream>
#include<cstring>
using namespace std;

ArchivoVenta::ArchivoVenta(){
    strcpy(nombreRuta, "archivoVenta.dat");
    tamanioRegistro = sizeof(Venta);
}

int ArchivoVenta::ObtainNewID(){
    return CantidadRegistros() + 1;
}

int ArchivoVenta::CantidadRegistros(){
    FILE *p;
    p = fopen(nombreRuta, "rb");
    int cantidad;
    if(p==nullptr)
    {
        return 0;
    }
    fseek(p,0,SEEK_END);
    cantidad=ftell(p) / tamanioRegistro;
    fclose(p);
    return cantidad;
}

bool ArchivoVenta::VerificarDuplicado(const char*){}
void ArchivoVenta::AgregarRegistroModificado(Venta&){}
bool ArchivoVenta::BuscarVentaporID(int, Vendedor&){}

void ArchivoVenta::AgregarRegistro(Venta){
//
// Aca se sube a archivo
//
}
bool ArchivoVenta::BajaLogica(int){}
void ArchivoVenta::MenuModificarVenta(int){}
bool ArchivoVenta::ListarRegistros(){}
void ArchivoVenta::ListarPorAnio(Fecha){}
void ArchivoVenta::RecaudacionTotalPorAnio(Fecha){}
