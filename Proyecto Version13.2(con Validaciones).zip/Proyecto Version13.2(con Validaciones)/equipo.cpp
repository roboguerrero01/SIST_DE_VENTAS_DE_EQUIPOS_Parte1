#include "equipo.h"
# include <cstring>
# include<iostream>
using namespace std;

using namespace std;
//NOTAS: agrege otra opcion de dise�o en Equipo::Mostrar y Equipo::Cargar

// Constructor
Equipo::Equipo() {
    IdEquipo = 0;
    strcpy(Marca, "");
    Tipo=-1;
    Stock = 0;
    Precio = 0.0;
    Estado = false;
}

// SETTERS
void Equipo::setIdEquipo(int _idEquipo) {
    IdEquipo = _idEquipo;
}

void Equipo::setMarca(const char* _marca) {
    strcpy(Marca, _marca);
}

void Equipo::setTipo(int _tipo) {
    Tipo=_tipo;
}

void Equipo::setStock(int _stock) {
    Stock = _stock;
}

void Equipo::setPrecio(float _precio) {
    Precio = _precio;
}

void Equipo::setEstado(bool _estado) {
    Estado = _estado;
}

// GETTERS
int Equipo::getIdEquipo() {
    return IdEquipo;
}

char* Equipo::getMarca() {
    return Marca;
}

int Equipo::getTipo() {
    return Tipo;
}

int Equipo::getStock() {
    return Stock;
}

float Equipo::getPrecio() {
    return Precio;
}

bool Equipo::getEstado() {
    return Estado;
}

// METODOS
bool Equipo::Cargar(int id) {
    cout << "Ingrese los datos del equipo" << endl;
    cout << "----------------------------" << endl;

    do{
        cin.clear();
        cin.ignore(10000, '\n');
        cout << "Tipo de equipo: ";
        cin >> Tipo;

        if (cin.fail()) { cout << "Error de ingreso, intentelo nuevamente e ingrese un valor numerico" << '\n'; }
        else if (Tipo <= 0) { cout << "Error de ingreso, ingrese un valor positivo" << '\n'; }
    } while(cin.fail() || Tipo <= 0);

    cin.ignore();
    cout << "Marca: ";
    cin.getline(Marca, 30);

    do{
        cin.clear();
        cin.ignore(10000, '\n');
        cout << "Precio: $";
        cin >> Precio;

        if (cin.fail()) { cout << "Error de ingreso, intentelo nuevamente e ingrese un valor numerico" << '\n'; }
        else if (Precio < 0) { cout << "Error de ingreso, ingrese un valor positivo" << '\n'; }
    } while(cin.fail() || Precio <= 0);

    do{
        cin.clear();
        cin.ignore(10000, '\n');

        cout << "Stock: ";
        cin >> Stock;

        if (cin.fail()) { cout << "Error de ingreso, intentelo nuevamente e ingrese un valor numerico" << '\n'; }
        else if (Stock < 0) { cout << "Error de ingreso, ingrese un valor positivo" << '\n'; }
    } while(cin.fail() || Stock < 0);

    Estado = true;
    cout<< "Su estado es: activo por default"<<endl;

    IdEquipo = id;
    cout<<endl;

    cout<<"El ID correspondiente al equipo es: "<<IdEquipo<<endl;

    return true;
}

void Equipo::Mostrar(){
    /*
    cout << " ------------- EQUIPO ------------- " << '\n';
    cout << " - ID: " << getIdEquipo() << '\n';
    cout << " - Tipo: " << getTipo() << '\n';
    cout << " - Marca: " << getMarca() << '\n';
    cout << " - Stock: " << getStock() << '\n';
    cout << " - Precio: $" << getPrecio() << '\n';
    cout << " - Estado: " << getEstado() << '\n' << '\n';
    cout << " ---------------------------------- " << '\n';
    */
    // dise�o 2 x si quieren probar algo distinto...
    cout << " EQUIPO [ID " << getIdEquipo() << " ]" << "            [Estado " << getEstado() << " ]" << endl;
    cout << "-------------------------------------- " << endl;
    cout << " Marca: " << getMarca() << endl;
    cout << " Tipo: " << getTipo() << "         |   " << "Stock: " << getStock() <<endl;
    cout << " Precio: $" << getPrecio() <<endl;
    cout << "-------------------------------------- " << endl << endl;
}
