#pragma once
#include "Fecha.h"
#include"DetalleDeVentas.h"
#include"archivo_equipo.h"


class Venta{
  private:
      int IdVenta;
      bool Estado;
      Fecha FechaDeVenta;

  public:
      Venta();

      void setEstado(bool);
      void setFechadeVenta(Fecha);

      bool getEstado();
      Fecha getFechadeVenta();

      bool Cargar(int);
      void Mostrar();
};
