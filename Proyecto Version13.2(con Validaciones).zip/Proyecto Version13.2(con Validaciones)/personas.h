#pragma once
#include "fecha.h"

class Persona{
  private:
      char Nombres[50];
      char Apellidos[50];
      char Dni[9];
      Fecha FechaNac;
      char Telefono[20];
      char Email[50];
      char Direccion[50];
      bool Estado;// 1-alta / 0-baja

  public:
      //CONSTRUCTORES
      Persona();
      Persona(const char*, const char*, const char*, Fecha, const char*, const char*, const char*, bool);

      // SETTERS
      void setNombres(const char*);
      void setApellidos(const char*);
      void SetFecha(Fecha);
      void setTelefono(const char*);
      void setEmail(const char*);
      void setDireccion(const char*);
      void setEstado(bool);
      void setDni(const char*);

      // GETTERS
      const char* getNombres();
      const char* getApellidos();
      Fecha GetFechaNac();
      const char* getTelefono();
      const char* getEmail();
      const char* getDireccion();
      bool getEstado();
      const char* getDni();

      //METODOS
      void Mostrar();
      void Cargar();
};
