#include <iostream>
#include "menues.h"

/*  Lean las NOTAS...

    chicos creo que realize la mayoria de las validaciones. jaja

    igual por las dudas les dejo los modelos de validaciones para cada caso posible:
    (en algunos casos, ejemplo: ingreso de cuit y tiene un if para no registrar el cuit repetido,
    en lugar de los break use un booleano para mantener el do while en ronda).

    me falto lo que es Venta.cpp y Vendedor.cpp

    ojo que algunos ENTER estan demas pero no pude encontrarlos ...!!!

    - VALIDACION DE ENTRADA DE UNA VARIABLE: ///////////////////////////////////////

    int numero;
    bool incorrecto = false;

    do{

        incorrecto = false;

        cout<<"Ingrese un numero: ";
        cin >> numero;

        if (cin.fail())
        {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "ERROR, ingrese valor numerico." << endl; //escriban el mensaje que quieran
            incorrecto = true;
        }

    }while(incorrecto);

    - VALIDACION DE ENTRADA DE UNA CADENA  (solo debe aceptar numeros)//////////////////
    char numero[20];
    bool errorDeIngreso = false;

    do{

        errorDeIngreso = false;

        cout << "Ingresa cadena: ";
        cin.getline(numero,21);

        for(int i=0; numero[i] != '\0'; i++)
        {
            // si no esta en el rango de numeros en ASCII.
            if(!((int)numero[i] < 58 && (int)numero[i] > 47))
            {
                errorDeIngreso = true;
            }
        }

        if (errorDeIngreso)
        {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "ERRROR, ingrese un valor numerico..." << endl;
        }

    }while(errorDeIngreso);

    - VALIDACION DE ENTRADA DE UNA CADENA  (no debe permirtir simbolos)//////////////////
    char Direccion[20];
    bool errorDeIngreso = false;

    do{
        errorDeIngreso = false;

        cout << "Ingresa Direccion: ";
        cin.getline(Direccion, 21);

        for(int i=0; Direccion[i] != '\0'; i++)
        {
            // si no esta en el rango de mayusculas, minusculas, numeros  o espacio en ASCII.
            if(!(Direccion[i]>64 && Direccion[i]<91 || Direccion[i]>96 && Direccion[i]<123 || (int)Direccion[i] > 47 && (int)Direccion[i] < 58 || Direccion[i] == 32))
            {
                errorDeIngreso = true;
            }
        }
        if (errorDeIngreso)
        {
            cout << "Error de ingreso. PRESIONE ENTER" << '\n';
            cin.clear();
            cin.ignore(10000,'\n');
        }
    }while(errorDeIngreso);


    - VALIDACION DE ENTRADA DE UNA CADENA  (solo acepta letras)//////////////////
    char nombre[20];
    bool erroDeIngreso = false;


    do{
        errorDeIngreso = false;

        cout << "Ingresa nombre: ";
        cin.getline(nombre, 21);

        for(int i=0; nombre[i] != '\0'; i++)
        {
            // si no esta en el rango de mayusculas o minusculass en ASCII.
            if(!(nombre[i]>64 && nombre[i]<91 || nombre[i]>96 && nombre[i]<123))
            {
                errorDeIngreso = true;
            }
        }
        if (errorDeIngreso)
        {
            cout << "Error de ingreso. PRESIONE ENTER" << '\n';
            cin.clear();
            cin.ignore(10000,'\n');
        }
    }while(errorDeIngreso);



*/

using namespace std;

void menuGeneral(){//revisado
    int opcion;
    do
    {
        system("cls");
        cout << " --------------------------------------------------------- " << endl;
        cout << "|        BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS        |" << endl;
        cout << "|        =====         MENU GENERAL          =====        |" << endl;
        cout << " --------------------------------------------------------- " << endl;
        cout << "|                                                         |" << endl;
        cout << "|            1- Menu CLIENTES FISICOS/JURIDICOS.          |" << endl;
        cout << "|            2- Menu EQUIPOS.                             |" << endl;
        cout << "|            3- Menu VENDEDORES.                          |" << endl;
        cout << "|            4- Menu de VENTAS.                           |" << endl;
        cout << "|                                                         |" << endl;
        cout << "|            0- SALIR DEL PROGRAMA.                       |" << endl;
        cout << "|                                                         |" << endl;
        cout << " --------------------------------------------------------- " << endl;
        cout << endl << "              Ingrese Opcion: ";
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion=-1;
        }

        bool salirMenuClientes = false;
        int OpcionMenuClientes;
        switch(opcion){
            case 1:
                while (!salirMenuClientes)
                {
                    system("cls");
                    cout << " ----------------------------------- " << endl;
                    cout << "|      Elige el Tipo de Cliente:    |" << endl;
                    cout << " ----------------------------------- " << endl;
                    cout << "|                                   |" << endl;
                    cout << "|           1 - FISICO.             |" << endl;
                    cout << "|           2 - JURIDICO.           |" << endl;
                    cout << "|                                   |" << endl;
                    cout << "|           0 - VOLVER.             |" << endl;
                    cout << "|                                   |" << endl;
                    cout << " ----------------------------------- " << endl;
                    cout << endl << "           opcion elegida: ";
                    cin >> OpcionMenuClientes;
                    cout << endl;
                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        OpcionMenuClientes = -1;
                    }

                    switch(OpcionMenuClientes)
                    {
                        case 1:
                            subMenuClientesFisicos();
                        break;

                        case 2:
                            subMenuClientesJuridicos();
                        break;

                        case 0:
                            salirMenuClientes = true;
                        break;

                        default:
                            cout << "Elija una opcion valida" << '\n';
                            system("pause");
                        break;
                    }
                }
                system("pause");
            break;

            case 2:
                subMenuEquipo();
                system("pause");
            break;

            case 3:
                subMenuVendedor();
                system("pause");
            break;

            case 4:
                subMenuVentas();
                system("pause");
            break;

            case 0:
                cout << "Saliendo del Programa, Vuelva Prontos." << endl;
                system("pause");
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);

}

void subMenuEquipo(){//revisado
    int opcion;
    int tipo;
    ArchivoEquipo obj;
    Equipo equi;
    bool incorrecto = false;
    do
    {
        int id=-1;
        system("cls");
        cout << " ---------------------------------------------------------- " << endl;
        cout << "|         BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS        |" << endl;
        cout << "|         =====        MENU DE EQUIPOS        =====        |" << endl;
        cout << " ---------------------------------------------------------- " << endl;
        cout << "|                                                          |" << endl;
        cout << "|                1- ALTA                                   |" << endl;
        cout << "|                2- BAJA                                   |" << endl;
        cout << "|                3- MODIFICAR                              |" << endl;
        cout << "|                4- LISTAR TODOS ACTIVOS/INACTIVOS         |" << endl;
        cout << "|                5- LISTAR POR ID                          |" << endl;
        cout << "|                6- LISTAR POR TIPO                        |" << endl;
        cout << "|                7- EQUIPOS MAS VENDIDOS                   |" << endl;
        cout << "|                8- EQUIPOS NO VENDIDOS                    |" << endl;
        cout << "|                                                          |" << endl;
        cout << "|                0- VOLVER AL MENU GENERAL.                |" << endl;
        cout << "|                                                          |" << endl;
        cout << " ---------------------------------------------------------- " << endl;
        cout << endl << "                   Ingrese Opcion: ";
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion = -1;
        }
        switch(opcion){

            case 1:
                system("cls");
                equi.Cargar(obj.ObtainNewID());
                obj.AgregarRegistro(equi);
                system("pause");
            break;

            case 2:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa id a dar de baja: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.BajaLogica(id);
                system("pause");
            break;

            case 3:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa id a modificar: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.MenuModificarEquipo(id);
                system("pause");
            break;

            case 4:
                system("cls");
                obj.ListarRegistros();
                system("pause");
                break;

            case 5:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa el id a buscar: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.ListarPorID(id);
                system("pause");
            break;

            case 6:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa el tipo a buscar: ";
                    cin >> tipo;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.ListarPorTipo(tipo);
                system("pause");
            break;

            case 7:
                system("cls");
                obj.RankingdeEquiposMasVendidos();
                system("pause");
                break;

            case 8:
                system("cls");
                obj.EquiposNoVendidos();
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL...." << endl;
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);

}

void subMenuClientesFisicos(){//revisado
    char cuil[20];
    int opcion;
    ArchivoClienteFisico archi;
    ClienteFisico comprador;
    bool incorrecto = false;
    do
    {   int id=-1;
        system("cls");
        cout << " -------------------------------------------------------------- " << endl;
        cout << "|           BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS          |" << endl;
        cout << "|           =====    MENU DE CLIENTES FISICO    =====          |" << endl;
        cout << " -------------------------------------------------------------- " << endl;
        cout << "|                                                              |" << endl;
        cout << "|            1- ALTA                                           |" << endl;
        cout << "|            2- BAJA LOGICA                                    |" << endl;
        cout << "|            3- MODIFICAR                                      |" << endl;
        cout << "|            4- LISTAR TODOS LOS REGISTROS ACTIVOS/INACTIVOS   |" << endl;
        cout << "|            5- MOSTRAR REGISTRO POR ID                        |" << endl;
        cout << "|            6- BUSCAR REGISTRO POR CUIL                       |" << endl;
        cout << "|            7- CLIENTE QUE MAS GASTO                          |" << endl;
        cout << "|                                                              |" << endl;
        cout << "|            0- VOLVER AL MENU GENERAL.                        |" << endl;
        cout << "|                                                              |" << endl;
        cout << " -------------------------------------------------------------- " << endl;
        cout << endl <<"                  Ingrese Opcion: ";
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion=-1;
        }
        switch(opcion){
            case 1:
                system("cls");
                cout << "\n--- Cargando datos del cliente fisico ---" << endl;
                cin.ignore();
                do{
                    incorrecto = false;

                    cout << "Ingrese su CUIL: ";
                    cin >> cuil;

                    for(int i=0; cuil[i] != '\0'; i++)
                    {
                        if(!((int)cuil[i] < 58 && (int)cuil[i] > 47))
                        {
                            incorrecto = true;
                        }
                    }

                    if (archi.CantidadRegistros()){
                        if (archi.VerificarDuplicado(cuil)) {
                            cout << "Ya existe el usuario." << endl;
                            incorrecto = true;
                        }
                    }

                    if (incorrecto)
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                    }

                }while(incorrecto);

                if(comprador.Cargar(cuil, archi.ObtainNewID())){
                    archi.AgregarRegistro(comprador);
                }
                system("pause");
            break;

            case 2:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingrese ID del perfil a dar De Baja: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                archi.BajaLogica(id);
                system("pause");
            break;

            case 3:
                system("cls");
                cin.ignore();

                do{

                    incorrecto = false;

                    cout<<"Ingrese ID de perfil a modificar: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                archi.MenuModificarClienteFisico(id);
                system("pause");
            break;

            case 4:
                system("cls");
                if (!archi.ListarRegistros()){
                    cout << "Archivo vacio." << '\n';
                }
                system("pause");
            break;

            case 5:
                system("cls");
                int id;

                do{

                    incorrecto = false;

                    cout<<"ingrese id: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "opcion incorrecta, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                cin.ignore();
                archi.MostrarClientePorID(id);
                system("pause");
            break;

            case 6:
                system("cls");
                char cuil[20];

                do{
                    incorrecto = false;

                    cout<<"ingrese CUIL para buscar: ";
                    cin.getline(cuil,20);

                    for(int i=0; cuil[i] != '\0'; i++)
                    {
                        if(!((int)cuil[i] < 58 && (int)cuil[i] > 47))
                        {
                            incorrecto = true;
                        }
                    }

                    if (incorrecto)
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "opcion incorrecta, ingrese un valor numerico..." << endl;

                    }

                }while(incorrecto);

                cin.ignore();
                archi.MostrarClientePorCUIL(cuil);
                system("pause");
            break;

            case 7:
                system("cls");
                archi.ClientequeMasGasto();
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL..." << endl;
                system("pause");
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);
}

void subMenuClientesJuridicos(){//revisado
    int opcion;
    ArchivoClienteJuridico archi;
    ClienteJuridico comprador;
    char cuit[20];
    bool incorrecto = false;
    do
    {   int id=-1;
        system("cls");
        cout << " ------------------------------------------------------------------- " << endl;
        cout << "|              BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS            |" << endl;
        cout << "|              =====   MENU DE CLIENTES JURIDICO   =====            |" << endl;
        cout << " ------------------------------------------------------------------- " << endl;
        cout << "|                                                                   |" << endl;
        cout << "|              1- ALTA                                              |" << endl;
        cout << "|              2- BAJA LOGICA                                       |" << endl;
        cout << "|              3- MODIFICAR                                         |" << endl;
        cout << "|              4- LISTAR TODOS LOS REGISTROS ACTIVOS/INACTIVOS      |" << endl;
        cout << "|              5- MOSTRAR REGISTRO POR ID                           |" << endl;
        cout << "|              6- BUSCAR REGISTRO POR CUIT                          |" << endl;
        cout << "|              7- CLIENTE QUE MAS GASTO                             |" << endl;
        cout << "|                                                                   |" << endl;
        cout << "|              0- VOLVER AL MENU GENERAL.                           |" << endl;
        cout << "|                                                                   |" << endl;
        cout << " ------------------------------------------------------------------- " << endl;
        cout << endl << "                   Ingrese Opcion: " << endl;
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion=-1;
        }
        switch(opcion)
        {
            case 1:
                system("cls");

                cin.ignore();

                do{

                    incorrecto = false;

                    cout << "Ingresa Cuit: ";
                    cin >> cuit;

                    for(int i=0; cuit[i] != '\0'; i++)
                    {
                        if(!((int)cuit[i] < 58 && (int)cuit[i] > 47))
                        {
                            incorrecto = true;
                        }
                    }


                    if (archi.CantidadRegistros()){
                        if (archi.VerificarDuplicado(cuit)) {
                            cout << "Ya existe el usuario." << endl;
                            incorrecto = true;
                        }
                    }
                    if (incorrecto)
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERRROR, ingrese un valor numerico..." << endl;
                    }

                }while(incorrecto);

                if(comprador.Cargar(cuit, archi.ObtainNewID())){
                    archi.AgregarRegistro(comprador);
                }

                system("pause");
            break;

            case 2:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingrese ID del perfil a dar De Baja: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                archi.BajaLogica(id);
                system("pause");
            break;

            case 3:
                system("cls");

                cin.ignore();

                do{

                    incorrecto = false;

                    cout<<"Ingrese ID del cliente a modificar: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                archi.MenuModificarClienteJuridico(id);
                system("pause");
            break;

            case 4:
                system("cls");
                if (!archi.ListarRegistros())
                {
                    cout << "Archivo vacio." << '\n';
                }
                system("pause");
                break;

            case 5:
                system("cls");

                do{

                    incorrecto = false;

                    cout << "Ingrese id a buscar: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                cin.ignore();
                archi.MostrarClientePorID(id);
                system("pause");
            break;

            case 6:
                system("cls");
                char cuit[20];

                do{

                    incorrecto = false;

                    cout<<"ingrese CUIT para buscar: ";
                    cin.getline(cuit,20);

                    for(int i=0; cuit[i] != '\0'; i++)
                    {
                        if(!((int)cuit[i] < 58 && (int)cuit[i] > 47))
                        {
                            incorrecto = true;
                        }
                    }

                    if (incorrecto)
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;

                    }

                }while(incorrecto);

                cin.ignore();
                archi.MostrarClientePorCUIT(cuit);
                system("pause");
            break;

            case 7:
                system("cls");
                archi.ClientequeMasGasto();
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL..." << endl;
                system("pause");
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);
}

void subMenuVendedor(){//revisado
 int opcion;
 Vendedor vendedorcito;
 ///ArchivoVendedor obj;
 bool incorrecto = false;
 do{
        int legajo=-1;
        system("cls");
        cout << " -------------------------------------------------------------- " << endl;
        cout << "|          BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS           |" << endl;
        cout << "|          =====       MENU DE VENDEDORES      =====           |" << endl;
        cout << " -------------------------------------------------------------- " << endl;
        cout << "|                                                              |" << endl;
        cout << "|                1- ALTA                                       |" << endl;
        cout << "|                2- BAJA                                       |" << endl;
        cout << "|                3- MODIFICAR                                  |" << endl;
        cout << "|                4- LISTAR TODOS ACTIVOS/INACTIVOS             |" << endl;
        cout << "|                5- LISTAR POR LEGAJO                          |" << endl;
        cout << "|                6- VENDEDOR QUE MAS RECAUDO                   |" << endl;
        cout << "|                7- PRODUCTO QUE MAS SE VENDIO POR VENDEDOR    |" << endl;
        cout << "|                                                              |" << endl;
        cout << "|                0- VOLVER AL MENU GENERAL.                    |" << endl;
        cout << "|                                                              |" << endl;
        cout << " -------------------------------------------------------------- " << endl;
        cout << endl << "                      Ingrese Opcion: " << endl;
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
         cin.clear(); //limpia error de cin
         cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
         opcion=-1;
        }
        switch(opcion)
        {
            case 1:
                system("cls");
                ///vendedorcito.Cargar();
                ///obj.AgregarRegistro(vendedorcito);
                system("pause");
            break;

            case 2:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa Legajo a dar de baja: ";
                    cin >> legajo;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                ///obj.BajaLogicaVendedor(legajo);
                system("pause");
            break;

            case 3:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa id a modificar: ";
                    cin >> legajo;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese valor numerico." << endl; //escriban el mensaje que quieran
                        incorrecto = true;
                    }

                }while(incorrecto);

                ///obj.MenuModificarVendedor(legajo);
                system("pause");
            break;

            case 4:
                system("cls");
                ///obj.ListarRegistros();
                system("pause");
            break;

            case 5:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa el legajo a buscar: ";
                    cin >> legajo;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese valor numerico." << endl; //escriban el mensaje que quieran
                        incorrecto = true;
                    }

                }while(incorrecto);

                ///obj.ListarPorLegajo(legajo);
                system("pause");
            break;

            case 6:
                system("cls");
                ///obj.VendedorMasRecaudo();
                system("pause");
            break;

            case 7:
                system("cls");
                cout<<"Ingrese el id del Equipo para buscar su vendedor estrella."<<endl;
                ///obj.VendedorMasVendioUnEquipo(id);
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL...." << endl;
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);
}

void subMenuVentas(){//revisado
 int opcion;
 Fecha anio;
 int anito;
 Venta ventita;
 ArchivoVenta obj;
 bool IDincorrecto = false;
 do{
        int id=-1;
        system("cls");
        cout << " -------------------------------------------------------- " << endl;
        cout << "|        BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS       |" << endl;
        cout << "|        =====          MENU DE VENTAS       =====       |" << endl;
        cout << " -------------------------------------------------------- " << endl;
        cout << "|                                                        |" << endl;
        cout << "|              1- ALTA                                   |" << endl;
        cout << "|              2- BAJA                                   |" << endl;
        cout << "|              3- MODIFICAR                              |" << endl;
        cout << "|              4- LISTAR VENTAS ACTIVOS/INACTIVOS        |" << endl;
        cout << "|              5- LISTAR VENTAS POR ANIO                 |" << endl;
        cout << "|              6- RECAUDACION TOTAL POR A�O              |" << endl;
        cout << "|                                                        |" << endl;
        cout << "|              0- VOLVER AL MENU GENERAL.                |" << endl;
        cout << "|                                                        |" << endl;
        cout << " -------------------------------------------------------- " << endl;
        cout <<endl<< "Ingrese Opcion: " << endl;
        cin >> opcion;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion=-1;
        }
        switch(opcion)
        {
            case 1:
                system("cls");
                if (ventita.Cargar(obj.ObtainNewID()))
                {
                    obj.AgregarRegistro(ventita);
                }
                system("pause");
            break;

            case 2:
                system("cls");
                do{ // VALIDACION

                    IDincorrecto = false;

                    cout<<"Ingresa Id de la venta a dar de baja: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        IDincorrecto = true;
                    }

                }while(IDincorrecto);

                obj.BajaLogica(id);
                system("pause");
            break;

            case 3:
                system("cls");

                do{ // VALIDACION

                    IDincorrecto = false;

                    cout<<"Ingresa id de la venta a modificar: ";
                    cin >> id;

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        IDincorrecto = true;
                    }

                }while(IDincorrecto);

                obj.MenuModificarVenta(id);
                system("pause");
            break;

            case 4:
                system("cls");
                obj.ListarRegistros();
                system("pause");
            break;

            case 5:
                system("cls");
                cout<<"Ingresa el anio para listar las Ventas: ";
                cin >> anito;
                anio.SetAnio(anito);
                obj.ListarPorAnio(anio);
                system("pause");
            break;

            case 6:
                system("cls");
                cout<<"Ingresa el anio para listar las Ventas: ";
                cin >> anito;
                anio.SetAnio(anito);
                obj.RecaudacionTotalPorAnio(anio);
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL...." << endl;
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);
}
