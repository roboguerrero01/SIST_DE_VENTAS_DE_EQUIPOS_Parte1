#include <iostream>
#include "fecha.h"
#include <ctime>

using namespace std;

// Constructor por defecto: asigna la fecha del sistema
Fecha::Fecha() {
    time_t t = time(nullptr);
    tm* tiempoLocal = localtime(&t);
    Dia = tiempoLocal->tm_mday;
    Mes = tiempoLocal->tm_mon + 1;
    Anio = tiempoLocal->tm_year + 1900;
}

Fecha::Fecha(int _d, int _m, int _a) {
    SetDia(_d);
    SetMes(_m);
    SetAnio(_a);
}

// Getters
int Fecha::GetDia() { return Dia; }
int Fecha::GetMes() { return Mes; }
int Fecha::GetAnio() { return Anio; }

// Setters
bool Fecha::SetDia(int _d) {
    cin.clear();
    cin.ignore(10000, '\n');
    bool esbisiesto=true;
         if(Anio%4!=0)
           {
            esbisiesto=false;
           }
        else
            {
               if (Anio%100==0&&Anio%400!=0)
                {
                    esbisiesto=false;
                }
            }

    switch (Mes) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            if (_d >= 1 && _d <= 31)
                {
                    Dia = _d;
                    cout<<"DIA CORRECTO"<<endl;
                    return true;
                }
               cout << "Dia invalido. Ingrese un dia entre 1-31. NO SE GUARDO" << endl;
               return false;
               break;
            case 4: case 6: case 9: case 11:
            if (_d >= 1 && _d <= 30)
                {
                    Dia = _d;
                    cout<<"DIA CORRECTO"<<endl;
                    return true;
                }
                cout << "Dia invalido. Ingrese un dia entre 1-30. NO SE GUARDO" << endl;
                return false;
                break;
            case 2:
            if (esbisiesto)
                {
                    if (_d >= 1 && _d <= 29)
                     {
                      Dia = _d;
                      cout<<"DIA CORRECTO"<<endl;
                      return true;
                     }
                  cout << "Dia invalido. Ingrese un dia entre 1-29. NO SE GUARDO" << endl;
                  return false;
                }
              else if (_d >= 1 && _d <= 28)
                {
                    Dia = _d;
                    cout<<"DIA CORRECTO"<<endl;
                    return true;
                }
                cout << "Dia invalido. Ingrese un dia entre 1-28. NO SE GUARDO" << endl;
                return false;
                break;

       default: cout << "Dia invalido fuera de los rangos permitidos entre 1-31. NO SE GUARDO" << endl;
               return false;
               break;
    }
}

bool Fecha::SetMes(int _m) {
    cin.clear();
    cin.ignore(10000, '\n');
    if (_m >= 1 && _m <= 12)
        {
          Mes = _m;
          cout<<"MES CORRECTO"<<endl;
          return true;
        }
    cout << "Mes invalido. Porfavor ingrese un Mes entre 1 y 12. NO SE GUARDO" << endl;
    return false;
}

bool Fecha::SetAnio(int _a) {
    cin.clear(); //limpia error de cin
    cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
    if (_a >= 1850 && _a <= 2025)
        {
         Anio = _a;
         cout<<"ANIO CORRECTO"<<endl;
         return true;
        }
  cout << "Anio invalido. Debe estar entre 1850 y 2025. NO SE GUARDO"<< endl;
  return false;
}

///Cargar datos
void Fecha::Cargar() {
 int d,a,m=0;
 bool salir[3]{false,false,false};
 int intentos=10;

 cout<<"Tienes "<<intentos<<" intentos para ingresar correctamente una fecha: 1 error es 1 intento menos"<<endl;
  //ANIO
  while(!salir[0])
    {
        cout<<"Anio: ";
        cin>>a;
        salir[0]=SetAnio(a);
        if(salir[0]==false)
             {
               intentos--;
               cout<<"Intentos restantes: "<<intentos<<endl;
             }
        if(intentos==0)
            {
              salir[0]=salir[1]=salir[2]=true;
              cout<<endl<<"Sin intentos, se usara la fecha del dia de hoy, use MODIFICAR para cambiar la fecha"; /// si al ingresar letras 10 veces
              CargarConFechaDeHoy();
            }
      };

  //MES
  while(!salir[1])
    {
        cout<<"Mes: ";
        cin>>m;
        salir[1]=SetMes(m);
        if(salir[1]==false)
             {
               intentos--;
               cout<<"Intentos restantes: "<<intentos<<endl;
             }

        if(intentos==0)
            {
              salir[1]=salir[2]=true;
              cout<<endl<<"Sin intentos, se usara la fecha del dia de hoy, use MODIFICAR para cambiar la fecha"; /// si al ingresar letras 10 veces
              CargarConFechaDeHoy();   /// seteo de fecha con la del dia de hoy
            }
      };
  //DIA
  while(!salir[2])
    {
        cout<<"Dia: ";
        cin>>d;
        salir[2]=SetDia(d);
        if(salir[2]==false)
             {
               intentos--;
               cout<<"Intentos restantes: "<<intentos<<endl;
             }
        if(intentos==0)
            {
              salir[2]=true;
              cout<<endl<<"Sin intentos, se usara la fecha del dia de hoy, use MODIFICAR para cambiar la fecha"; /// si al ingresar letras 10 veces
              CargarConFechaDeHoy();
            }
      };

  cout<<endl;
  }

void Fecha::Mostrar() {
    cout << Dia << "/" << Mes << "/" << Anio << endl<<endl;
}

void Fecha::CargarConFechaDeHoy(){
    time_t t = time(nullptr);
    tm* tiempoLocal = localtime(&t);
    Dia = tiempoLocal->tm_mday;
    Mes = tiempoLocal->tm_mon + 1;
    Anio = tiempoLocal->tm_year + 1900;
}
