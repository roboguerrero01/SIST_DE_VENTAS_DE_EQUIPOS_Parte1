#pragma once

class Equipo {
   private:
      int IdEquipo;
      int Tipo;
      char Marca[30];
      int Stock;
      float Precio;
      bool Estado;

   public:
      // Constructor por defecto
      Equipo();

      //GETTERES Y SETTERS
      void setIdEquipo(int);
      void setMarca(const char*);
      void setTipo(int);
      void setStock(int);
      void setPrecio(float);
      void setEstado(bool);

      int getIdEquipo();
      char* getMarca();
      int getTipo();
      int getStock();
      float getPrecio();
      bool getEstado();

      //metodos
      bool Cargar(int); /// int es id
      void Mostrar();
      void Modificar();
};

