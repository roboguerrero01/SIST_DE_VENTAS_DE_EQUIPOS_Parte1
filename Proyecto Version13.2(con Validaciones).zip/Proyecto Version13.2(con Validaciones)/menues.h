#pragma once
#include "archivo_clienteFisico.h"
#include "archivo_clienteJuridico.h"
#include "archivo_equipo.h"
#include "Venta.h"
#include "archivo_Venta.h"
#include "Vendedor.h"

void menuGeneral();
void subMenuEquipo();
void subMenuClientes();
void subMenuVendedor();
void subMenuVentas();
void subMenuClientesJuridicos();
void subMenuClientesFisicos();


