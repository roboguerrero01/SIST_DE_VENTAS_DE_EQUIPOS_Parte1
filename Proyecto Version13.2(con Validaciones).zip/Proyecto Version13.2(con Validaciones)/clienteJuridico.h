#pragma once

class ClienteJuridico{
  private:
      int IdClienteJuridico;
      char Cuit[12];
      char NombreEmpresa[50];
      char Direccion[100];
      bool Estado;

  public:
      ClienteJuridico();

      void setIdClienteJuridico(int);
      void setCuit(const char*);
      void setNombreEmpresa(const char*);
      void setDireccion(const char*);
      void setEstado(bool);

      int getIdClienteJuridico();
      const char* getCuit();
      const char* getNombreEmpresa();
      const char* getDireccion();
      bool getEstado();

      bool Cargar(const char*, int); ///cuit, id
      void Mostrar();

};
