#include"archivo_Vendedor.h"
#include "archivo_Venta.h"
#include<iostream>
#include <cstring>
using namespace std;

ArchivoVendedor::ArchivoVendedor(){
    strcpy(nombreRuta, "archivoVendedor.dat");
    tamanioRegistro = sizeof(Vendedor);
}
////
bool ArchivoVendedor::VerificarDuplicado(int legajo){ /// LO USA LA FUNCION AGREGAR REGISTRO
    Vendedor obj;

    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(legajo == obj.getLegajo())
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}
////
void ArchivoVendedor::AgregarRegistroModificado(Vendedor& obj){ /// LO USA LA FUNCION MENU MODIFICAR VENDEDOR
    FILE *p;

    p = fopen(nombreRuta, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    fseek(p, tamanioRegistro*(obj.getLegajo() - 1), SEEK_SET);

    if(fwrite(&obj, tamanioRegistro, 1, p))
    {
        cout<<"Registro Modificado Exitosamente" << endl;
    }
    else
    {
        cout<<"Registro NO Modificado, ALGO SALIO MAL" << endl;
    }


    fclose(p);
}
////
bool ArchivoVendedor::BuscarVendedorporLegajo(int legajo, Vendedor& obj){ /// Funcion para corroborar si existe, LO USA LA FUNCION MOSTRAR VENDEDOR X LEGAJO
    FILE *p = fopen(nombreRuta, "rb");
    if (p==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return 0;
    }

    int pos = 0;

    while (fread(&obj, tamanioRegistro, 1, p) == 1) {
        if (obj.getLegajo() == legajo)
        {
            fclose(p);
            return 1;
        }
        pos++;
    }

    fclose(p);
    return -1;
}
////
int ArchivoVendedor::ObtainNewLegajo(){
    return CantidadRegistros() + 1;
}
////
int ArchivoVendedor::CantidadRegistros(){
    FILE *p;
    p = fopen(nombreRuta, "rb");
    int cantidad;
    if(p==nullptr)
    {
        return 0;
    }
    fseek(p,0,SEEK_END);
    cantidad=ftell(p) / tamanioRegistro;
    fclose(p);
    return cantidad;
}

void ArchivoVendedor::AgregarRegistro(Vendedor obj){ /// OPCION 1
    int escribio;
    FILE *p = fopen(nombreRuta, "ab");

    if (p==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    escribio = fwrite(&obj, tamanioRegistro, 1, p);

    fclose(p);

    if (escribio != 1)
    {
        cout << "Error al escribir el registro." << endl;
        return;
    }

    cout << "Registro agregado correctamente." <<endl<< endl;
    return;
}

bool ArchivoVendedor::BajaLogica(int legajo){ /// OPCION 2
    Vendedor obj;

    BuscarVendedorporLegajo(legajo, obj);

    if (!obj.getEstado())
    {
        cout << "Error: Equipo ya dado de baja" << '\n';
        return 0;
    }

    obj.setEstado(false);

    AgregarRegistroModificado(obj);

    return true;
}

bool ArchivoVendedor::MenuModificarVendedor(int legajo){ /// OPCION 3
    Vendedor obj;
    char _nombres[30];
    char _apellidos[30];
    char _dni[9];
    char _telefono[20];
    char _correo[50];
    char _direccion[50];
    Fecha _nacimiento;

    Fecha _ingreso;
    float _sueldo;

    bool salir = false;
    bool errorDeIngreso = false;

    if (!BuscarVendedorporLegajo(legajo, obj))
        {
            cout<<"No hay registros cargados/guardados"<<endl;
            return 0;
        }

    if (!obj.getEstado())
    {
        cout << "Error: perfil dado de baja." << '\n';
        salir = true;
    }

    while(!salir)
    {
        system ("cls");
        int opc;
        cout << " ----------------------------------------------------- " << endl;
        cout << "         Perfil de " << obj.getNombres() << " " << obj.getApellidos() << endl;
        cout << " ----------------------------------------------------- " << endl;
        cout << "         Elija el atributo a modificar: "<<endl<<endl;
        cout << "         1 -  Nombre"<<endl;
        cout << "         2 -  Apellido"<<endl;
        cout << "         3 -  Dni"<<endl;
        cout << "         4 -  Nacimiento"<<endl;
        cout << "         5 -  Telefono"<<endl;
        cout << "         6 -  Correo"<<endl;
        cout << "         7 -  Direccion"<<endl;
        cout << "         8 -  Fecha de Ingreso" << endl;
        cout << "         9 -  Sueldo" << endl << endl;
        cout << "         0 -  Salir"<<endl<<endl;
        cout << " ------------------------------------------------------ " << endl;
        cout << "              Opcion: ";
        cin>>opc;
        if(cin.fail())
        {
            cin.clear();
            cin.ignore(10000,'\n');
            opc = -1;
        }
        switch(opc)
        {

            case 1:  //nombre
                cin.ignore(10000, '\n');
                do{
                    errorDeIngreso = false;
                    cin.clear();
                    cout<<"Ingrese Nuevo Nombre: ";
                    cin.getline(_nombres, 30);

                    for(int i=0; _nombres[i] != '\0'; i++)
                    {
                        // si no esta en el rango de mayusculas o minusculass en ASCII.
                        if(!(_nombres[i]>64 && _nombres[i]<91 || _nombres[i]>96 && _nombres[i]<123 ||_nombres[i]==32))
                        {
                            errorDeIngreso = true;
                            cout << "Error de ingreso. PRESIONE ENTER" << '\n';
                            break;
                        }
                    }
                }
                while(errorDeIngreso);

                obj.setNombres(_nombres);
                AgregarRegistroModificado(obj);
                system ("pause");
            break;

            case 2:  //apellido
                cin.ignore(10000, '\n');
                do{
                    errorDeIngreso = false;
                    cin.clear();
                    cout<<"Ingrese Nuevo Apellido: ";
                    cin.getline(_apellidos,30);

                    for(int i=0; _apellidos[i] != '\0'; i++)
                    {
                        // si no esta en el rango de mayusculas o minusculass en ASCII.
                        if(!(_apellidos[i]>64 && _apellidos[i]<91 || _apellidos[i]>96 && _apellidos[i]<123||_apellidos[i]==32))
                        {
                            errorDeIngreso = true;
                            cout << "Error de ingreso. PRESIONE ENTER" << '\n';
                            break;
                        }
                    }
                }
                while(errorDeIngreso);


                obj.setApellidos(_apellidos);
                AgregarRegistroModificado(obj);
                system ("pause");
            break;

            case 3:  //dni
                cin.ignore(10000, '\n');
                do{

                    errorDeIngreso = false;
                    cin.clear();
                    cout<<"Ingrese Nuevo DNI: ";
                    cin.getline(_dni,9);

                    for(int i=0; _dni[i] != '\0'; i++)
                    {
                        if((int)_dni[0]==48) ///que el primer numero no sea 0
                        {
                            errorDeIngreso=true;
                            cout << "ERRROR, El dni no puede empezar en 0" << endl;
                            break;
                        }

                        // si no esta en el rango de numeros en ASCII.
                        if(!(_dni[i] >= '0' && _dni[i] <= '9'))
                        {
                            errorDeIngreso = true;
                            cout << "Error de ingreso. Ingrese un valor numerico positivo valido" << '\n';
                            break;
                        }
                    }

                }while(errorDeIngreso);

                obj.setDni(_dni);
                AgregarRegistroModificado(obj);
                system ("pause");
            break;

            case 4:  //fecha
                cout<<"Ingrese Nueva Fecha de Nacimiento: ";
                _nacimiento.Cargar();
                obj.SetFecha(_nacimiento);
                AgregarRegistroModificado(obj);
                system ("pause");
            break;

            case 5:  //telefono
                cin.ignore(10000, '\n');
                do{

                    errorDeIngreso = false;
                    cin.clear();
                    cout<<"Ingrese Nuevo Telefono: ";
                    cin.getline(_telefono,20);

                    for(int i=0; _telefono[i] != '\0'; i++)
                    {
                        // si no esta en el rango de numeros en ASCII.
                        if(!((int)_telefono[i] < 58 && (int)_telefono[i] > 47))
                        {
                            errorDeIngreso = true;
                            cout << "Error de ingreso. Digite un numero positivo" << '\n';
                            break;
                        }
                    }
                }while(errorDeIngreso);

                obj.setTelefono(_telefono);
                AgregarRegistroModificado(obj);
                system ("pause");
            break;

            case 6:  //email
                cin.ignore(10000, '\n');
                cout<<"Ingrese Nuevo EMAIL:";
                cin.getline(_correo,50);
                obj.setEmail(_correo);
                AgregarRegistroModificado(obj);
                system ("pause");
            break;

            case 7:  //direccion
                cin.ignore(10000, '\n');
                do{
                    errorDeIngreso = false;
                    cin.clear();
                    cout<<"Ingrese Nueva Direccion:";
                    cin.getline(_direccion, 50);

                    for(int i=0; _direccion[i] != '\0'; i++)
                    {
                        // si no esta en el rango de mayusculas, minusculas o numeros en ASCII.
                        if(!(_direccion[i]>64 && _direccion[i]<91 || _direccion[i]>96 && _direccion[i]<123 || (int)_direccion[i] > 47 && (int)_direccion[i] < 58 || _direccion[i] == 32))
                        {
                            errorDeIngreso = true;
                            cout << "Error de ingreso. NO SE PERMITEN SIMBOLOS" << '\n';
                            break;
                        }
                    }
                }while(errorDeIngreso);

                obj.setDireccion(_direccion);
                AgregarRegistroModificado(obj);
                system ("pause");
            break;

            case 8:  //Ingreso
                cout<<"Ingrese Nueva Fecha de Ingreso: ";
                _ingreso.Cargar();
                obj.setIngreso(_ingreso);
                AgregarRegistroModificado(obj);
                system ("pause");
            break;

            case 9:  //Sueldo
                cout<<"Ingrese el nuevo sueldo: ";
                cin >> _sueldo;
                if(cin.fail()||_sueldo<0)
                {
                    errorDeIngreso = true;
                    cout << "Error de ingreso. Ingrese un valor numerico positivo" << '\n';
                    cin.clear();
                    cin.ignore(10000,'\n');
                    system ("pause");
                    break;
                }
                obj.setSueldo(_sueldo);
                AgregarRegistroModificado(obj);
                system ("pause");
            break;

            case 0:
                cout<<"saliendo del modificar, muchas gracias"<<endl;
                salir = true;
            break;

            default:
                cout<<"ingrese opcion correcta"<<endl;
                system ("pause");
            break;
        }
    }

    return 1;
}

bool ArchivoVendedor::ListarRegistros(){ /// OPCION 4
    bool flagTodosInactivos = true;
    bool flagTodosActivos = true;
    Vendedor obj;
    FILE *p;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr){
        cout<<"error de apertura"<<endl;
        return 0;
    }

    int opc;
    bool salir=false;
    while(!salir){
        cout<<"Quiere Listar:"<<endl<<"1 - Activos"<<endl<<"2 - Inactivos"<<endl<<"0 - Volver"<<endl<<endl ;
        cout<<"Su opcion: "<<endl;
        cin.ignore(10000, '\n');
        cin>>opc;
        if (cin.fail()){
            opc=-1;
            cin.clear();
        }

        switch(opc){
        case 2:
            system("pause");
            system("cls");
            while(fread(&obj, tamanioRegistro, 1, p)){
                if (!obj.getEstado()){
                    flagTodosActivos = false;
                    obj.Mostrar();
                    cout<<endl;
                }
            }
            if (flagTodosActivos){
                cout << "Error: No hay registros inactivos" << endl;
            }
            salir=true;
            break;
        case 1:
            system("pause");
            system("cls");
            while(fread(&obj, tamanioRegistro, 1, p)){
                if (obj.getEstado()){
                    flagTodosInactivos = false;
                    obj.Mostrar();
                    cout<<endl;
                }
            }
            if (flagTodosInactivos){
                cout << "Error: No hay registros activos" << endl;
            }
            salir=true;
            break;
        case 0:
            cout<<"Volviendo"<<endl;
            salir=true;
            break;

        default:
            cout<<"Ingrese una opcion numerica positiva valida"<<endl;
            system("pause");
            system("cls");
            break;
        }
    }
    fclose(p);
    return 1;
}

void ArchivoVendedor::ListarPorLegajo(int legajo){ /// OPCION 5
    Vendedor obj;
    if(BuscarVendedorporLegajo(legajo, obj)){
        obj.Mostrar();
    }
}

void ArchivoVendedor::VendedorMasRecaudo(){ /// OPCION 6
    ArchivoVenta ventas;
    Vendedor MayorRecaudador;
    Vendedor obj;
    bool Flag = true;

    FILE *p;
    p = fopen(nombreRuta, "rb");

    while(fread(&obj, tamanioRegistro, 1, p)){
        if(Flag){
            MayorRecaudador = obj;
            Flag = false;
        }
        if(ventas.RecaudacionTotalVendedor(MayorRecaudador.getLegajo()) <  ventas.RecaudacionTotalVendedor(obj.getLegajo())) {
            MayorRecaudador = obj;
        }
    }

    MayorRecaudador.Mostrar();
    cout << "Recaudacion total: " << ventas.RecaudacionTotalVendedor(MayorRecaudador.getLegajo()) << '\n';

    fclose(p);
}

void ArchivoVendedor::VendedorMasVendioUnEquipo(int idEquipo){ /// OPCION 7
    ArchivoVenta objVenta;
    Vendedor obj;

    int cantidadVendida = 0;
    int mayorCantidadVendida = 0;
    int i = 0;
    int indiceVendedor = -1; // posicion en memoria de vendedor

    FILE *p;
    p = fopen(nombreRuta, "rb");

    while(fread(&obj, tamanioRegistro, 1, p)){
        cantidadVendida = objVenta.CantidadVendidaDeEquipoPorVendedor(obj.getLegajo(), idEquipo);

        if(mayorCantidadVendida < cantidadVendida){
            mayorCantidadVendida = cantidadVendida;
            indiceVendedor = i;
        }

        i++;
    }

    fseek(p, tamanioRegistro * indiceVendedor, SEEK_SET);
    fread(&obj, tamanioRegistro, 1, p);

    cout << "Vendedor que mas recaudo ese equipo: " << '\n';
    obj.Mostrar();
    cout << "Vendio " << mayorCantidadVendida << " Unidades. " << '\n';


    fclose(p);
}

bool ArchivoVendedor::VerificarActivo(int _legajo){
    Vendedor vendedorcito;
    FILE *p;
    p = fopen(nombreRuta, "rb");

    while(fread(&vendedorcito, tamanioRegistro, 1, p)){
        if(_legajo==vendedorcito.getLegajo())
        {
            fclose(p);
            return vendedorcito.getEstado();
        }
    }

    fclose(p);
    return false;
}


