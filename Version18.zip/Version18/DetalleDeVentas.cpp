#include<iostream>
#include"DetalleDeVentas.h"
#include"archivo_equipo.h"
#include"equipo.h"
#include"archivo_Venta.h"
using namespace std;

DetalleDeVentas::DetalleDeVentas(){
    Cantidad = 0;
}

void DetalleDeVentas::setIdDetalleDeVenta(int _idDetalleDeVenta){ IdDetalleDeVenta = _idDetalleDeVenta; }
void DetalleDeVentas::setCantidad(int){}
void DetalleDeVentas::setPrecioUnitario(float){}

int DetalleDeVentas::getIdDetalleDeVenta(){ return IdDetalleDeVenta; }
int DetalleDeVentas::getIdVenta(){ return IdVenta; }
int DetalleDeVentas::getIdEquipo(){ return IdEquipo; }
int DetalleDeVentas::getCantidad(){ return Cantidad; }
float DetalleDeVentas::getPrecioUnitario(){ return PrecioUnitario; }

void DetalleDeVentas::Mostrar(){
    cout << " Detalle de venta [ ID: " << getIdDetalleDeVenta() << " ]" << endl;
    cout << "-------------------------------------- " << endl;
    cout << " ID Equipo: " << getIdEquipo() << endl;
    cout << " Cantidad adquirida: " << getCantidad() << endl;
    cout << " Precio unitario: $" << getPrecioUnitario() << endl;
    cout << " Precio total: $" << getCantidad() * getPrecioUnitario() <<endl;
    cout << "-------------------------------------- " << endl << endl;
}

bool DetalleDeVentas::Cargar(int idVenta, int idEquipo){
    bool confirmarCompra = false;

    ArchivoEquipo gestorEquipo;
    Equipo equipo;
    gestorEquipo.BuscarPosicionPorId(idEquipo, equipo);

    IdVenta = idVenta;
    IdEquipo = idEquipo;



////Reviso que haya stock disponible

    if (equipo.getStock() == 0){
        cout << "Error: No hay Stock disponible" << endl;
        system("pause");
        return false;
    }

    PrecioUnitario = equipo.getPrecio();
    cout << "Precio Unitario: $" << PrecioUnitario << endl;

////Pido Cantidad a comprar
//    Cantidad = 0;
        cout << "Unidades disponibles: " << equipo.getStock() << endl;
    do{
        cout << "Cuantas unidades desea comprar? " << endl;
        cin >> Cantidad;
        if (Cantidad > equipo.getStock())
        {
            cout << "Error: Stock insuficiente, Elija una cantidad disponible"<<endl;
        }
        if (Cantidad==0)
        {
            cout << "Error: Elija una cantidad mayor a 0"<<endl<<endl;
        }

    } while (Cantidad > equipo.getStock()|| Cantidad==0);

    cout << "Precio Total: $" << Cantidad * PrecioUnitario << endl;

////Muestro coste total del detalle de venta y pregunto si se arrepienten
    do {
        if (cin.fail()){ cout << "Error: Ingrese un valor valido." << endl; }

        cin.clear();
        cin.ignore(10000, '\n');

        cout <<endl<<"Desea confirmar el detalle de venta? [ 0 - Cancelar, 1 - Aceptar] " << endl;
        cin >> confirmarCompra;

    } while (cin.fail());

    if (!confirmarCompra){
        cout << "Detalle de venta cancelado exitosamente. " << endl;
        return false;
    }

////Guardo los cambios realizados
    equipo.setStock(equipo.getStock() - Cantidad);
    gestorEquipo.AgregarRegistroModificado(equipo);
    GuardarEnArchivo();

    return true;
}

void DetalleDeVentas::GuardarEnArchivo(){
    const char* ruta = "DetalleDeVentas.dat";
    int tamanioRegistro = sizeof(DetalleDeVentas);

    FILE *p;
    p = fopen(ruta, "ab");

    if (p == nullptr){
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    fwrite(this, tamanioRegistro, 1, p);

    fclose(p);
}

void DetalleDeVentas::DevolverStock(int idVenta){
    ArchivoEquipo GestorEquipo;
    Equipo equipo;
    DetalleDeVentas obj;
    const char* ruta = "DetalleDeVentas.dat";
    int tamanioRegistro = sizeof(DetalleDeVentas);

    FILE *p;
    p = fopen(ruta, "rb");

    if (p == nullptr){
        cout<<"no hay detalles de venta cargado"<<endl;
        system("pause");
        return;
    }

    while(fread(&obj, tamanioRegistro, 1, p)){
        if (idVenta == obj.getIdVenta()){
            GestorEquipo.BuscarPosicionPorId(obj.getIdEquipo(), equipo);
            equipo.setStock(equipo.getStock() + obj.getCantidad());
            GestorEquipo.AgregarRegistroModificado(equipo);
        }
    }

    fclose(p);

}
// "DetalleDeVentas.dat"
// "DetalleDeVentasCopia.dat"

void DetalleDeVentas::CopiaDeSeguridad(){
    DetalleDeVentas obj;
    int peso = sizeof(DetalleDeVentas);

    FILE *pDTV;
    FILE *pDTVC;

    pDTV = fopen("DetalleDeVentas.dat", "rb"); /// Original lee
    pDTVC = fopen("DetalleDeVentasCopia.dat", "ab"); /// Copia escribe

    if (pDTV == nullptr){
//        cout<<"Error: Original"<<endl;
//        system("pause");
        return;
    }

    if (pDTVC == nullptr){
        cout<<"Error: Copia"<<endl;
        system("pause");
        return;
    }

    fseek(pDTVC, 0, SEEK_CUR);

    while(fread(&obj, peso, 1, pDTV)){
        fwrite(&obj, peso, 1, pDTVC);
    }

    fclose(pDTV);
    fclose(pDTVC);
}
void DetalleDeVentas::CargarCopiaDeSeguridad(){
    DetalleDeVentas obj;
    int peso = sizeof(DetalleDeVentas);

    FILE *pDTVC;
    FILE *pDTV;

    pDTVC = fopen("DetalleDeVentasCopia.dat", "rb"); /// Copia lee
    pDTV = fopen("DetalleDeVentas.dat", "wb"); /// Original escribe

    if (pDTVC == nullptr){
        cout<<"Error: Copia"<<endl;
        system("pause");
        return;
    }

    if (pDTV == nullptr){
        cout<<"Error: Original"<<endl;
        system("pause");
        return;
    }

    fseek(pDTV, 0, SEEK_CUR);

    while(fread(&obj, peso, 1, pDTVC)){
        fwrite(&obj, peso, 1, pDTV);
    }

    fclose(pDTVC);
    fclose(pDTV);
}

void DetalleDeVentas::CancelarDetallesDeVenta(int idVenta){
    DevolverStock(idVenta);
    CargarCopiaDeSeguridad();
}

float DetalleDeVentas::RecaudacionVenta(int idVenta){
    DetalleDeVentas detalle;
    int recaudacion = 0;

    const char* ruta = "DetalleDeVentas.dat";
    int tamanioRegistro = sizeof(DetalleDeVentas);

    FILE *p;
    p = fopen(ruta, "rb");

    if (p == nullptr){
        cout<<"no hay detalles de venta cargados"<<endl;
        system("pause");
        return 0;
    }

    while(fread(&detalle, tamanioRegistro, 1, p)){
        if (detalle.getIdVenta() == idVenta){
            recaudacion += detalle.getCantidad() * detalle.getPrecioUnitario();
        }
    }

    fclose(p);

    return recaudacion;
}

int DetalleDeVentas::ObtainNewID(int id){
    return ContarRegistros(id) + 1;
}

int DetalleDeVentas::ContarRegistros(int idVenta){
    DetalleDeVentas obj;

    int cantidad = 0;

    const char* ruta = "DetalleDeVentas.dat";
    int tamanioRegistro = sizeof(DetalleDeVentas);

    FILE *p;

    p = fopen(ruta, "rb");

    if (p == nullptr){
        return 0;
    }

    while(fread(&obj, tamanioRegistro, 1, p)){
        if(obj.getIdVenta()==idVenta){
            cantidad++;
        }
    }

    fclose(p);

    return cantidad;
}

int DetalleDeVentas::ContarVentasDeEquipo(int idVenta, int idEquipo){
    DetalleDeVentas obj;

    int cantidad = 0;

    const char* ruta = "DetalleDeVentas.dat";
    int tamanioRegistro = sizeof(DetalleDeVentas);

    FILE *p;

    p = fopen(ruta, "rb");

    if (p == nullptr){
        return 0;
    }

    while(fread(&obj, tamanioRegistro, 1, p)){
        if(obj.getIdVenta()==idVenta && obj.getIdEquipo() == idEquipo){
            cantidad += obj.getCantidad();
        }
    }

    fclose(p);

    return cantidad;
}
