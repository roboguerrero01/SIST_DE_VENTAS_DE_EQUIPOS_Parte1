#include"archivo_Venta.h"
#include<iostream>
#include<cstring>
using namespace std;

ArchivoVenta::ArchivoVenta(){
    strcpy(nombreRuta, "archivoVenta.dat");
    tamanioRegistro = sizeof(Venta);
}

int ArchivoVenta::ObtainNewID(){
    return CantidadRegistros() + 1;
}

int ArchivoVenta::CantidadRegistros(){
    FILE *p;
    p = fopen(nombreRuta, "rb");
    int cantidad;
    if(p==nullptr)
    {
        return 0;
    }
    fseek(p,0,SEEK_END);
    cantidad=ftell(p) / tamanioRegistro;
    fclose(p);
    return cantidad;
}

bool ArchivoVenta::VerificarDuplicado(int id){
    Venta obj;

    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(id == obj.getIDventa())
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}

void ArchivoVenta::AgregarRegistroModificado(Venta& obj){
    FILE *p;

    p = fopen(nombreRuta, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    fseek(p, tamanioRegistro*(obj.getIDventa() - 1), SEEK_SET);

    if(fwrite(&obj, tamanioRegistro, 1, p))
    {
//        cout<<"Registro Modificado Exitosamente" << endl;
    }
    else
    {
//        cout<<"Registro NO Modificado, ALGO SALIO MAL" << endl;
    }


    fclose(p);
}

bool ArchivoVenta::BuscarVentaporID(int id, Venta& obj){
    FILE *p = fopen(nombreRuta, "rb");
    if (p==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return 0;
    }

    int pos = 0;

    while (fread(&obj, tamanioRegistro, 1, p) == 1) {
        if (obj.getIDventa() == id)
        {
            fclose(p);
            return pos;
        }
        pos++;
    }

    fclose(p);
    return -1;
}

float ArchivoVenta::RecaudacionTotalVendedor(int legajoVendedor){
    DetalleDeVentas detalle;
    int recaudacion = 0;
    Venta obj;

    FILE *p;
    p = fopen(nombreRuta, "rb");

    if (p == nullptr){
        cout<<"no hay ventas cargadas"<<endl;
        system("pause");
        return 0;
    }

    while(fread(&obj, tamanioRegistro, 1, p)){
        if (obj.getLegajoVendedor() == legajoVendedor){
            recaudacion += detalle.RecaudacionVenta(obj.getIDventa());
        }
    }

    return recaudacion;
}

int ArchivoVenta::CantidadVendidaDeEquipoPorVendedor(int legajoVendedor, int idEquipo){
    DetalleDeVentas detalle;
    int cantidad = 0;
    Venta obj;

    FILE *p;
    p = fopen(nombreRuta, "rb");

    if (p == nullptr){
        cout<<"no hay ventas cargadas"<<endl;
        system("pause");
        return 0;
    }

    while(fread(&obj, tamanioRegistro, 1, p)){
        if (obj.getLegajoVendedor() == legajoVendedor){
            cantidad += detalle.ContarVentasDeEquipo(obj.getIDventa(), idEquipo);
        }
    }

    return cantidad;
}

void ArchivoVenta::AgregarRegistro(Venta obj){
    int escribio;
    FILE *p = fopen(nombreRuta, "ab");

    if (p==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    escribio = fwrite(&obj, tamanioRegistro, 1, p);

    fclose(p);

    if (escribio != 1)
    {
        cout << "Error al escribir el registro." << endl;
        return;
    }

    cout << "Registro agregado correctamente." <<endl<< endl;
    return;
}

bool ArchivoVenta::BajaLogica(int id){
    Venta obj;
    DetalleDeVentas detalle;
    FILE *p;
    p = fopen(nombreRuta, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    fseek(p, tamanioRegistro*(id-1), 0);
    fread(&obj, tamanioRegistro, 1, p);

    if (!obj.getEstado())
    {
        cout << "Error: Equipo ya dado de baja" << '\n';
        fclose(p);
        return 0;
    }

    obj.setEstado(false);

    AgregarRegistroModificado(obj);
    detalle.DevolverStock(obj.getIDventa());

    fclose(p);

    return true;
}

void ArchivoVenta::ModificarFechaDeVenta(int idVenta){
    Fecha date;
    Venta obj;
    FILE *p;

    p = fopen(nombreRuta, "rb+");

    if (p == nullptr)
    {
        cout<<"Error"<<endl;
        system("pause");
        return;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(obj.getIDventa() == idVenta)
        {
            break;
        }
    }
    fseek(p, -tamanioRegistro, SEEK_CUR);

    obj.Mostrar();
    cout << "Ingresa la nueva fecha de venta" << endl;
    date.Cargar();
    obj.setFechadeVenta(date);

    fwrite(&obj, tamanioRegistro, 1, p);

    fclose(p);

    return;
}

bool ArchivoVenta::ListarRegistros(){
    bool flagTodosInactivos = true;
    bool flagTodosActivos = true;
    Venta obj;
    FILE *p;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr){
        cout<<"error de apertura"<<endl;
        return 0;
    }

    int opc;
    bool salir=false;
    while(!salir){
        cout<<"Quiere Listar:"<<endl<<"1 - Activos"<<endl<<"2 - Inactivos"<<endl<<"0 - Volver"<<endl<<endl ;
        cout<<"Su opcion: "<<endl;
        cin.ignore(10000, '\n');
        cin>>opc;

        if (cin.fail()){
            cin.clear();
            cin.ignore(10000,'\n');
            opc=-1;
        }

        switch(opc){
        case 1:
            system("pause");
            system("cls");
            while(fread(&obj, tamanioRegistro, 1, p)){
                if (obj.getEstado()){
                    flagTodosInactivos = false;
                    obj.Mostrar();
                }
            }
            if (flagTodosInactivos){
                cout << "Error: No hay registros activos" << endl;
            }
            salir=true;
            break;
        case 2:
            system("pause");
            system("cls");
            while(fread(&obj, tamanioRegistro, 1, p)){
                if (!obj.getEstado()){
                    flagTodosActivos = false;
                    obj.Mostrar();
                }
            }
            if (flagTodosActivos){
                cout << "Error: No hay registros inactivos" << endl;
            }
            salir=true;
            break;
        case 0:
            cout<<"Volviendo"<<endl;
            salir=true;
            break;

        default:
            cout<<"Ingrese una opcion valida"<<endl;
            system("pause");
            system("cls");
            break;
        }
    }
    fclose(p);
    return 1;
}

void ArchivoVenta::ListarPorAnio(Fecha anio){
    Venta obj;
    FILE *p = fopen(nombreRuta, "rb");

    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    bool encontrado = false;

    while (fread(&obj, tamanioRegistro, 1, p) == 1) {
        //  Comparar tipo, evitar eliminados y registros inv�lidos (ID 0)
        if ( obj.getFechadeVenta().GetAnio() == anio.GetAnio() && obj.getEstado())
        {
            obj.Mostrar();
            encontrado = true;
        }
    }

    fclose(p);

    if (!encontrado) {
        cout << "No se encontraron ventas en el anio \"" << anio.GetAnio() << "\"." << endl;
    }
}

void ArchivoVenta::RecaudacionTotalPorAnio(Fecha anio){
    int recaudacion = 0;
    Venta obj;
    DetalleDeVentas detalles;

    FILE *p;
    p = fopen(nombreRuta, "rb");

    while(fread(&obj, tamanioRegistro, 1, p)){
        if(obj.getFechadeVenta().GetAnio() == anio.GetAnio()){
            recaudacion += detalles.RecaudacionVenta(obj.getIDventa());
        }
    }

    cout << "Recaudacion total en " << anio.GetAnio() << ": $" << recaudacion << endl;
    fclose(p);
    return;
}

float ArchivoVenta::RecaudacionTotalCliente(int idClienteFisico){
    DetalleDeVentas detalle;
    int recaudacion = 0;
    Venta obj;

    FILE *p;
    p = fopen(nombreRuta, "rb");

    if (p == nullptr){
        cout<<"no hay ventas cargadas"<<endl;
        system("pause");
        return 0;
    }

    while(fread(&obj, tamanioRegistro, 1, p)){
        if (obj.getIdCliente() == idClienteFisico && obj.getEstado()){
            recaudacion += detalle.RecaudacionVenta(obj.getIDventa());
        }
    }
    fclose(p);
    return recaudacion;
}

int ArchivoVenta::CantidadVendidaDeEquipo(int idEquipo){
    DetalleDeVentas detalle;
    int cantidad = 0;
    Venta obj;

    FILE *p;
    p = fopen(nombreRuta, "rb");

    if (p == nullptr){
        cout<<"no hay ventas cargadas"<<endl;
        system("pause");
        return 0;
    }

    while(fread(&obj, tamanioRegistro, 1, p)){
        if(obj.getEstado())
            cantidad += detalle.ContarVentasDeEquipo(obj.getIDventa(), idEquipo);
    }

    fclose(p);

    return cantidad;
}


