#pragma once
#include "personas.h"

class ClienteFisico : public Persona{
  private:
      int IdClienteFisico;
      char Cuil[12];

  public:
      ClienteFisico();

      //GETTERS Y SETTERS
      void setIdClienteFisico(int);
      void setCUIL(const char*);

      int getIdClienteFisico();
      const char* getCUIL();

      bool Cargar(const char*, int); /// cuil, id
      void Mostrar();
};
