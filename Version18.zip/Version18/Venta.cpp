#include<iostream>
#include"Venta.h"

using namespace std;

Venta::Venta(){}

void Venta::setIDventa(int _IdVenta){ IdVenta = _IdVenta; }
void Venta::setEstado(bool _Estado){ Estado = _Estado; }
void Venta::setFechadeVenta(Fecha _FechaDeVenta){ FechaDeVenta = _FechaDeVenta;}
void Venta::setLegajoVendedor(int _LegajoVendedor){ LegajoVendedor = _LegajoVendedor; }
void Venta::setIdCliente(int _idCliente){ IdCliente = _idCliente; }

int Venta::getIDventa(){ return IdVenta; }
bool Venta::getEstado(){ return Estado; }
Fecha Venta::getFechadeVenta(){ return FechaDeVenta; }
int Venta::getLegajoVendedor(){ return LegajoVendedor; }
int Venta::getIdCliente(){ return IdCliente; }

bool Venta::Cargar(int id){
    Estado = true;
    setIDventa(id);

    Fecha _fechaDeVenta;
    int FisicoOJuridico;
    char cuilycuit[12];
    int _legajo;
    int idFisico;
    int idJuridico;
    bool exit = false;
    int caso = 1; ///ASI ENTRA SIEMPRE EN EL CASE

    ArchivoVendedor objVendedor;
    ArchivoClienteFisico objFisico;
    ArchivoClienteJuridico objJuridico;
    ArchivoEquipo equipo;
    DetalleDeVentas detalle;
    int idEquipo = -1;
    bool error;

    cout<<"Bienvenido al ingreso de Ventas"<<endl<<endl<<"A continuacion ingrese la Fecha de Venta"<<endl;

    _fechaDeVenta.Cargar();
    setFechadeVenta(_fechaDeVenta);

////Buscamos id del vendedor
        do{
            error=false;
            if (objVendedor.CantidadRegistros() == 0)
            {
                cout << "Error: No hay vendedores cargados al sistema" << '\n';
                return false;
            }
            cout << "Ingrese el legajo del vendedor: ";
            cin >> _legajo;
            if(!(objVendedor.VerificarDuplicado(_legajo)))
            {
                cout << "Error, vendedor inexistente, intentelo nuevamente" << '\n';
                error=true;
            }
            if (!(objVendedor.VerificarActivo(_legajo)))
            {
                error=true;
                cout<<"VENDEDOR INACTIVO/DADO DE BAJA, ingrese un legajo valido"<<endl;
            }
        } while (error);
        setLegajoVendedor(_legajo); ///setea el legajo de un vendedor de una venta

    cin.ignore();

////Buscamos el id del cliente
        cout << "Que tipo de cliente esta realizando la compra? [ 1 - Fisico, 2 - Juridico]" << '\n';
        cin >> FisicoOJuridico;

        cin.ignore();
        switch(FisicoOJuridico)
        {
        case 1:
            do{
                error=false;
                if (objFisico.CantidadRegistros() == 0)
                {
                    cout<<"No hay Clientes Fisicos Cargados"<<endl;
                    break;
                }

                cout << "Ingrese el cuil del comprador fisico: ";
                cin.getline(cuilycuit,12);

                if( !objFisico.VerificarDuplicado(cuilycuit) )
                {
                    cout << "Error, Cliente inexistente, intentelo nuevamente" << '\n';
                    error=true;
                }
                if (!objFisico.VerificarActivo(objFisico.BuscarIdConCuil(cuilycuit)))
                {
                    error=true;
                    cout<<"ERROR cliente fisico dado de baja"<<endl;
                }

            } while (error);
            idFisico=objFisico.BuscarIdConCuil(cuilycuit);
            setIdCliente(idFisico);
            break;
        case 2:
            do{
                error=false;
                if (objJuridico.CantidadRegistros() == 0)
                {
                    cout<<"No hay Clientes Juridicos Cargados"<<endl;
                    break;
                }

                cout << "Ingrese el cuit del comprador Juridico: ";
                cin.getline(cuilycuit,12);

                if( !objJuridico.VerificarDuplicado(cuilycuit) )
                {
                    cout << "Error, Cliente inexistente, intentelo nuevamente" << '\n';
                    error=true;
                }
                if (!objJuridico.VerificarActivo(objJuridico.BuscarIdConCuit(cuilycuit)))
                {
                    error=true;
                    cout<<"ERROR cliente juridico dado de baja"<<endl;
                }
            } while (error);
            idJuridico=objJuridico.BuscarIdConCuit(cuilycuit);
            setIdCliente(idJuridico);
            break;
        default:
            break;
        }

    IdVenta = id;
    cout << " - ID Venta: " << IdVenta<<endl;
    detalle.CopiaDeSeguridad();
    while(!exit){
        switch(caso){
        case 0:
            exit = true;
            break;
        case 1:
//Buscamos el id del equipo
            do {
                error=false;
                detalle.setIdDetalleDeVenta(detalle.ObtainNewID(IdVenta));
                cout<<"---------------------------------------"<<endl;
                cout<< " - ID Detalle de venta: " << detalle.getIdDetalleDeVenta()<< endl;
                cout << "Ingrese el id del equipo a comprar:";
                cin >> idEquipo;
                cin.ignore();
                if (!equipo.VerificarDuplicado(idEquipo))
                {
                    cout << "Error: el id no esta vinculado a ningun equipo" << endl;
                    error=true;
                }
                if (!equipo.VerificarActivo(idEquipo))
                {
                  error=true;
                  cout<<"EQUIPO INACTIVO/DADO DE BAJA, ingrese un id valido"<<endl;
                }
            } while (error);
            detalle.Cargar(IdVenta, idEquipo);

            break;
        case 2:
////Cancelar Venta
            detalle.CancelarDetallesDeVenta(IdVenta);
            cout << "Venta cancelada exitosamente" << endl;
            Estado = false;
            return false;
            break;
        default:
            cout << "Error: Ingrese una opcion valida. " << endl;
            break;
        }

        if (!exit){
            cout<<"---------------------------------------"<<endl;
            cout <<endl<<"Quiere seguir cargando detalles de venta?"<<endl<<"0 - Parar"<<endl<<"1 - Seguir"<<endl<<"2 - Cancelar venta" << endl;
            cout<<"Su OPCION: ";
            cin >> caso;
            cout<<endl;
        }
    }


    cout << "Estado: Activo por default " << endl;
    return true;
}

void Venta::Mostrar(){
    cout << "\n--- Datos de la Venta ---" << endl;
    cout << "Id venta: " << IdVenta << endl;
    cout << "Legajo Vendedor: " << LegajoVendedor << '\n';
    cout << "Id Cliente: " << IdCliente << '\n';
    cout << "Fecha de Venta: ";
    FechaDeVenta.Mostrar();

    if (Estado){ cout << "Estado: Activo" << endl; }
    else { cout << "Estado: Inactivo" << endl; }
}
