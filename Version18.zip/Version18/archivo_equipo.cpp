#include <iostream>
#include <cstring>
#include "archivo_equipo.h"
#include "archivo_Venta.h"
using namespace std;

///CONSTRUCTOR
ArchivoEquipo::ArchivoEquipo(){//revisado
        strcpy(nombreRuta, "archivoEquipo.dat");
        tamanioRegistro = sizeof(Equipo);
    }

int ArchivoEquipo::AgregarRegistro(Equipo& equipo) {//revisado
    int escribio;
    FILE *pequipo = fopen(nombreRuta, "ab");

    if (pequipo==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return 0;
    }

    escribio = fwrite(&equipo, tamanioRegistro, 1, pequipo);

    fclose(pequipo);

    if (escribio != 1)
    {
        cout << "Error al escribir el registro." << endl;
        return -1;
    }

    cout << "Registro agregado correctamente." <<endl<< endl;
    return escribio;
}

bool ArchivoEquipo::ListarRegistros() {//revisado

    bool flagTodosInactivos = true;
    bool flagTodosActivos = true;
    Equipo obj;
    FILE *p;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        return false;
    }

    int opc;
    bool salir=false;
    while(!salir)
    {
    cout<<"Quiere Listar:"<<endl<<"0. Inactivos"<<endl<<"1.Activos"<<endl<<"2. Volver"<<endl<<endl ;
    cout<<"Su opcion: "<<endl;
    cin.ignore(10000, '\n');
    cin>>opc;
    if (cin.fail())
    {
        opc=-1;
        cin.clear();
    }
    switch(opc)
    {
      case 0:
             system("pause");
             system("cls");
              while(fread(&obj, tamanioRegistro, 1, p))
              {
                  if (!obj.getEstado())
                  {
                      flagTodosActivos = false;
                      obj.Mostrar();
                  }
              }
              if (flagTodosActivos)
              {
                  cout << "Error: No hay registros inactivos" << endl;
              }
              salir=true;
              break;
      case 1:
            system("pause");
            system("cls");
            while(fread(&obj, tamanioRegistro, 1, p))
            {
                  if (obj.getEstado())
                  {
                      flagTodosInactivos = false;
                      obj.Mostrar();
                  }
            }
            if (flagTodosInactivos)
            {
             cout << "Error: No hay registros activos" << endl;
            }
            salir=true;
            break;
        case 2:
            cout<<"Volviendo"<<endl;
            salir=true;
            break;

        default:
               cout<<"Ingrese una opcion valida"<<endl;
               system("pause");
               system("cls");
               break;
    }
    }
    fclose(p);
    return 1;
}

void ArchivoEquipo::ListarPorTipo(int _tipo) {//revisado
    Equipo equipo;
    FILE *pequipo = fopen(nombreRuta, "rb");

    if (pequipo == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    bool encontrado = false;

    while (fread(&equipo, tamanioRegistro, 1, pequipo) == 1) {
        //  Comparar tipo, evitar eliminados y registros inv�lidos (ID 0)
        if ( equipo.getTipo() == _tipo && equipo.getEstado())
        {
            equipo.Mostrar();
            encontrado = true;
        }
    }

    fclose(pequipo);

    if (!encontrado) {
        cout << "No se encontraron equipos del tipo \"" << _tipo << "\"." << endl;
    }
}

///METODOS

void ArchivoEquipo::ListarPorID(int id){//revisado
    Equipo obj;
    int pos;
    FILE *p;

    pos = BuscarPosicionPorId(id, obj);
    if (pos == -1)
    {
        cout<<"registro no existe"<<endl;
        return;
    }

    p = fopen(nombreRuta, "rb");
    if (p==nullptr)
    {
        cout<<"error de apertura"<<endl;
        return;
    }

    fseek(p, tamanioRegistro*pos, SEEK_CUR);
    fread(&obj, tamanioRegistro, 1, p);


    if(obj.getEstado())
    {
        obj.Mostrar();
    } else
    {
        cout << "Error: Registro inactivo" << endl;
    }

    fclose(p);
}

int ArchivoEquipo::BuscarPosicionPorId(int idBuscado, Equipo& equipo) {//revisado
    FILE *pequipo = fopen(nombreRuta, "rb");
    if (pequipo==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return 0;
    }

    int pos = 0;

    while (fread(&equipo, tamanioRegistro, 1, pequipo) == 1) {
        if (equipo.getIdEquipo() == idBuscado)
        {
            fclose(pequipo);
            return pos;
        }
        pos++;
    }

    fclose(pequipo);
    return -1;
}


bool ArchivoEquipo::MenuModificarEquipo(int id){//revisado
    Equipo obj;

    int _tipo;
    char _marca[30];
    int _stock;
    float _precio;

    int opc;
    bool salir = false;

    FILE *p;

    p = fopen(nombreRuta, "rb+");
    if (p==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    fseek(p, tamanioRegistro*(id-1), SEEK_CUR);
    fread(&obj, tamanioRegistro, 1, p);


    if (!obj.getEstado())
    {
        cout << "Error: perfil dado de baja." << '\n';
        fclose(p);
        return false;
    }
    bool incorrecto = false;
    while(!salir){
        system("cls");
        cout << " ----------------------------------- " << endl;
        cout << "|   Elija el Atributo a Modificar:  |" << endl;
        cout << " ----------------------------------- " << endl;
        cout << "|                                   |" << endl;
        cout << "|          1 - Tipo                 |" << endl;
        cout << "|          2 - Marca                |" << endl;
        cout << "|          3 - Stock                |" << endl;
        cout << "|          4 - Precio               |" << endl;
        cout << "|          0 - Salir                |" << endl;
        cout << "|                                   |" << endl;
        cout << " ----------------------------------- " << endl;
        cout<<"  opcion: ";
        cin>>opc;

        if(cin.fail())
        {
            cin.clear();
            cin.ignore(10000,'\n');
            opc = -1;
        }

        switch(opc){

            case 1:  //tipo
                do{

                    incorrecto = false;

                    cout<<"Ingrese nuevo tipo: ";
                    cin >> _tipo;

                    if (cin.fail()||_tipo<=0)
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese valor numerico o Positivo." << endl;
                        incorrecto = true;
                    }

                }
                while(incorrecto);

                cin.ignore();
                obj.setTipo(_tipo);
                AgregarRegistroModificado(obj);
                system("pause");
            break;

            case 2:  //marca
                cin.ignore(10000, '\n');

                cout<<"Ingrese nueva marca: ";
                cin.getline(_marca,30);
                obj.setMarca(_marca);
                AgregarRegistroModificado(obj);
                system("pause");
            break;
            case 3:  //stock

                do{

                    incorrecto = false;

                    cout<<"Ingrese nuevo stock: ";
                    cin >> _stock;

                    if (cin.fail() || _stock <= 0)
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese valor numerico o mayor a 0." << endl; //escriban el mensaje que quieran
                        incorrecto = true;
                    }

                }
                while(incorrecto);

                obj.setStock(_stock);
                AgregarRegistroModificado(obj);
                system("pause");
            break;

            case 4:  //precio

                do{

                    incorrecto = false;

                    cout<<"Ingrese nuevo precio: $";
                    cin >> _precio;

                    if (cin.fail() || _precio <= 0)
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese valor numerico o mayor a 0." << endl; //escriban el mensaje que quieran
                        incorrecto = true;
                    }

                }
                while(incorrecto);

                obj.setPrecio(_precio);
                AgregarRegistroModificado(obj);
                system("pause");
            break;

            case 0:
                cout<<"saliendo del modificar, muchas gracias"<<endl;
                salir = true;
            break;

            default:
                cout<<"ingrese opcion correcta"<<endl;
                system("pause");
            break;
        }
        cout<<endl;

    }
    fclose(p);
    return true;
}

///GETTERS

//autogenerar id al agregar registro
int ArchivoEquipo::ObtainNewID() {//revisado
    return CantidadRegistros() + 1;
}

int ArchivoEquipo::CantidadRegistros(){//revisado
    FILE *pfile;
    pfile=fopen(nombreRuta, "rb");
    int cantidad;
    if(pfile==nullptr)
    {
        return 0;
    }
    fseek(pfile,0,SEEK_END);
    cantidad=ftell(pfile) / sizeof(Equipo);
    fclose(pfile);
    return cantidad;
}

void ArchivoEquipo::AgregarRegistroModificado(Equipo& obj){
    FILE *p;

    p = fopen(nombreRuta, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    fseek(p, tamanioRegistro*(obj.getIdEquipo() - 1), SEEK_SET);

    if(fwrite(&obj, tamanioRegistro, 1, p))
    {
        cout<<"Registro Modificado Exitosamente" << endl;
    }
    else
    {
        cout<<"Registro NO Modificado, ALGO SALIO MAL" << endl;
    }


    fclose(p);
}

bool ArchivoEquipo::BajaLogica(int id){//revisado
    Equipo obj;
    FILE *p;
    p = fopen(nombreRuta, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    fseek(p, tamanioRegistro*(id-1), 0);
    fread(&obj, tamanioRegistro, 1, p);

    if (!obj.getEstado())
    {
        cout << "Error: Equipo ya dado de baja" << '\n';
        return 0;
    }

    obj.setEstado(false);

    AgregarRegistroModificado(obj);

    fclose(p);

    return true;
}

void ArchivoEquipo::RankingdeEquiposMasVendidos(){//revisado
    ArchivoVenta GVenta;
    Equipo obj;
    Equipo *ArrayEquipos;
    int tam = CantidadRegistros();
    ArrayEquipos = new Equipo[tam];

    FILE *p;
    p = fopen(nombreRuta, "rb");

    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    for(int i = 0; i < tam; i++){
        fread(&ArrayEquipos[i], tamanioRegistro, 1, p);
    }

    for(int i = 0; i < tam-1; i++){
        for(int j = i+1; j < tam; j++){
            if(GVenta.CantidadVendidaDeEquipo(ArrayEquipos[i].getIdEquipo()) < GVenta.CantidadVendidaDeEquipo(ArrayEquipos[j].getIdEquipo())){
                obj = ArrayEquipos[i];
                ArrayEquipos[i] = ArrayEquipos[j];
                ArrayEquipos[j] = obj;
            }
        }
    }

    for(int i = 0; i < tam; i++){
        cout << "Top "<<i+1<<": " << '\n';
        ArrayEquipos[i].Mostrar();
        cout << "Cantidad Vendida: " << GVenta.CantidadVendidaDeEquipo(ArrayEquipos[i].getIdEquipo()) << '\n'<< '\n';
    }

    fclose(p);
}

void ArchivoEquipo::EquiposNoVendidos(){//revisado
    ArchivoVenta GVenta;
    Equipo obj;

    FILE *p;
    p = fopen(nombreRuta, "rb");

    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    cout << "Equipo sin ventas registradas: " << '\n' << '\n';
    while(fread(&obj, tamanioRegistro, 1, p)){
        if (GVenta.CantidadVendidaDeEquipo(obj.getIdEquipo()) == 0){
            obj.Mostrar();
            cout << "Cantidad vendida: " << GVenta.CantidadVendidaDeEquipo(obj.getIdEquipo()) << '\n' << '\n';
        }
    }

    fclose(p);
}

bool ArchivoEquipo::VerificarActivo(int _id){
  Equipo equipito;
  FILE *p;
    p = fopen(nombreRuta, "rb");

    while(fread(&equipito, tamanioRegistro, 1, p)){
        if(_id==equipito.getIdEquipo())
        {
            fclose(p);
            return equipito.getEstado();
        }
    }
    fclose(p);
    return false;
}

bool ArchivoEquipo::VerificarDuplicado(int id){//revisado
    Equipo obj;

    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(id == obj.getIdEquipo())
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}
