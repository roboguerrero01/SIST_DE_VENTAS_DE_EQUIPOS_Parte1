#include<iostream>
#include<cstring>
#include"clienteJuridico.h"
using namespace std;

ClienteJuridico::ClienteJuridico(){
    Estado = true;
}

void ClienteJuridico::setIdClienteJuridico(int _id){
    IdClienteJuridico = _id;
}

void ClienteJuridico::setCuit(const char* _cuit){
    strcpy(Cuit, _cuit);
}

void ClienteJuridico::setNombreEmpresa(const char* _nombreEmpresa){
    strcpy(NombreEmpresa, _nombreEmpresa);
}

void ClienteJuridico::setDireccion(const char* _direccion){
    strcpy(Direccion, _direccion);
}

void ClienteJuridico::setEstado(bool _estado){
    Estado = _estado;
}

int ClienteJuridico::getIdClienteJuridico(){ return IdClienteJuridico; }
const char* ClienteJuridico::getCuit(){ return Cuit; }
const char* ClienteJuridico::getNombreEmpresa(){ return NombreEmpresa; }
const char* ClienteJuridico::getDireccion(){ return Direccion; }
bool ClienteJuridico::getEstado(){ return Estado; }

bool ClienteJuridico::Cargar(const char* cuit, int id){
    strcpy(Cuit, cuit);
    bool errorDeIngreso = false;

    cout << "Ingresa Nombre Empresa: ";
    cin.getline(NombreEmpresa, 50);

    do{
        errorDeIngreso = false;
        cin.clear();
        cout << "Ingresa Direccion: ";
        cin.getline(Direccion, 100);

        for(int i=0; Direccion[i] != '\0'; i++)
        {
            // si no esta en el rango de mayusculas, minusculas, numeros o espacio en ASCII.
            if(!(Direccion[i]>64 && Direccion[i]<91 || Direccion[i]>96 && Direccion[i]<123 || (int)Direccion[i] > 47 && (int)Direccion[i] < 58))
            {
                errorDeIngreso = true;
                cout << "Error de ingreso. No se permiten simbolos ni numeros negativos" << '\n';
                break;
            }
        }
    }while(errorDeIngreso);

    IdClienteJuridico = id;
    cout << "Su ID Cliente Juridico asignado es: " << IdClienteJuridico << endl;
    cout << "Cliente juridico cargado." << '\n';
    return true;
}


void ClienteJuridico::Mostrar(){
    cout << endl;
    cout << " Cliente Juridico [ ID: " << IdClienteJuridico << " ]" << "     [ Estado: " << Estado << " ]" << endl;
    cout << "----------------------------------------- " << endl;
    cout << " Nombre Empresa: " << NombreEmpresa << endl;
    cout << " Cuit: " << Cuit << endl;
    cout << " Direccion: " << Direccion << endl;
    cout << "----------------------------------------- " << endl << endl;
}


