#include"Vendedor.h"
# include<iostream>
using namespace std;

Vendedor::Vendedor(){}


Vendedor::Vendedor();

void Vendedor::setLegajo(int _legajo){ Legajo = _legajo; }
void Vendedor::setIngreso(Fecha _fechaDeIngreso){ FechaDeIngreso = _fechaDeIngreso; }
void Vendedor::setSueldo(float _sueldo){ Sueldo = _sueldo; }

int Vendedor::getLegajo(){ return Legajo; }
Fecha Vendedor::getIngreso(){ return FechaDeIngreso; }
float Vendedor::getSueldo(){ return Sueldo; }

void Vendedor::Cargar(int id){
    Fecha objF;
    float _sueldo;
    bool errordeingreso;
    cout << " ------ Ingrese datos del Vendedor ------ " << '\n';
    Persona::Cargar();
    cout << " - Ingrese la fecha de ingreso " << '\n';
    objF.Cargar();
    setIngreso(objF);
    do{

        errordeingreso=false;
        cout << " - Ingrese el sueldo: $";
        cin >> _sueldo;
        if( cin.fail() || _sueldo<0 )
        {
          errordeingreso=true;
          cout<<"ERROR, ingrese nuevamente un valor positivo numerico"<<endl;
          cin.clear();
          cin.ignore(10000,'\n');
        }
    }while(errordeingreso);
    setSueldo(_sueldo);
    cout<<endl;


    setLegajo(id);
    cout << " - Legajo asignado = " << getLegajo() << '\n';
}


void Vendedor::Mostrar(){
    Fecha obj = getIngreso();
    cout << "-------------------------------------------- " << endl;
    cout << " VENDEDOR [ LEGAJO: " << getLegajo() << " ]" << endl;
    cout << "-------------------------------------------- " << endl;
    cout << " Fecha de ingreso: ";
    obj.Mostrar();
    cout << " Sueldo: " << getSueldo() << endl;
    cout << "-------------------------------------------- " << endl;
    cout << "                -INFO PERSONA-               " << endl;
    Persona::Mostrar();
    cout << "-------------------------------------------- " << endl<<endl;
}
