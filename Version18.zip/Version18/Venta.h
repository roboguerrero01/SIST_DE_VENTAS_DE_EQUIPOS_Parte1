#pragma once
#include "Fecha.h"
#include"DetalleDeVentas.h"
#include"archivo_equipo.h"
#include"archivo_Vendedor.h"
#include"archivo_clienteFisico.h"
#include"archivo_clienteJuridico.h"


class Venta{
  private:
      int IdVenta;
      bool Estado;
      Fecha FechaDeVenta;
      int LegajoVendedor;
      int IdCliente;

  public:
      Venta();

      void setIDventa(int);
      void setEstado(bool);
      void setFechadeVenta(Fecha);
      void setLegajoVendedor(int);
      void setIdCliente(int);

      int getIDventa();
      bool getEstado();
      Fecha getFechadeVenta();
      int getLegajoVendedor();
      int getIdCliente();

      bool Cargar(int);
      void Mostrar();
};
