#include <iostream>
#include "menues.h"

/// Isra 2 - 10 Fabri /// All time re de hijo lo tengoooooo
/// Isra 0 - 4 Fabri /// 11/14/2025


using namespace std;

void menuGeneral(){
    DetalleDeVentas GDetalles;
    GDetalles.CargarCopiaDeSeguridad();

    int opcion;
    do
    {
        system("cls");
        cout << " --------------------------------------------------------- " << endl;
        cout << "|        BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS        |" << endl;
        cout << "|        =====         MENU GENERAL          =====        |" << endl;
        cout << " --------------------------------------------------------- " << endl;
        cout << "|                                                         |" << endl;
        cout << "|            1- Menu CLIENTES FISICOS/JURIDICOS.          |" << endl;
        cout << "|            2- Menu EQUIPOS.                             |" << endl;
        cout << "|            3- Menu VENDEDORES.                          |" << endl;
        cout << "|            4- Menu de VENTAS.                           |" << endl;
        cout << "|                                                         |" << endl;
        cout << "|            0- SALIR DEL PROGRAMA.                       |" << endl;
        cout << "|                                                         |" << endl;
        cout << " --------------------------------------------------------- " << endl;
        cout << endl << "              Ingrese Opcion: ";
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion=-1;
        }

        bool salirMenuClientes = false;
        int OpcionMenuClientes;
        switch(opcion){
            case 1:
                while (!salirMenuClientes)
                {
                    system("cls");
                    cout << " ----------------------------------- " << endl;
                    cout << "|      Elige el Tipo de Cliente:    |" << endl;
                    cout << " ----------------------------------- " << endl;
                    cout << "|                                   |" << endl;
                    cout << "|           1 - FISICO.             |" << endl;
                    cout << "|           2 - JURIDICO.           |" << endl;
                    cout << "|                                   |" << endl;
                    cout << "|           0 - VOLVER.             |" << endl;
                    cout << "|                                   |" << endl;
                    cout << " ----------------------------------- " << endl;
                    cout << endl << "           opcion elegida: ";
                    cin >> OpcionMenuClientes;
                    cout << endl;
                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        OpcionMenuClientes = -1;
                    }

                    switch(OpcionMenuClientes)
                    {
                        case 1:
                            subMenuClientesFisicos();
                        break;

                        case 2:
                            subMenuClientesJuridicos();
                        break;

                        case 0:
                            salirMenuClientes = true;
                        break;

                        default:
                            cout << "Elija una opcion valida" << '\n';
                            system("pause");
                        break;
                    }
                }
                system("pause");
            break;

            case 2:
                subMenuEquipo();
                system("pause");
            break;

            case 3:
                subMenuVendedor();
                system("pause");
            break;

            case 4:
                subMenuVentas();
                system("pause");
            break;

            case 0:
                cout << "Saliendo del Programa, Vuelva Prontos." << endl;
                system("pause");
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);

}

void subMenuEquipo(){
    int opcion;
    int tipo;
    ArchivoEquipo obj;
    Equipo equi;
    bool incorrecto = false;
    do
    {
        int id=-1;
        system("cls");
        cout << " ---------------------------------------------------------- " << endl;
        cout << "|         BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS        |" << endl;
        cout << "|         =====        MENU DE EQUIPOS        =====        |" << endl;
        cout << " ---------------------------------------------------------- " << endl;
        cout << "|                                                          |" << endl;
        cout << "|                1- ALTA                                   |" << endl;
        cout << "|                2- BAJA                                   |" << endl;
        cout << "|                3- MODIFICAR                              |" << endl;
        cout << "|                4- LISTAR TODOS ACTIVOS/INACTIVOS         |" << endl;
        cout << "|                5- LISTAR POR ID                          |" << endl;
        cout << "|                6- LISTAR POR TIPO                        |" << endl;
        cout << "|                7- RANKING EQUIPOS MAS VENDIDOS           |" << endl;
        cout << "|                8- EQUIPOS NO VENDIDOS                    |" << endl;
        cout << "|                                                          |" << endl;
        cout << "|                0- VOLVER AL MENU GENERAL.                |" << endl;
        cout << "|                                                          |" << endl;
        cout << " ---------------------------------------------------------- " << endl;
        cout << endl << "                   Ingrese Opcion: ";
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion = -1;
        }
        switch(opcion){

            case 1:
                system("cls");
                equi.Cargar(obj.ObtainNewID());
                obj.AgregarRegistro(equi);
                system("pause");
            break;

            case 2:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa id a dar de baja: ";
                    cin >> id;

                    if(!(0 < id && id <= obj.CantidadRegistros() )){
                        incorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico o mayor que 0..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.BajaLogica(id);
                system("pause");
            break;

            case 3:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa id a modificar: ";
                    cin >> id;

                    if(!(0 < id && id <= obj.CantidadRegistros() )){
                        incorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.MenuModificarEquipo(id);
                system("pause");
            break;

            case 4:
                system("cls");
                obj.ListarRegistros();
                system("pause");
                break;

            case 5:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa el id a buscar: ";
                    cin >> id;

                    if(!(0 < id && id <= obj.CantidadRegistros() )){
                        incorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.ListarPorID(id);
                system("pause");
            break;

            case 6:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa el tipo a buscar: ";
                    cin >> tipo;

                    if (cin.fail()||tipo<=0)
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.ListarPorTipo(tipo);
                system("pause");
            break;

            case 7:
                system("cls");
                obj.RankingdeEquiposMasVendidos();
                system("pause");
                break;

            case 8:
                system("cls");
                obj.EquiposNoVendidos();
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL...." << endl;
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);

}

void subMenuClientesFisicos(){
    char cuil[12];
    int opcion;
    int id;
    ArchivoClienteFisico archi;
    ArchivoClienteJuridico GJuridico;
    ClienteFisico comprador;
    bool incorrecto = false;
    do
    {
        system("cls");
        cout << " -------------------------------------------------------------- " << endl;
        cout << "|           BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS          |" << endl;
        cout << "|           =====    MENU DE CLIENTES FISICO    =====          |" << endl;
        cout << " -------------------------------------------------------------- " << endl;
        cout << "|                                                              |" << endl;
        cout << "|            1- ALTA                                           |" << endl;
        cout << "|            2- BAJA LOGICA                                    |" << endl;
        cout << "|            3- MODIFICAR                                      |" << endl;
        cout << "|            4- LISTAR TODOS LOS REGISTROS ACTIVOS/INACTIVOS   |" << endl;
        cout << "|            5- MOSTRAR REGISTRO POR ID                        |" << endl;
        cout << "|            6- BUSCAR REGISTRO POR CUIL                       |" << endl;
        cout << "|            7- CLIENTE QUE MAS GASTO                          |" << endl;
        cout << "|                                                              |" << endl;
        cout << "|            0- VOLVER AL MENU GENERAL.                        |" << endl;
        cout << "|                                                              |" << endl;
        cout << " -------------------------------------------------------------- " << endl;
        cout << endl <<"                  Ingrese Opcion: ";
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion=-1;
        }
        switch(opcion){
            case 1:
                system("cls");
                cout << "\n--- Cargando datos del cliente fisico ---" << endl;
                cin.ignore();
                do{
                    incorrecto = false;

                    cout << "Ingrese su CUIL: ";
                    cin >> cuil;

                    for(int i=0; cuil[i] != '\0'; i++)
                    {
                        if((int)cuil[0]==48) ///que el primer numero no sea 0
                        {
                            incorrecto=true;
                            break;
                        }
                        if(!((int)cuil[i] < 58 && (int)cuil[i] > 47))
                        {
                            incorrecto = true;
                            break;
                        }
                    }

                    if (archi.CantidadRegistros()){
                        if (archi.VerificarDuplicado(cuil)) {
                            cout << "Ya existe el usuario." << endl;
                            incorrecto = true;
                        }
                    }

                    if (incorrecto)
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERRROR, ingrese un valor numerico positivo y que no empiece por 0..."  << endl;
                    }

                }while(incorrecto);

                if(comprador.Cargar(cuil, archi.ObtainNewID())){
                    archi.AgregarRegistro(comprador);
                }
                system("pause");
            break;

            case 2:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingrese ID del perfil a dar De Baja: ";
                    cin >> id;

                    if(!(0 < id && id <= archi.CantidadRegistros() + GJuridico.CantidadRegistros())){
                        incorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                archi.BajaLogica(id);
                system("pause");
            break;

            case 3:
                system("cls");
                cin.ignore();

                do{

                    incorrecto = false;

                    cout<<"Ingrese ID de perfil a modificar: ";
                    cin >> id;

                    if(!(0 < id && id <= archi.CantidadRegistros() + GJuridico.CantidadRegistros())){
                        incorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                archi.MenuModificarClienteFisico(id);
                system("pause");
            break;

            case 4:
                system("cls");
                if (!archi.ListarRegistros()){
                    cout << "Archivo vacio." << '\n';
                }
                system("pause");
            break;

            case 5:
                system("cls");
                int id;

                do{

                    incorrecto = false;

                    cout<<"ingrese id: ";
                    cin >> id;

                    if(!(0 < id && id <= archi.CantidadRegistros() + GJuridico.CantidadRegistros())){
                        incorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "opcion incorrecta, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                cin.ignore();
                archi.MostrarClientePorID(id);
                system("pause");
            break;

            case 6:
                cin.ignore();
                system("cls");
                do{
                    incorrecto = false;

                    cout<<"ingrese CUIL para buscar: ";
                    cin.getline(cuil,20);
                    cin.clear();
                    for(int i=0; cuil[i] != '\0'; i++)
                    {
                        if(!((int)cuil[i] < 58 && (int)cuil[i] > 47))
                        {
                            incorrecto = true;
                            cout << "opcion incorrecta, ingrese un valor numerico..." << endl;
                        }
                    }
                }while(incorrecto);
                archi.MostrarClientePorCUIL(cuil);
                system("pause");
            break;

            case 7:
                system("cls");
                archi.ClientequeMasGasto();
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL..." << endl;
                system("pause");
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);
}

void subMenuClientesJuridicos(){
    int opcion;
    ArchivoClienteJuridico archi;
    ArchivoClienteFisico GFisico;
    ClienteJuridico comprador;
    char cuit[12];
    bool incorrecto = false;
    do
    {   int id=-1;
        system("cls");
        cout << " ------------------------------------------------------------------- " << endl;
        cout << "|              BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS            |" << endl;
        cout << "|              =====   MENU DE CLIENTES JURIDICO   =====            |" << endl;
        cout << " ------------------------------------------------------------------- " << endl;
        cout << "|                                                                   |" << endl;
        cout << "|              1- ALTA                                              |" << endl;
        cout << "|              2- BAJA LOGICA                                       |" << endl;
        cout << "|              3- MODIFICAR                                         |" << endl;
        cout << "|              4- LISTAR TODOS LOS REGISTROS ACTIVOS/INACTIVOS      |" << endl;
        cout << "|              5- MOSTRAR REGISTRO POR ID                           |" << endl;
        cout << "|              6- BUSCAR REGISTRO POR CUIT                          |" << endl;
        cout << "|              7- CLIENTE QUE MAS GASTO                             |" << endl;
        cout << "|                                                                   |" << endl;
        cout << "|              0- VOLVER AL MENU GENERAL.                           |" << endl;
        cout << "|                                                                   |" << endl;
        cout << " ------------------------------------------------------------------- " << endl;
        cout << endl << "                   Ingrese Opcion: ";
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion=-1;
        }
        switch(opcion)
        {
            case 1:
                system("cls");
                cin.ignore();
                do{

                    incorrecto = false;
                    cin.clear();
                    cout << "Ingrese Cuit: ";
                    cin.getline(cuit,12);

                     for(int i=0; cuit[i] != '\0'; i++)
                     {
                        if((int)cuit[0]==48) ///que el primer numero no sea 0
                        {
                            incorrecto=true;
                            cout << "ERRROR, ingrese un valor numerico positivo y que no empiece por 0..." << endl;
                            break;
                        }
                        if (cuit[i] < '0' || cuit[i] > '9')
                        {
                            incorrecto = true;
                            cout << "ERRROR, ingrese un valor numerico positivo y que no empiece por 0..." << endl;
                            break;
                        }
                     }
                    if (archi.CantidadRegistros())
                    {
                        if (archi.VerificarDuplicado(cuit)) {
                            cout << "Ya existe el usuario." << endl;
                            incorrecto = true;
                        }
                    }

                }while(incorrecto);

                if(comprador.Cargar(cuit, archi.ObtainNewID())){
                    archi.AgregarRegistro(comprador);
                }

                system("pause");
            break;

            case 2:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingrese ID del perfil a dar De Baja: ";
                    cin >> id;

                    if(!(0 < id && id <= archi.CantidadRegistros() + GFisico.CantidadRegistros())){
                        incorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                archi.BajaLogica(id);
                system("pause");
            break;

            case 3:
                system("cls");

                cin.ignore();

                do{

                    incorrecto = false;
                    cout<<"Ingrese ID del cliente a modificar: ";
                    cin >> id;

                    if(!(0 < id && id <= archi.CantidadRegistros() + GFisico.CantidadRegistros())){
                        incorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }


                }while(incorrecto);

                archi.MenuModificarClienteJuridico(id);
                system("pause");
            break;

            case 4:
                system("cls");
                if (!archi.ListarRegistros())
                {
                    cout << "Archivo vacio." << '\n';
                }
                system("pause");
                break;

            case 5:
                system("cls");

                do{

                    incorrecto = false;

                    cout << "Ingrese id a buscar: ";
                    cin >> id;

                    if(!(0 < id && id <= archi.CantidadRegistros() + GFisico.CantidadRegistros())){
                        incorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                cin.ignore();
                archi.MostrarClientePorID(id);
                system("pause");
            break;

            case 6:
                system("cls");
                cin.ignore(10000,'\n');
                do{

                    incorrecto = false;
                    cin.clear();
                    cout<<"ingrese CUIT para buscar: ";
                    cin.getline(cuit,20);

                    for(int i=0; cuit[i] != '\0'; i++)
                     {
                        if((int)cuit[0]==0)
                        {
                            incorrecto = true;
                            break;
                        }
                        if (cuit[i] < '0' || cuit[i] > '9')
                        {
                            incorrecto = true;
                            cout << "ERROR, ingrese un valor numerico..." << endl;
                            break;
                        }
                     }
                }while(incorrecto);
                archi.MostrarClientePorCUIT(cuit);
                system("pause");
            break;

            case 7:
                system("cls");
                archi.ClientequeMasGasto();
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL..." << endl;
                system("pause");
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);
}

void subMenuVendedor(){
 int opcion;
 Vendedor vendedorcito;
 ArchivoVendedor obj;
 ArchivoEquipo GEquipo;
 bool incorrecto = false;
 int _id;
 do{
        int legajo=-1;
        system("cls");
        cout << " -------------------------------------------------------------- " << endl;
        cout << "|          BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS           |" << endl;
        cout << "|          =====       MENU DE VENDEDORES      =====           |" << endl;
        cout << " -------------------------------------------------------------- " << endl;
        cout << "|                                                              |" << endl;
        cout << "|                1- ALTA                                       |" << endl;
        cout << "|                2- BAJA                                       |" << endl;
        cout << "|                3- MODIFICAR                                  |" << endl;
        cout << "|                4- LISTAR TODOS ACTIVOS/INACTIVOS             |" << endl;
        cout << "|                5- LISTAR POR LEGAJO                          |" << endl;
        cout << "|                6- VENDEDOR QUE MAS RECAUDO                   |" << endl;
        cout << "|                7- PRODUCTO QUE MAS SE VENDIO POR VENDEDOR    |" << endl;
        cout << "|                                                              |" << endl;
        cout << "|                0- VOLVER AL MENU GENERAL.                    |" << endl;
        cout << "|                                                              |" << endl;
        cout << " -------------------------------------------------------------- " << endl;
        cout << endl << "                      Ingrese Opcion: ";
        cin >> opcion;
        cout << endl;
        if (cin.fail())
        {
         cin.clear(); //limpia error de cin
         cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
         opcion=-1;
        }
        switch(opcion)
        {
            case 1:
                system("cls");
                vendedorcito.Cargar(obj.ObtainNewLegajo());
                obj.AgregarRegistro(vendedorcito);
                system("pause");
            break;

            case 2:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa Legajo a dar de baja: ";
                    cin >> legajo;

                    if(!(0 < legajo && legajo <= obj.CantidadRegistros() )){
                        incorrecto = true;
                        cout << "ERROR, No existe vendedor con ese legajo..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese un valor numerico..." << endl;
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.BajaLogica(legajo);
                system("pause");
            break;

            case 3:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa id a modificar: ";
                    cin >> legajo;

                    if(!(0 < legajo && legajo <= obj.CantidadRegistros() )){
                        incorrecto = true;
                        cout << "ERROR, No existe vendedor con ese legajo..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese valor numerico." << endl; //escriban el mensaje que quieran
                        incorrecto = true;
                    }

                }while(incorrecto);

                obj.MenuModificarVendedor(legajo);
                system("pause");
            break;

            case 4:
                system("cls");
                obj.ListarRegistros();
                system("pause");
            break;

            case 5:
                system("cls");

                do{

                    incorrecto = false;

                    cout<<"Ingresa el legajo a buscar: ";
                    cin >> legajo;

                    if(!(0 < legajo && legajo <= obj.CantidadRegistros() )){
                        incorrecto = true;
                        cout << "ERROR, No existe vendedor con ese legajo..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese valor numerico." << endl; //escriban el mensaje que quieran
                        incorrecto = true;
                    }

                }while(incorrecto);
                cout<<endl;
                obj.ListarPorLegajo(legajo);
                system("pause");
            break;

            case 6:
                system("cls");
                obj.VendedorMasRecaudo();
                system("pause");
            break;

            case 7:


                system("cls");
                do{
                    incorrecto = false;
                    cout<<"Ingrese el id del Equipo para buscar su vendedor estrella."<<endl;
                    cin >> _id;


                    if(!(0 < _id && _id <= GEquipo.CantidadRegistros() )){
                        incorrecto = true;
                        cout << "ERROR, No existe ese equipo..." << endl;
                    }

                    if (cin.fail())
                    {
                        cin.clear();
                        cin.ignore(10000, '\n');
                        cout << "ERROR, ingrese valor numerico." << endl; //escriban el mensaje que quieran
                        incorrecto = true;
                    }
                } while(incorrecto);

                obj.VendedorMasVendioUnEquipo(_id);
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL...." << endl;
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);
}

void subMenuVentas(){
 int opcion;
 Fecha anio;
 int anito;
 Venta ventita;
 ArchivoVenta obj;
 bool IDincorrecto = false;
 do{
        int id=-1;
        system("cls");
        cout << " -------------------------------------------------------- " << endl;
        cout << "|        BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS       |" << endl;
        cout << "|        =====          MENU DE VENTAS       =====       |" << endl;
        cout << " -------------------------------------------------------- " << endl;
        cout << "|                                                        |" << endl;
        cout << "|              1- ALTA                                   |" << endl;
        cout << "|              2- BAJA                                   |" << endl;
        cout << "|              3- MODIFICAR                              |" << endl;
        cout << "|              4- LISTAR VENTAS ACTIVOS/INACTIVOS        |" << endl;
        cout << "|              5- LISTAR VENTAS POR ANIO                 |" << endl;
        cout << "|              6- RECAUDACION TOTAL POR ANIO             |" << endl;
        cout << "|                                                        |" << endl;
        cout << "|              0- VOLVER AL MENU GENERAL.                |" << endl;
        cout << "|                                                        |" << endl;
        cout << " -------------------------------------------------------- " << endl;
        cout <<endl<< "Ingrese Opcion: ";
        cin >> opcion;
        if (cin.fail())
        {
            cin.clear(); //limpia error de cin
            cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
            opcion=-1;
        }
        switch(opcion)
        {
            case 1:
                system("cls");
                if (ventita.Cargar(obj.ObtainNewID()))
                {
                    obj.AgregarRegistro(ventita);
                }
                system("pause");
            break;

            case 2:
                system("cls");
                do{ // VALIDACION

                    IDincorrecto = false;

                    cout<<"Ingresa Id de la venta a dar de baja: ";
                    cin >> id;

                    if(!(0 < id && id <= obj.CantidadRegistros() )){
                        IDincorrecto = true;
                        cout << "ERROR, No existe venta con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cout << "ERROR, no uses letras por favor" << endl;
                        cin.clear();
                        cin.ignore(10000, '\n');
                        IDincorrecto = true;
                    }

                }while(IDincorrecto);

                obj.BajaLogica(id);
                system("pause");
            break;

            case 3:
                system("cls");

                do{ // VALIDACION

                    IDincorrecto = false;

                    cout<<"Ingresa id de la venta a modificar: ";
                    cin >> id;

                    if(!(0 < id && id <= obj.CantidadRegistros() )){
                        IDincorrecto = true;
                        cout << "ERROR, No existe cliente con ese id..." << endl;
                    }

                    if (cin.fail())
                    {
                        cout << "ERROR, no uses letras." << endl;
                        cin.clear();
                        cin.ignore(10000, '\n');
                        IDincorrecto = true;
                    }

                }while(IDincorrecto);

                obj.ModificarFechaDeVenta(id);
                system("pause");
            break;

            case 4:
                system("cls");
                obj.ListarRegistros();
                system("pause");
            break;

            case 5:
                system("cls");
                do{
                    cout<<"Ingresa el anio para listar las Ventas: ";
                    cin >> anito;
                } while (!anio.SetAnio(anito));
                obj.ListarPorAnio(anio);
                system("pause");
            break;

            case 6:
                system("cls");
                do{
                    cout<<"Ingresa el anio para listar la recaudacion de las Ventas: ";
                    cin >> anito;
                } while (!anio.SetAnio(anito));
                obj.RecaudacionTotalPorAnio(anio);
                system("pause");
            break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL...." << endl;
            break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
            break;
        }
    }while(opcion != 0);
}
