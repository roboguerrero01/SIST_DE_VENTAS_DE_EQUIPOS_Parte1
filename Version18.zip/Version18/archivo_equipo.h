#pragma once
#include "equipo.h"

class ArchivoEquipo {
  private:
      char nombreRuta[30];
      int tamanioRegistro;

  public:
      ArchivoEquipo();

      bool VerificarDuplicado(int);
      void AgregarRegistroModificado(Equipo&); /// LO USA LA FUNCION MENU MODIFICAR EQUIPO
      int BuscarPosicionPorId(int, Equipo&); /// LO USA LA FUNCION LISTAR X ID
      int ObtainNewID();
      int CantidadRegistros();
      bool VerificarActivo(int);

      int AgregarRegistro(Equipo&); /// OPCION 1
      bool BajaLogica(int); /// OPCION 2
      bool MenuModificarEquipo(int); /// OPCION 3
      bool ListarRegistros(); /// OPCION 4
      void ListarPorID(int); /// OPCION  5
      void ListarPorTipo(int); /// OPCION 6
      void RankingdeEquiposMasVendidos(); /// OPCION 7
      void EquiposNoVendidos(); /// OPCION 8
};
