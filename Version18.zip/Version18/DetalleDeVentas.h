#pragma once

// "DetalleDeVentas.dat"
// "DetalleDeVentasCopia.dat"

class DetalleDeVentas{
  private:
      int IdDetalleDeVenta;
      int IdVenta;
      int IdEquipo;
      int Cantidad;
      float PrecioUnitario;

  public:
      DetalleDeVentas();

      void setIdDetalleDeVenta(int);
      void setCantidad(int);
      void setPrecioUnitario(float);

      int getIdDetalleDeVenta();
      int getIdVenta();
      int getIdEquipo();
      int getCantidad();
      float getPrecioUnitario();

////Methods
      void Mostrar();
      bool Cargar(int, int); /// RECIBE EL ID DE LA VENTA Y EL ID DEL EQUIPO
      int ObtainNewID(int);
      int ContarRegistros(int);

      void GuardarEnArchivo(); /// Id Venta
      void CancelarDetallesDeVenta(int);
      void DevolverStock(int);
      void CopiaDeSeguridad(); /// Falta Implementar
      void CargarCopiaDeSeguridad(); /// Falta Implementar

      float RecaudacionVenta(int);
      int ContarVentasDeEquipo(int, int); // id venta, id equipo
};
