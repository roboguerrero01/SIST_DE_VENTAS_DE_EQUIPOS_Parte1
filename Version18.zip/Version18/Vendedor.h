#pragma once
#include "personas.h"
#include "fecha.h"

class Vendedor : public Persona{
  private:
      int Legajo;
      Fecha FechaDeIngreso;
      float Sueldo;

  public:
      Vendedor();

      void setLegajo(int);
      void setIngreso(Fecha);
      void setSueldo(float);

      int getLegajo();
      Fecha getIngreso();
      float getSueldo();

      void Cargar(int);
      void Mostrar();
};

