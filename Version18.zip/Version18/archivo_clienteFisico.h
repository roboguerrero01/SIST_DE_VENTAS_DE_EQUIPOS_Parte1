#pragma once
#include "clientesFisicos.h"
#include "archivo_clienteJuridico.h"
#include "fecha.h"
#include "clientesFisicos.h"

class ArchivoClienteFisico{
  private:
      char nombreRuta[30];
      int tamanioRegistro;

  public:
      ArchivoClienteFisico();

      bool VerificarDuplicado(const char*); /// LO USA LA FUNCION AGREGAR REGISTRO
      void AgregarRegistroModificado(ClienteFisico&); /// LO USA LA FUNCION MENU MODIFICAR CLIENTE
      bool BuscarClientePorID(int, ClienteFisico&); /// Funcion para corroborar si existe, LO USA LA FUNCION MOSTRAR CLIENTE X ID
      int ObtainNewID();
      int CantidadRegistros();
      int BuscarIdConCuil(const char*);
      bool VerificarActivo(int);


      void AgregarRegistro(ClienteFisico&); /// OPCION 1
      bool BajaLogica(int); /// OPCION 2
      void MenuModificarClienteFisico(int); /// OPCION 3
      bool ListarRegistros(); /// OPCION 4
      bool MostrarClientePorID(int); /// OPCION 5
      void MostrarClientePorCUIL(const char*); /// OPCION 6
      void ClientequeMasGasto(); /// OPCION 7
};
