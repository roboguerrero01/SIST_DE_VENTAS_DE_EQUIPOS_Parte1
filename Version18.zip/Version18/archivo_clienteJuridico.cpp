#include<iostream>
#include<cstring>
#include"archivo_clienteJuridico.h"
#include "archivo_Venta.h"
using namespace std;



ArchivoClienteJuridico::ArchivoClienteJuridico(){//revisado
    strcpy(nombreRuta, "archivoClienteJuridico.dat");
    tamanioRegistro = sizeof(ClienteJuridico);
}

bool ArchivoClienteJuridico::MostrarClientePorID(int id){//revisado
    ClienteJuridico obj;

    if (!BuscarClientePorID(id, obj))
    {
        cout<<"No hay registros cargados/guardados"<<endl;
        return false;
    }

    obj.Mostrar();
    return true;
}

void ArchivoClienteJuridico::MenuModificarClienteJuridico(int id){//revisado
    ClienteJuridico obj;
    char _cuit[12];
    char _nombreEmpresa[50];
    char _direccion[100];

    bool salir = false;
    bool errorDeIngreso = false;

    if (!BuscarClientePorID(id, obj))
    {
        cout<<"No hay registros cargados/guardados"<<endl;
        return;
    }

    if (!obj.getEstado())
    {
        salir = true;
        cout << "Error: perfil dado de baja." << '\n';
    }

    int opc;
    while(!salir)
    {
        system ("cls");
        cout << " ------------------------------------------------------ " << endl;
        cout << "               Perfil de " << obj.getNombreEmpresa() << endl;
        cout << " ------------------------------------------------------ " << endl;
        cout << "                 Elija el atributo a modificar: "<< endl << endl;
        cout << "                 1 - Cuit" << endl;
        cout << "                 2 - Nombre Empresa" << endl;
        cout << "                 3 - Direccion" << endl << endl;
        cout << "                 0 - Salir" << endl;
        cout << " ------------------------------------------------------ " << endl;
        cout << "                     opcion: ";
        cin>>opc;
        if(cin.fail())
        {
            cin.clear();
            cin.ignore(10000,'\n');
            opc = -1;
        }
//        cin.ignore();
        switch(opc)
        {
            case 1:  //Cuit
                cin.ignore(10000, '\n');
                do{

                    errorDeIngreso = false;
                    cin.clear();
                    cout << "Ingrese el cuit: ";
                    cin.getline(_cuit, 30);

                    for(int i=0; _cuit[i] != '\0'; i++)
                    {
                        // si no esta en el rango de numeros en ASCII.
                        if(!((int)_cuit[i] < 58 && (int)_cuit[i] > 47))
                        {
                            errorDeIngreso = true;
                            cout << "ERRROR, ingrese un valor numerico..." << endl;
                            break;
                        }
                    }

                }while(errorDeIngreso);

                obj.setCuit(_cuit);
                AgregarRegistroModificado(obj);
                system("pause");
            break;

            case 2:  //Nombre empresa
                cin.ignore(10000, '\n');
                do{
                    errorDeIngreso = false;
                    cin.clear();
                    cout << "Ingrese el Nombre: ";
                    cin.getline(_nombreEmpresa,30);

                    for(int i=0; _nombreEmpresa[i] != '\0'; i++)
                    {
                        // si no esta en el rango de mayusculas o minusculass en ASCII.
                        if(!(_nombreEmpresa[i]>64 && _nombreEmpresa[i]<91
                          || _nombreEmpresa[i]>96 && _nombreEmpresa[i]<123
                          || _nombreEmpresa[i]>='0' && _nombreEmpresa[i]<='9'
                          ||_nombreEmpresa[i]==32) )
                        {
                        errorDeIngreso = true;
                        cout << "ERRROR, ingrese un valor numerico..." << endl;
                        break;
                        }
                    }
                }while(errorDeIngreso);

                obj.setNombreEmpresa(_nombreEmpresa);
                AgregarRegistroModificado(obj);
                system("pause");
            break;

            case 3:  //Direccion
                cin.ignore(10000, '\n');
                do{
                    errorDeIngreso = false;
                    cin.clear();
                    cout << "Ingresa Direccion: ";
                    cin.getline(_direccion,9);

                    for(int i=0; _direccion[i] != '\0'; i++)
                    {
                        // si no esta en el rango de mayusculas, minusculas, numeros o  espacio en ASCII.
                        if(!(_direccion[i]>64 && _direccion[i]<91 || _direccion[i]>96 && _direccion[i]<123 || (int)_direccion[i] > 47 && (int)_direccion[i] < 58 || _direccion[i] == 32))
                        {
                        errorDeIngreso = true;
                        cout << "ERRROR, ingrese un valor numerico..." << endl;
                        break;
                        }
                    }

                }while(errorDeIngreso);

                obj.setDireccion(_direccion);
                AgregarRegistroModificado(obj);
                system("pause");
            break;

            case 0:
                cout<<"saliendo del modificar, muchas gracias"<<endl;
                salir = true;
            break;

            default:
                cout<<"ingrese opcion correcta"<<endl;
                system("pause");
            break;
        }

    }

    return;
}

bool ArchivoClienteJuridico::BajaLogica(int id){//revisado
    ClienteJuridico obj;

    if (!BuscarClientePorID(id, obj))
    {
        cout<<"No hay registros cargados/guardados"<<endl;
        return false;
    }

    obj.setEstado(0);

    AgregarRegistroModificado(obj);

    return true;
}

bool ArchivoClienteJuridico::VerificarDuplicado(const char* _cuit){//revisado
    ClienteJuridico obj;

    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(!strcmp(obj.getCuit(), _cuit))
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}

int ArchivoClienteJuridico::BuscarIdConCuit(const char* _cuit){//revisado
    ClienteFisico obj;

    FILE *p;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return -1;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(!strcmp(obj.getCUIL(), _cuit))
        {
            fclose(p);
            return obj.getIdClienteFisico();
        }
    }

    fclose(p);

    return -1;
}

bool ArchivoClienteJuridico::BuscarClientePorID(int id, ClienteJuridico& cli){//revisado
    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&cli, tamanioRegistro, 1, p))
    {
        if(cli.getIdClienteJuridico() == id)
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}

int ArchivoClienteJuridico::ObtainNewID(){//revisado
    ArchivoClienteFisico obj;
    return CantidadRegistros() + obj.CantidadRegistros() + 1;
}

int ArchivoClienteJuridico::CantidadRegistros(){//revisado
    FILE *pfile;
    pfile=fopen(nombreRuta, "rb");
    int cantidad;
    if(pfile==nullptr)
    {
        return 0;
    }
    fseek(pfile,0,SEEK_END);
    cantidad=ftell(pfile) / tamanioRegistro;
    fclose(pfile);
    return cantidad;
}

bool ArchivoClienteJuridico::ListarRegistros(){//revisado
        if (!CantidadRegistros())
    {
        return 0;
    }

    bool flagTodosInactivos = true;
    bool flagTodosActivos = true;
    ClienteJuridico obj;
    FILE *p;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        return false;
    }

    int opc;
    bool salir=false;
    while(!salir)
    {
        cout << " -------------------- " << endl;
        cout << "|    Quiere Listar:  |" << endl;
        cout << " -------------------- " << endl;
        cout << "|                    |" << endl;
        cout << "|    1. Activos      |" << endl;
        cout << "|    2. Inactivos    |" << endl;
        cout << "|                    |" << endl;
        cout << "|    0. Volver       |" << endl;
        cout << "|                    |" << endl;
        cout << " -------------------- " << endl;
        cout << endl << "      Su opcion: " << endl;
        cin>>opc;
        if (cin.fail())
        {
            cin.clear();
            cin.ignore(10000, '\n');
            opc=-1;
        }
        switch(opc)
        {
            case 1: // activos
                system("pause");
                system("cls");
                while(fread(&obj, tamanioRegistro, 1, p))
                {
                    if (obj.getEstado())
                    {
                        flagTodosInactivos = false;
                        obj.Mostrar();
                    }
                }

                if (flagTodosInactivos)
                {
                    cout << "Error: No hay registros activos" << endl;
                }
                salir=true;
            break;
            case 2: // inactivos
                system("pause");
                system("cls");
                while(fread(&obj, tamanioRegistro, 1, p))
                {
                    if (!obj.getEstado())
                    {
                        flagTodosActivos = false;
                        obj.Mostrar();
                    }
                }

                if (flagTodosActivos)
                {
                    cout << "Error: No hay registros inactivos" << endl;
                }
                salir=true;
            break;
            case 0:
                cout<<"Volviendo al menu principal.."<<endl;
                salir=true;
                break;
            default:
                cout<<"Ingrese una opcion valida"<<endl;
                system("pause");
                system("cls");
            break;
        }
    }
    fclose(p);
    return 1;
}

void ArchivoClienteJuridico::AgregarRegistro(ClienteJuridico& cli){//revisado
    FILE *p;
    int escribio;

    p = fopen(nombreRuta, "ab");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    escribio = fwrite(&cli, tamanioRegistro, 1, p);

    fclose(p);

    if (escribio != 1)
    {
        cout << "Error al escribir el registro." << endl;
        return;
    }
}

 void ArchivoClienteJuridico::AgregarRegistroModificado(ClienteJuridico& cli){//revisado
    ClienteJuridico obj;
    FILE *p;

    p = fopen(nombreRuta, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(cli.getIdClienteJuridico() == obj.getIdClienteJuridico())
        {
            break;
        }
    }

    fseek(p, -tamanioRegistro, SEEK_CUR);

    if(fwrite(&cli, tamanioRegistro, 1, p))
    {
        cout<<"Registro Modificado Exitosamente" << endl;
    }
    else
    {
        cout<<"Registro NO Modificado, ALGO SALIO MAL" << endl;
    }


    fclose(p);
}

void ArchivoClienteJuridico::MostrarClientePorCUIT(const char* cuit){//revisado
   ClienteJuridico obj;
   bool bandera=0;
    FILE* p;
    p=fopen(nombreRuta, "rb");
    if(p==nullptr)
    {
        cout<<"Error de Apertura";
        return;
    }
    while(fread(&obj, tamanioRegistro, 1, p))
    {
     if (strcmp(cuit, obj.getCuit())==0)
     {
      bandera=true;
      obj.Mostrar();
     }
    }
    if(!bandera){cout<<"El CUIT no coincide"<<endl;}
    fclose(p);
    return;
}

void ArchivoClienteJuridico::ClientequeMasGasto(){//revisado
    ArchivoVenta GVenta;
    ClienteJuridico obj;
    int recaudacion = 0;
    int mayorRecaudacion = 0;
    int idMayorRecaudacion = 0;
    bool flagPrimero = true;

    FILE *p;
    p = fopen(nombreRuta, "rb");

    while(fread(&obj, tamanioRegistro, 1, p)){
        if(flagPrimero){
            idMayorRecaudacion = obj.getIdClienteJuridico();
            mayorRecaudacion = GVenta.RecaudacionTotalCliente(idMayorRecaudacion);

            flagPrimero = false;
        }

        recaudacion = GVenta.RecaudacionTotalCliente(obj.getIdClienteJuridico());

        if(mayorRecaudacion < recaudacion){
            mayorRecaudacion = recaudacion;
            idMayorRecaudacion = obj.getIdClienteJuridico();
        }
    }

    BuscarClientePorID(idMayorRecaudacion, obj);

    cout << "Cliente que mas gasto: " << '\n';
    obj.Mostrar();
    cout << "Con un total de $" << mayorRecaudacion << " pesos gastados" << '\n';
    fclose(p);
}

bool ArchivoClienteJuridico::VerificarActivo(int _id){
  ClienteJuridico juridiquito;
  FILE *p;
    p = fopen(nombreRuta, "rb");

    while(fread(&juridiquito, tamanioRegistro, 1, p)){
        if(_id==juridiquito.getIdClienteJuridico())
        {
            fclose(p);
            return juridiquito.getEstado();
        }
    }
    fclose(p);
    return false;
}

