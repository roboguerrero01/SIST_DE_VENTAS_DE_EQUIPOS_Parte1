#include"Vendedor.h"
# include<iostream>
using namespace std;

Vendedor::Vendedor(){}


Vendedor::Vendedor();

void Vendedor::setLegajo(int _legajo){ Legajo = _legajo; }
void Vendedor::setIngreso(Fecha _fechaDeIngreso){ FechaDeIngreso = _fechaDeIngreso; }
void Vendedor::setSueldo(float _sueldo){ Sueldo = _sueldo; }

int Vendedor::getLegajo(){ return Legajo; }
Fecha Vendedor::getIngreso(){ return FechaDeIngreso; }
float Vendedor::getSueldo(){ return Sueldo; }

void Vendedor::Cargar(int id){
    Fecha objF;
    float _sueldo = -1;

    cout << " ------ Cargando Vendedor ------ " << '\n';
    Persona::Cargar();
    cout << " --- Cargue sus datos de Vendedor --- " << '\n';
    cout << " - Ingrese la fecha de ingreso " << '\n';
    objF.Cargar();
    setIngreso(objF);
    cout << "" << '\n';

    cout << " - Ingrese el sueldo             " << '\n';
    cin >> _sueldo;
    setSueldo(_sueldo);


    setLegajo(id);
    cout << " - Legajo asignado = " << getLegajo() << '\n';
}


void Vendedor::Mostrar(){
    Fecha obj = getIngreso();
    cout << " VENDEDOR [ LEGAJO: " << getLegajo() << " ]" << endl;
    cout << "-------------------------------------- " << endl;
    cout << " Fecha de ingreso: ";
    obj.Mostrar();
    cout << endl;
    cout << " Sueldo: " << getSueldo() << endl;
    cout << "-------------------------------------- " << endl;
    Persona::Mostrar();
    cout << "-------------------------------------- " << endl << endl;
}
