#include<iostream>
#include"Venta.h"

using namespace std;

Venta::Venta(){}

void Venta::setIDventa(int _IdVenta){ IdVenta = _IdVenta; }
void Venta::setEstado(bool _Estado){ Estado = _Estado; }
void Venta::setFechadeVenta(Fecha _FechaDeVenta){ FechaDeVenta = _FechaDeVenta;}
void Venta::setLegajoVendedor(int _LegajoVendedor){ LegajoVendedor = _LegajoVendedor; }
void Venta::setIdCliente(int _idCliente){ IdCliente = _idCliente; }

int Venta::getIDventa(){ return IdVenta; }
bool Venta::getEstado(){ return Estado; }
Fecha Venta::getFechadeVenta(){ return FechaDeVenta; }
int Venta::getLegajoVendedor(){ return LegajoVendedor; }
int Venta::getIdCliente(){ return IdCliente; }

bool Venta::Cargar(int id){
    int FisicoOJuridico;
    int _legajo;
    char cuilYCuit[12];
    bool exit = false;
    int caso = 1; ///ASI ENTRA SIEMPRE EN EL CASE
    bool primerDetalle=true;

    ArchivoClienteFisico objFisico;
    ArchivoClienteJuridico objJuridico;
    ArchivoVendedor objVendedor;
    DetalleDeVentas detalle;
    ArchivoEquipo equipo;
    int idEquipo = -1;

    cout<<"Bienvenido al ingreso de Ventas"<<endl<<endl<<"A continuacion ingrese la Fecha de Venta"<<endl;

    FechaDeVenta.Cargar();

    do{
        if (objVendedor.CantidadRegistros() == 0){ break; }
        cout << "Ingrese el legajo del vendedor: ";
        cin >> _legajo;
        if(!(objVendedor.VerificarDuplicado(_legajo))){
            cout << "Error, vendedor inexistente, intentelo nuevamente" << '\n';
        }
    } while (!(objVendedor.VerificarDuplicado(_legajo)));
    setLegajoVendedor(_legajo);

    cin.ignore();

    cout << "Que tipo de cliente esta realizando la compra? [ 1 - Fisico, 2 - Juridico]" << '\n';
    cin >> FisicoOJuridico;

    cin.ignore();
    if(FisicoOJuridico == 1){
        do{
            if (objFisico.CantidadRegistros() == 0){ break; }

            cout << "Ingrese el cuil del cliente fisico: ";
            cin.getline(cuilYCuit, 12);

            if( !( objFisico.VerificarDuplicado(cuilYCuit))  ){
                cout << "Error, Cliente inexistente, intentelo nuevamente" << '\n';
            }

        } while ( !( objFisico.VerificarDuplicado(cuilYCuit)) );
        setIdCliente(objFisico.BuscarIdConCuil(cuilYCuit));
    }
    if (FisicoOJuridico == 2){
        do{
            if (objJuridico.CantidadRegistros() == 0){ break; }

            cout << "Ingrese el cuit del cliente juridico: ";
            cin.getline(cuilYCuit, 12);

            if( !( objJuridico.VerificarDuplicado(cuilYCuit))  ){
                cout << "Error, Cliente inexistente, intentelo nuevamente" << '\n';
            }

        } while ( !( objJuridico.VerificarDuplicado(cuilYCuit)) );
        setIdCliente(objJuridico.BuscarIdConCuit(cuilYCuit));
    }


    IdVenta = id;
    cout << " - ID Venta: " << IdVenta<<endl;
    detalle.CopiaDeSeguridad();
    while(!exit){
        switch(caso){
        case 0:
            exit = true;
            break;
        case 1:
//Pedir id de equipo
            do {
                detalle.setIdDetalleDeVenta(detalle.ObtainNewID(IdVenta));
                cout<<"---------------------------------------"<<endl;
                cout<< " - ID Detalle de venta: " << detalle.getIdDetalleDeVenta()<< endl;
                cout << "Ingrese el id del equipo que desea adquirir" << endl;
                cin >> idEquipo;
                cin.ignore();
                if (!equipo.VerificarDuplicado(idEquipo))
                {
                    cout << "Error: el id no esta vinculado a ningun equipo" << endl;
                }
            } while(!equipo.VerificarDuplicado(idEquipo));
            detalle.Cargar(IdVenta, idEquipo);

            break;
        case 2:
////Cancelar Venta
            detalle.CancelarDetallesDeVenta(IdVenta);
            cout << "Venta cancelada exitosamente" << endl;
            Estado = false;
            return false;
            break;
        default:
            cout << "Error: Ingrese una opcion valida. " << endl;
            break;
        }

        if (!exit){
            cout<<"---------------------------------------"<<endl;
            cout <<endl<<"Quiere seguir cargando detalles de venta?"<<endl<<"0 - Parar"<<endl<<"1 - Seguir"<<endl<<"2 - Cancelar venta" << endl;
            cout<<"Su OPCION: ";
            cin >> caso;
            cout<<endl;
        }
    }

    Estado = true;

    cout << "Estado: Activo por default " << endl;
    return true;
}

void Venta::Mostrar(){
    cout << "\n--- Datos de la Venta ---" << endl;
    cout << "Id venta: " << IdVenta << endl;
    cout << "Legajo Vendedor: " << LegajoVendedor << '\n';
    cout << "Id Cliente: " << IdCliente << '\n';
    cout << "Fecha de Venta: ";
    FechaDeVenta.Mostrar();

    if (Estado){ cout << "Estado: Activo" << endl; }
    else { cout << "Estado: Inactivo" << endl; }
}


