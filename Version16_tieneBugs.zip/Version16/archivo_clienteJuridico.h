#pragma once
#include"clienteJuridico.h"
#include"clienteJuridico.h"
#include"archivo_clienteFisico.h"

class ArchivoClienteJuridico{
  private:
      char nombreRuta[30];
      int tamanioRegistro;

  public:
      ArchivoClienteJuridico();

      bool VerificarDuplicado(const char*); /// LO USA LA FUNCION AGREGAR REGISTRO
      void AgregarRegistroModificado(ClienteJuridico&); /// LO USA LA FUNCION MENU MODIFICAR CLIENTE
      bool BuscarClientePorID(int, ClienteJuridico&); /// Funcion para corroborar si existe, LO USA LA FUNCION MOSTRAR CLIENTE X ID
      int ObtainNewID();
      int CantidadRegistros();
      int BuscarIdConCuit(const char*);

      void AgregarRegistro(ClienteJuridico&); /// OPCION 1
      bool BajaLogica(int); /// OPCION 2
      void MenuModificarClienteJuridico(int); /// OPCION 3
      bool ListarRegistros(); /// OPCION 4
      bool MostrarClientePorID(int); /// OPCION 5
      void MostrarClientePorCUIT(const char*); /// OPCION 6
      void ClientequeMasGasto(); /// OPCION 7
};
