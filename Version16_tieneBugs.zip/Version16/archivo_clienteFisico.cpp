#include "archivo_clienteFisico.h"
# include<iostream>
# include<cstring>
using namespace std;

ArchivoClienteFisico::ArchivoClienteFisico(){
    strcpy(nombreRuta, "archivoClienteFisico.dat");
    tamanioRegistro = sizeof(ClienteFisico);
}

void ArchivoClienteFisico::AgregarRegistro(ClienteFisico& cli){
    FILE *p;
    int escribio;

    p = fopen(nombreRuta, "ab");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    escribio = fwrite(&cli, tamanioRegistro, 1, p);

    fclose(p);

    if (escribio != 1)
    {
        cout << "Error al escribir el registro." << endl;
    }
}

bool ArchivoClienteFisico::ListarRegistros(){
    if (!CantidadRegistros())
    {
        return 0;
    }

    bool flagTodosInactivos = true;
    bool flagTodosActivos = true;
    ClienteFisico obj;
    FILE *p;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        return false;
    }

    int opc;
    bool salir=false;
    while(!salir)
    {
        cout << " -------------------- " << endl;
        cout << "|    Quiere Listar:  |" << endl;
        cout << " -------------------- " << endl;
        cout << "|                    |" << endl;
        cout << "|    1. Activos      |" << endl;
        cout << "|    2. Inactivos    |" << endl;
        cout << "|                    |" << endl;
        cout << "|    0. Volver       |" << endl;
        cout << "|                    |" << endl;
        cout << " -------------------- " << endl;
        cout << endl << "      Su opcion: " << endl;
        cin>>opc;
        if (cin.fail())
        {
            cin.clear();
            cin.ignore(10000, '\n');
            opc = -1;
        }
        switch(opc)
        {
            case 1:
                system("pause");
                system("cls");
                while(fread(&obj, tamanioRegistro, 1, p))
                {
                    if (obj.getEstado())
                    {
                        flagTodosInactivos = false;
                        obj.Mostrar();
                    }
                }
                if (flagTodosInactivos)
                {
                    cout << "Error: No hay registros activos" << endl;
                }
                salir=true;
            break;

            case 2:
                system("pause");
                system("cls");
                while(fread(&obj, tamanioRegistro, 1, p))
                {
                    if (!obj.getEstado())
                    {
                        flagTodosActivos = false;
                        obj.Mostrar();
                    }
                }
                if (flagTodosActivos)
                {
                    cout << "Error: No hay registros inactivos" << endl;
                }
                salir=true;
            break;

            case 0:
                cout<<"Volviendo"<<endl;
                salir=true;
            break;

            default:
                cout<<"Ingrese una opcion valida"<<endl;
                system("pause");
                system("cls");
            break;
        }
    }
   return 1;
}

bool ArchivoClienteFisico::VerificarDuplicado(const char* _cuil){
    ClienteFisico obj;

    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(!strcmp(obj.getCUIL(), _cuil))
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}

int ArchivoClienteFisico::BuscarIdConCuil(const char* _cuil){
    ClienteFisico obj;

    FILE *p;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return -1;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(!strcmp(obj.getCUIL(), _cuil))
        {
            return obj.getIdClienteFisico();
        }
    }

    fclose(p);

    return -1;
}

bool ArchivoClienteFisico::BuscarClientePorID(int id, ClienteFisico& cli){
    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&cli, tamanioRegistro, 1, p))
    {
        if(cli.getIdClienteFisico() == id)
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}

int ArchivoClienteFisico::CantidadRegistros(){
    FILE *pfile;
    pfile=fopen(nombreRuta, "rb");
    int cantidad;
    if(pfile==nullptr)
    {
        return 0;
    }
    fseek(pfile,0,SEEK_END);
    cantidad=ftell(pfile) / tamanioRegistro;
    fclose(pfile);
    return cantidad;
 }

int ArchivoClienteFisico::ObtainNewID(){
    ArchivoClienteJuridico obj;
    return CantidadRegistros() + obj.CantidadRegistros() + 1;
}

bool ArchivoClienteFisico::BajaLogica(int id){
    ClienteFisico obj;

    if (!BuscarClientePorID(id, obj))
        {
            cout<<"No hay registros cargados/guardados"<<endl;
            return false;
        }
    obj.setEstado(0);
    AgregarRegistroModificado(obj);
    return true;
}

void ArchivoClienteFisico::MenuModificarClienteFisico(int id){
    ClienteFisico obj;
    char _nombres[30];
    char _apellidos[30];
    char _dni[9];
    char _telefono[20];
    char _cuil[20];
    char _correo[50];
    char _direccion[50];
    Fecha _nacimiento;
    bool salir = false;
    bool errorDeIngreso = false;

    if (!BuscarClientePorID(id, obj))
        {
            cout<<"No hay registros cargados/guardados"<<endl;
            return;
        }

    if (!obj.getEstado())
    {
        cout << "Error: perfil dado de baja." << '\n';
        salir = true;
    }

    while(!salir)
    {
        system ("cls");
        int opc;
        cout << " ----------------------------------------------------- " << endl;
        cout << "         Perfil de " << obj.getNombres() << " " << obj.getApellidos() << endl;
        cout << " ----------------------------------------------------- " << endl;
        cout << "         Elija el atributo a modificar: "<<endl<<endl;
        cout << "         1 -  Nombre"<<endl;
        cout << "         2 -  Apellido"<<endl;
        cout << "         3 -  Dni"<<endl;
        cout << "         4 -  Nacimiento"<<endl;
        cout << "         5 -  Telefono"<<endl;
        cout << "         6 -  Correo"<<endl;
        cout << "         7 -  Direccion"<<endl;
        cout << "         8 -  Cuil" << endl << endl;
        cout << "         0 -  Salir"<<endl<<endl;
        cout << " ------------------------------------------------------ " << endl;
        cout << "              Opcion: ";
        cin>>opc;
        if(cin.fail())
        {
            cin.clear();
            cin.ignore(10000,'\n');
            opc = -1;
        }
        cin.ignore();
        switch(opc){

            case 1:  //nombre

                do{
                    errorDeIngreso = false;

                    cout<<"Ingrese Nuevo Nombre: ";
                    cin.getline(_nombres, 30);

                    for(int i=0; _nombres[i] != '\0'; i++)
                    {
                        // si no esta en el rango de mayusculas o minusculass en ASCII.
                        if(!(_nombres[i]>64 && _nombres[i]<91 || _nombres[i]>96 && _nombres[i]<123))
                        {
                            errorDeIngreso = true;
                        }
                    }
                    if (errorDeIngreso)
                    {
                        cout << "Error de ingreso. PRESIONE ENTER" << '\n';
                        cin.clear();
                        cin.ignore(10000,'\n');
                        break;
                    }
                }
                while(errorDeIngreso);

                obj.setNombres(_nombres);
                AgregarRegistroModificado(obj);
            break;

            case 2:  //apellido

                do{
                    errorDeIngreso = false;

                    cout<<"Ingrese Nuevo Apellido: ";
                    cin.getline(_apellidos,30);

                    for(int i=0; _apellidos[i] != '\0'; i++)
                    {
                        // si no esta en el rango de mayusculas o minusculass en ASCII.
                        if(!(_apellidos[i]>64 && _apellidos[i]<91 || _apellidos[i]>96 && _apellidos[i]<123))
                        {
                            errorDeIngreso = true;
                        }
                    }
                    if (errorDeIngreso)
                    {
                        cout << "Error de ingreso. PRESIONE ENTER" << '\n';
                        cin.clear();
                        cin.ignore(10000,'\n');
                        break;
                    }
                }
                while(errorDeIngreso);


                obj.setApellidos(_apellidos);
                AgregarRegistroModificado(obj);
            break;

            case 3:  //dni

                do{

                    errorDeIngreso = false;

                    cout<<"Ingrese Nuevo DNI: ";
                    cin.getline(_dni,9);

                    for(int i=0; _dni[i] != '\0'; i++)
                    {
                        // si no esta en el rango de numeros en ASCII.
                        if(!(_dni[i] >= '0' && _dni[i] <= '9'))
                        {
                            errorDeIngreso = true;
                            cin.clear();
                            cin.ignore(10000, '\n');
                            cout << "ERRROR, ingrese un valor numerico..." << endl;
                            break;
                        }
                    }

                }while(errorDeIngreso);

                obj.setDni(_dni);
                AgregarRegistroModificado(obj);
            break;

            case 4:  //fecha
                cout<<"Ingrese Nueva Fecha de Nacimiento: ";
                _nacimiento.Cargar();
                obj.SetFecha(_nacimiento);
                AgregarRegistroModificado(obj);
            break;

            case 5:  //telefono

                do{

                    errorDeIngreso = false;

                    cout<<"Ingrese Nuevo Telefono:";
                    cin.getline(_telefono,20);

                    for(int i=0; _telefono[i] != '\0'; i++)
                    {
                        // si no esta en el rango de numeros en ASCII.
                        if(!((int)_telefono[i] < 58 && (int)_telefono[i] > 47))
                        {
                           errorDeIngreso = true;
                            cin.clear();
                            cin.ignore(10000, '\n');
                            cout << "ERRROR, ingrese un valor numerico..." << endl;
                            break;
                        }
                    }
                }while(errorDeIngreso);

                obj.setTelefono(_telefono);
                AgregarRegistroModificado(obj);
            break;

            case 6:  //email
                cout<<"Ingrese Nuevo EMAIL:";
                cin.getline(_correo,50);
                obj.setEmail(_correo);
                AgregarRegistroModificado(obj);
            break;

            case 7:  //direccion

                do{
                    errorDeIngreso = false;

                    cout<<"Ingrese Nueva Direccion:";
                    cin.getline(_direccion, 50);

                    for(int i=0; _direccion[i] != '\0'; i++)
                    {
                        // si no esta en el rango de mayusculas, minusculas o numeros en ASCII.
                        if(!(_direccion[i]>64 && _direccion[i]<91 || _direccion[i]>96 && _direccion[i]<123 || (int)_direccion[i] > 47 && (int)_direccion[i] < 58 || _direccion[i] == 32))
                        {
                           errorDeIngreso = true;
                            cin.clear();
                            cin.ignore(10000, '\n');
                            cout << "ERRROR, ingrese valores validos..." << endl;
                            break;
                        }
                    }
                }while(errorDeIngreso);

                obj.setDireccion(_direccion);
                AgregarRegistroModificado(obj);
            break;

            case 8:  //cuil

                do{

                    errorDeIngreso = false;

                    cout<<"Ingrese Nuevo CUIL:";
                    cin.getline(_cuil,20);

                    for(int i=0; _cuil[i] != '\0'; i++)
                    {
                        // si no esta en el rango de numeros en ASCII.
                        if(!((int)_cuil[i] < 58 && (int)_cuil[i] > 47))
                        {
                            errorDeIngreso = true;
                            cin.clear();
                            cin.ignore(10000, '\n');
                            cout << "ERRROR, ingrese un valor valido..." << endl;
                            break;
                        }
                    }

                }while(errorDeIngreso);

                obj.setCUIL(_cuil);
                AgregarRegistroModificado(obj);
            break;

            case 0:
                cout<<"saliendo del modificar, muchas gracias"<<endl;
                salir = true;
            break;

            default:
                cout<<"ingrese opcion correcta"<<endl;
            break;
        }

        system("pause");
    }

    return;
}

void ArchivoClienteFisico::AgregarRegistroModificado(ClienteFisico& cli){
    ClienteFisico obj;
    FILE *p;

    p = fopen(nombreRuta, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(cli.getIdClienteFisico() == obj.getIdClienteFisico())
        {
            break;
        }
    }

    fseek(p, -tamanioRegistro, SEEK_CUR);

    if(fwrite(&cli, tamanioRegistro, 1, p))
    {
        cout<<"Registro Modificado Exitosamente" << endl;
    }
    else
    {
        cout<<"Registro NO Modificado, ALGO SALIO MAL" << endl;
    }


    fclose(p);
}

bool ArchivoClienteFisico::MostrarClientePorID(int id){
    ClienteFisico obj;
    if (!BuscarClientePorID(id, obj))
    {
        cout<<"No hay registros cargados/guardados con ese ID"<<endl;
        return false;
    }
    obj.Mostrar();
    return true;
}

void ArchivoClienteFisico::MostrarClientePorCUIL(const char* cuil){
   ClienteFisico obj;
   bool bandera=0;
    FILE* p;
    p=fopen(nombreRuta, "rb");
    if(p==nullptr)
    {
        cout<<"Error de Apertura";
        return;
    }
    while(fread(&obj, tamanioRegistro, 1, p))
    {
     if (strcmp(cuil, obj.getCUIL())==0)
     {
      bandera=true;
      obj.Mostrar();
     }
    }
    if(!bandera){cout<<"El CUIL no coincide"<<endl;}
    return;
}

void ArchivoClienteFisico::ClientequeMasGasto(){cout<<"A Desarrollar"<<endl;}
