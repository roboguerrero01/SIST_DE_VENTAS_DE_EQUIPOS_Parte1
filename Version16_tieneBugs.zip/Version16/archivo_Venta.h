#pragma once
#include"Vendedor.h"
#include"Venta.h"
#include"fecha.h"


class ArchivoVenta{
  private:
      char nombreRuta[30];
      int tamanioRegistro;

  public:
      ArchivoVenta(); ///"archivoVenta.dat"

      bool VerificarDuplicado(int); /// LO USA LA FUNCION AGREGAR REGISTRO
      void AgregarRegistroModificado(Venta&); /// LO USA LA FUNCION MENU MODIFICAR VENDEDOR
      bool BuscarVentaporID(int, Venta&); /// Funcion para corroborar si existe, LO USA LA FUNCION MOSTRAR VENDEDOR X LEGAJO
      int ObtainNewID();
      int CantidadRegistros();
      float RecaudacionTotalVendedor(int);
      int CantidadVendidaDeEquipoPorVendedor(int, int);

      void AgregarRegistro(Venta); /// OPCION 1
      bool BajaLogica(int); /// OPCION 2
      void ModificarFechaDeVenta(int); /// OPCION 3
      bool ListarRegistros(); /// OPCION 4
      void ListarPorAnio(Fecha); /// OPCION 5
      void RecaudacionTotalPorAnio(Fecha); /// OPCION 6

};
