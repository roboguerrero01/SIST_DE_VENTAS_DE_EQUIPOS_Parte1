#include <iostream>
#include <cstring>
#include "personas.h"

using namespace std;

// Constructores
Persona::Persona(){
strcpy(Nombres,"sin_nombre");
strcpy(Apellidos,"sin_apellido");
strcpy(Dni,"sin_DNI");
strcpy(Telefono,"sin_telefono");
strcpy(Email,"sin_email");
strcpy(Direccion,"sin_direccion");
Estado=false;
}


Persona::Persona(const char* nombres, const char* apellidos, const char* dni, Fecha fechaNac,
            const char* telefono, const char* email, const char* direccion, bool estado) {

    strcpy(Nombres, nombres);
    strcpy(Apellidos, apellidos);
    FechaNac = fechaNac;
    strcpy(Telefono, telefono);
    strcpy(Email, email);
    strcpy(Dni, dni);
    strcpy(Direccion, direccion);
    Estado = estado;
}

// Getters


const char* Persona::getNombres() {
    return Nombres;
}

const char* Persona::getApellidos() {
    return Apellidos;
}

Fecha Persona::GetFechaNac() {
    return FechaNac;
}

const char* Persona::getTelefono() {
    return Telefono;
}

const char* Persona::getDni() {
    return Dni;
}

const char* Persona::getEmail() {
    return Email;
}

const char* Persona::getDireccion() {
    return Direccion;
}

bool Persona::getEstado() {
    return Estado;
}

// Setters

void Persona::setNombres(const char* nombres) {
    strcpy(Nombres, nombres);
}

void Persona::setApellidos(const char* apellidos) {
    strcpy(Apellidos, apellidos);
}

void Persona::SetFecha(Fecha fechaNac) {
    FechaNac = fechaNac;
}

void Persona::setTelefono(const char* telefono) {
    strcpy(Telefono, telefono);
}

void Persona::setEmail(const char* email) {
    strcpy(Email, email);
}

void Persona::setDni(const char* dni) {
    strcpy(Dni, dni);
}

void Persona::setDireccion(const char* direccion) {
    strcpy(Direccion, direccion);
}

void Persona::setEstado(bool estado) {
    Estado = estado;
}

// M�todos
void Persona::Cargar() {
    bool errorDeIngreso = false;
    cout << "Cargue sus datos personales" << endl;
    cout << "---------------------------" << endl;
    cin.ignore(10000,'\n');

    do{
        errorDeIngreso = false;

        cout << "Nombres: ";
        cin.getline(Nombres,50);

        for(int i=0; Nombres[i] != '\0'; i++)
        {
            // si no esta en el rango de mayusculas o minusculass en ASCII.
            if(!(Nombres[i] > 64 && Nombres[i] < 91 || Nombres[i] > 96 && Nombres[i] < 123))
            {
                errorDeIngreso = true;
                cout << "Error de ingreso. PRESIONE ENTER" << '\n';
                cin.clear();
                cin.ignore(10000,'\n');
                break;
            }
        }

    }while(errorDeIngreso);

    do{
        errorDeIngreso = false;

        cout << "Apellidos: ";
        cin.getline(Apellidos,50);

        for(int i=0; Apellidos[i] != '\0'; i++)
        {
            // si no esta en el rango de mayusculas o minusculass en ASCII.
            if(!(Apellidos[i] > 64 && Apellidos[i] < 91 || Apellidos[i] > 96 && Apellidos[i] < 123))
            {
                errorDeIngreso = true;
                cout << "Error de ingreso. PRESIONE ENTER" << '\n';
                cin.clear();
                cin.ignore(10000,'\n');
                break;
            }
        }

    }while(errorDeIngreso);


    do{

        errorDeIngreso = false;

        cout << "DNI: ";
        cin.getline(Dni,9);

        for(int i=0; Dni[i] != '\0'; i++)
        {
            // si no esta en el rango de numeros en ASCII.
            if(!(Dni[i] >= '0' && Dni[i] <= '9'))
            {
                errorDeIngreso = true;
                cin.clear();
                cin.ignore(10000, '\n');
                cout << "ERRROR, ingrese un valor numerico..." << endl;
                break;
            }
        }

    }while(errorDeIngreso);

    cout << "Fecha de nacimiento: "<<endl;
    FechaNac.Cargar();  // asegurate de tener este m�todo en la clase Fecha

    do{

        errorDeIngreso = false;

        cout << "Telefono: ";
        cin.getline(Telefono, 20);

        for(int i=0; Telefono[i] != '\0'; i++)
        {
            // si no esta en el rango de numeros en ASCII.
            if(!((int)Telefono[i] < 58 && (int)Telefono[i] > 47))
            {
                errorDeIngreso = true;
                cin.clear();
                cin.ignore(10000, '\n');
                cout << "ERRROR, ingrese un valor numerico..." << endl;
                break;
            }
        }

    }while(errorDeIngreso);

    cout << "Email: ";
    cin.getline(Email, 50);

    do{
        errorDeIngreso = false;
        cout << "Direccion: ";
        cin.getline(Direccion, 50);

        for(int i=0; Direccion[i] != '\0'; i++)
        {
            // si no esta en el rango de mayusculas, minusculas, numeros o espacio en ASCII.
            if(!(Direccion[i]>64 && Direccion[i]<91 || Direccion[i]>96 && Direccion[i]<123 || (int)Direccion[i] > 47 && (int)Direccion[i] < 58))
            {
                errorDeIngreso = true;
                cout << "Error de ingreso. PRESIONE ENTER" << '\n';
                cin.clear();
                cin.ignore(10000,'\n');
                break;
            }
        }

    }while(errorDeIngreso);


    Estado=true;
}

void Persona::Mostrar() {
    cout << " Nombre completo: " << Nombres << " " << Apellidos << endl;
    cout << " DNI [ "<<Dni<< " ]" << endl;
    cout << " Fec. Nac.:";
    FechaNac.Mostrar();// asegurate que exista mostrar() en Fecha
    cout << " Direccion: " << Direccion  << endl << endl;
    cout << "              - Info de Contacto -" << endl;
    cout << " Telefono [ " << Telefono << " ]" << endl;
    cout << " Email: " << Email << endl;
    cout << "                             Estado ";
    if(Estado==true){
        cout<<"[ Activo ]"<<endl;
    }else{
        cout<<"[ Inactivo ]"<<endl;
    }
}
