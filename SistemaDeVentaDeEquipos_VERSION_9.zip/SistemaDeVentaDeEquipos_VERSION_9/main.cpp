#include <iostream>
#include "menues.h"

using namespace std;

int main()
{
   menuGeneral();

   return 0;
}
