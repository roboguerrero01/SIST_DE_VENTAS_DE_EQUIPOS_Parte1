#pragma once

class ClienteJuridico{
private:
    int IdClienteJuridico;
    char Cuit[12];
    char NombreEmpresa[50];
    char Direccion[100];
    bool Estado;

public:
    ClienteJuridico();

    void setIdClienteJuridico(int _id);
    void setCuit(const char* );
    void setNombreEmpresa(const char* );
    void setDireccion(const char* );
    void setEstado(bool _estado);

    int getIdClienteJuridico();
    const char* getCuit();
    const char* getNombreEmpresa();
    const char* getDireccion();
    bool getEstado();

    bool cargar();
    void cargar(const char*, const char*, const char*);
    void mostrar();

};
