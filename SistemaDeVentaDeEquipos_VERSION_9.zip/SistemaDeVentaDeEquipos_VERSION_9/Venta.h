#ifndef VENTA_H_INCLUDED
#define VENTA_H_INCLUDED
#include "Fecha.h"

class Venta{
  private:
    int idventa;
    bool estado;
    Fecha fechadeVenta;

  public:
    bool cargar();
    void Mostrar();
    void setEstado();
    void setfechadeVenta();
    Venta(){};
    bool getEstado();
    Fecha getFechadeVenta();
};

#endif // VENTA_H_INCLUDED
