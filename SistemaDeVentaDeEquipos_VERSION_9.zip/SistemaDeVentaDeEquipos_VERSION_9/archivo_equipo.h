#include "equipo.h"
#include <cstring>
#pragma once

class ArchivoEquipo {
private:
    char nombre[30];
    int tamanioRegistro;

public:
    ArchivoEquipo(const char* n = "Registro_De_Equipos.dat");
    ///METODOS
    int AgregarRegistro(Equipo obj);
    int CantidadRegistros();
    int BuscarPosicionPorId(int id);
    bool ListarRegistros();
    void ListarPorID(int id);
    bool MenuModificarEquipo(int id); //modifica un euqipo en una posicion determinada
    bool BajaLogicaEquipo(int id);
    void AgregarRegistroModificado(Equipo obj);
    int obtainNewID();
    void ListarPorTipo(int tipo);
    void RankingdeEquiposMasVendidos(); ///DESARROLLAR
    void EquiposNoVendidos();///DESARROLLAR
};
