#include "equipo.h"
#include "archivo_equipo.h"
# include <cstring>
# include<iostream>
using namespace std;

using namespace std;


// Constructor
Equipo::Equipo() {
    IdEquipo = 0;
    strcpy(Marca, "");
    Tipo=-1;
    Stock = 0;
    Precio = 0.0;
    Estado = false;
}


// SETTERS
void Equipo::setIdEquipo(int _idEquipo) {
    IdEquipo = _idEquipo;
}


void Equipo::setMarca(const char* _marca) {
    strcpy(Marca, _marca);
}

void Equipo::setTipo(int _tipo) {
    Tipo=_tipo;
}

void Equipo::setStock(int _stock) {
    Stock = _stock;
}

void Equipo::setPrecio(float _precio) {
    Precio = _precio;
}

void Equipo::setEstado(bool _estado) {
    Estado = _estado;
}

// GETTERS
int Equipo::getIdEquipo() {
    return IdEquipo;
}


char* Equipo::getMarca() {
    return Marca;
}

int Equipo::getTipo() {
    return Tipo;
}

int Equipo::getStock() {
    return Stock;
}

float Equipo::getPrecio() {
    return Precio;
}

bool Equipo::getEstado() {
    return Estado;
}

// METODOS
bool Equipo::Cargar() {
    ArchivoEquipo obj;

    cout << "Ingrese los datos del equipo" << endl;
    cout << "----------------------------" << endl;

    cout << "Tipo de equipo: ";
    cin>> Tipo;

    cin.ignore();
    cout << "Marca: ";
    cin.getline(Marca, 30);

    cout << "Precio: $";
    cin >> Precio;


    cout << "Stock: ";
    cin >> Stock;


    Estado=true;
    cout<< "Su estado es: activo por default"<<endl;

    IdEquipo = obj.obtainNewID();
    cout<<endl;

    cout<<"El ID correspondiente al equipo es: "<<IdEquipo<<endl;

    return true;
}

void Equipo::Mostrar(){
    std::cout << " ------------- Equipo ------------- " << '\n';
    std::cout << " - ID: " << getIdEquipo() << '\n';
    std::cout << " - Tipo: " << getTipo() << '\n';
    std::cout << " - Marca: " << getMarca() << '\n';
    std::cout << " - Stock: " << getStock() << '\n';
    std::cout << " - Precio: $" << getPrecio() << '\n';
    std::cout << " - Estado: " << getEstado() << '\n' << '\n';
}

