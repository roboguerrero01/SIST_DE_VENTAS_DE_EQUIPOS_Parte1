#pragma once

class Equipo {
   private:
       int IdEquipo;
       int Tipo;
       char Marca[30];
       int Stock;
       float Precio;
       bool Estado;

   public:
       Equipo();  // Constructor por defecto
        //GETTERES Y SETTERS
        void setIdEquipo(int _idEquipo);
        void setMarca(const char* _marca);
        void setTipo(int _tipo);
        void setStock(int _stock);
        void setPrecio(float _precio);
        void setEstado(bool _estado);

        int getIdEquipo();
        char* getMarca();
        int getTipo();
        int getStock();
        float getPrecio();
        bool getEstado();

        //metodos

        bool Cargar();
        void Mostrar();
        void Modificar();
};

