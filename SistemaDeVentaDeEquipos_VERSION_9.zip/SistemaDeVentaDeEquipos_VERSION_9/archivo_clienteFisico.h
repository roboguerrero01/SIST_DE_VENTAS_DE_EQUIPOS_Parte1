# include<iostream>
# include"clientesFisicos.h"
using namespace std;

class archivoClienteFisico{
private:
  char NombreRuta[30];
  int TamanioRegistros;

public:
    archivoClienteFisico(const char* n = "archivoClienteFisico.dat");

    void agregarRegistro(ClienteFisico& cli);
    bool listarRegistros();
    bool verificarDuplicado(const char* _cuil);
    bool BuscarClientePorID(int id, ClienteFisico& cli);
    bool bajaLogica(int id);
    void menuModificarClienteFisico(int id);
    void AgregarRegistroModificado(ClienteFisico& cli);
    bool MostrarClienteFisicoPorID(int id);
    int obtainNewID();
    int cantidadRegistros();
    void MostrarClienteporCUIL(const char* cuil);
    void ClientequeMasGasto(); ///A DESARROLLAR
};
