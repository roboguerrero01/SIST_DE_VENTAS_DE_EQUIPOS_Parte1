#include <iostream>
#include <cstring>
#include "personas.h"

using namespace std;

// Constructores
Persona::Persona(){
strcpy(Nombres,"sin_nombre");
strcpy(Apellidos,"sin_apellido");
strcpy(Dni,"sin_DNI");
strcpy(Telefono,"sin_telefono");
strcpy(Email,"sin_email");
strcpy(Direccion,"sin_direccion");
Estado=false;
}


Persona::Persona(const char* nombres, const char* apellidos, const char* dni, Fecha fechaNac,
            const char* telefono, const char* email, const char* direccion, bool estado) {

    strcpy(Nombres, nombres);
    strcpy(Apellidos, apellidos);
    FechaNac = fechaNac;
    strcpy(Telefono, telefono);
    strcpy(Email, email);
    strcpy(Dni, dni);
    strcpy(Direccion, direccion);
    Estado = estado;
}

// Getters


const char* Persona::getNombres() {
    return Nombres;
}

const char* Persona::getApellidos() {
    return Apellidos;
}

Fecha Persona::GetFechaNac() {
    return FechaNac;
}

const char* Persona::getTelefono() {
    return Telefono;
}

const char* Persona::getDni() {
    return Dni;
}

const char* Persona::getEmail() {
    return Email;
}

const char* Persona::getDireccion() {
    return Direccion;
}

bool Persona::getEstado() {
    return Estado;
}

// Setters

void Persona::setNombres(const char* nombres) {
    strcpy(Nombres, nombres);
}

void Persona::setApellidos(const char* apellidos) {
    strcpy(Apellidos, apellidos);
}

void Persona::SetFecha(Fecha fechaNac) {
    FechaNac = fechaNac;
}

void Persona::setTelefono(const char* telefono) {
    strcpy(Telefono, telefono);
}

void Persona::setEmail(const char* email) {
    strcpy(Email, email);
}

void Persona::setDni(const char* dni) {
    strcpy(Dni, dni);
}

void Persona::setDireccion(const char* direccion) {
    strcpy(Direccion, direccion);
}

void Persona::setEstado(bool estado) {
    Estado = estado;
}

// M�todos
void Persona::cargar() {
    cout << "Cargue sus datos personales" << endl;
    cout << "---------------------------" << endl;
    cin.ignore();

    cout << "Nombres: ";
    cin.getline(Nombres,50);
    cout << "Apellidos: ";
    cin.getline(Apellidos,50);

    cout << "DNI: ";
    cin.getline(Dni,9);

    cout << "Fecha de nacimiento: "<<endl;
    FechaNac.cargar();  // asegurate de tener este m�todo en la clase Fecha
    cout << "Telefono: ";
    cin.getline(Telefono, 20);
    cout << "Email: ";
    cin.getline(Email, 50);
    cout << "Direccion: ";
    cin.getline(Direccion, 50);
    Estado=true;
}

void Persona::mostrar() {
    cout << "Nombre completo: " << Nombres << " " << Apellidos << endl;
    cout<<"DNI: "<<Dni<<endl;
    cout << "Fecha de nacimiento: ";
    FechaNac.mostrar(); // asegurate que exista mostrar() en Fecha
    cout << "Telefono: " << Telefono << endl;
    cout << "Email: " << Email << endl;
    cout << "Direccion: " << Direccion << endl;
    cout << "Estado: ";
    if(Estado==true){
        cout<<"activo"<<endl;
    }else{
        cout<<"inactivo"<<endl;
    }
}
