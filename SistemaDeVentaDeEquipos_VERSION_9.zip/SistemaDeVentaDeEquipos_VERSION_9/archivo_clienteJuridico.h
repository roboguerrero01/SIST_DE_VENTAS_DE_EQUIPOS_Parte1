#pragma once
#include"clienteJuridico.h"

class ArchivoClienteJuridico{
private:
    char NombreRuta[30];
    int TamanioRegistros;
public:
    ArchivoClienteJuridico(const char* n = "archivoClienteJuridico.dat");

    bool mostrarClienteJuridicoPorID(int id);
    bool menuModificarClienteJuridico(int id);
    bool bajaLogica(int id);
    bool verificarDuplicado(const char*);
    bool BuscarClientePorID(int id, ClienteJuridico& cli);
    int cantidadRegistros();
    bool listarRegistros();
    void agregarRegistro(ClienteJuridico cli);
    void AgregarRegistroModificado(ClienteJuridico& cli);
    int obtainNewID();
    void MostrarClienteporCUIT(const char* cuit);
    void ClientequeMasGasto(); /// A DESARROLLAR
};
