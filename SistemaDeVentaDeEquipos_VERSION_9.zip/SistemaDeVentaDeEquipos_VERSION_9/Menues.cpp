#include <iostream>
#include "menues.h"
#include "archivo_clienteFisico.h"
#include "archivo_clienteJuridico.h"
#include "archivo_equipo.h"
#include "Venta.h"
#include "Vendedor.h"


using namespace std;

void menuGeneral(){
    int opcion;
    do
    {
        system("cls");
        cout<<"BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS"<<endl;
        cout << "===== MENU GENERAL =====" << endl;
        cout << "1- Menu CLIENTES JURIDICOS/FISICOS. " << endl;
        cout << "2- Menu EQUIPOS. " << endl;
        cout<< "3- Menu VENDEDORES. "<<endl;
        cout<<"4- Menu de VENTAS. "<<endl;

        cout <<endl<< "0- SALIR DEL PROGRAMA. " << endl;
        cout <<endl<< "Ingrese Opcion: " << endl;
        cin >> opcion;
        if (cin.fail())
        {
         cin.clear(); //limpia error de cin
         cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
         opcion=-1;
        }
        bool salirMenuClientes = false;
        int OpcionMenuClientes;
        switch(opcion){
            case 1:
                while (!salirMenuClientes)
                {
                    system("cls");
                    cout << "Elige el tipo de cliente: " << '\n';
                    cout << "[ 1 - Fisico. 2 - Juridico. 0 - Volver. ] " << '\n';
                    cin.ignore(10000, '\n');
                    cin >> OpcionMenuClientes;
                    if (cin.fail()){
                        OpcionMenuClientes = -1;
                        cin.clear();
                    }
                    switch(OpcionMenuClientes){
                    case 1:
                        subMenuClientesFisicos();
                        break;
                    case 2:
                        subMenuClientesJuridicos();
                        break;
                    case 0:
                        salirMenuClientes = true;
                        break;
                    default:
                        cout << "Elija una opcion valida" << '\n';
                        system("pause");
                        break;
                    }
                }

                system("pause");
                break;

            case 2:
                subMenuEquipo();
                system("pause");
                break;
            case 3:
                subMenuVendedor();
                system("pause");
                break;
            case 4:
                subMenuVentas();
                system("pause");
                break;
            case 0:
                cout << "Saliendo del Programa, Vuelva Prontos." << endl;
                system("pause");
                break;
            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
                break;
        }
    }while(opcion != 0);

}
void subMenuEquipo(){
    int opcion;
    int tipo;
    ArchivoEquipo obj;
    Equipo equi;

    do
    {   int id=-1;
        system("cls");
        cout<<"BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS"<<endl;
        cout << "===== MENU DE EQUIPOS =====" << endl;
        cout << "1- ALTA " << endl;
        cout << "2- BAJA " << endl;
        cout << "3- MODIFICAR " << endl;
        cout << "4- LISTAR TODOS ACTIVOS/INACTIVOS" << endl;
        cout << "5- LISTAR POR ID" << endl;
        cout << "6- LISTAR POR TIPO" << endl;
        cout << "7- EQUIPOS MAS VENDIDOS" << endl;
        cout << "8- EQUIPOS NO VENDIDOS" << endl;
        cout <<endl<< "0- VOLVER AL MENU GENERAL. " << endl;
        cout <<endl<< "Ingrese Opcion: " << endl;
        cin >> opcion;
        if (cin.fail())
        {
         cin.clear(); //limpia error de cin
         cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
         opcion=-1;
        }
        switch(opcion){
            case 1:
                system("cls");
                equi.Cargar();
                obj.AgregarRegistro(equi);
                system("pause");
                break;

            case 2:
                system("cls");
                cout<<"Ingresa id a dar de baja: ";
                cin >> id;
                obj.BajaLogicaEquipo(id);
                system("pause");
                break;

            case 3:
                system("cls");
                cout<<"Ingresa id a modificar: ";
                cin >> id;
                obj.MenuModificarEquipo(id);
                system("pause");
                break;

            case 4:
                system("cls");
                obj.ListarRegistros();
                system("pause");
                break;

            case 5:
                system("cls");
                cout<<"Ingresa el id a buscar: ";
                cin >> id;
                obj.ListarPorID(id);
                system("pause");
                break;

            case 6:
                system("cls");
                cout<<"Ingresa el tipo a buscar: ";
                cin >> tipo;
                obj.ListarPorTipo(tipo);
                system("pause");
                break;

            case 7:
                system("cls");
                obj.RankingdeEquiposMasVendidos();
                system("pause");
                break;

            case 8:
                system("cls");
                obj.EquiposNoVendidos();
                system("pause");
                break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL...." << endl;
                break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
                break;
        }
    }while(opcion != 0);

}
void subMenuClientesFisicos(){
    int opcion;
    archivoClienteFisico archi;
    ClienteFisico comprador;
    do
    {   int id=-1;
        system("cls");
        cout<<"BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS"<<endl;
        cout << "===== MENU DE CLIENTES FISICO =====" << endl; /// fisico
        cout << "1- ALTA " << endl;
        cout << "2- BAJA LOGICA " << endl;
        cout << "3- MODIFICAR " << endl;
        cout << "4- LISTAR TODOS LOS REGISTROS ACTIVOS/INACTIVOS" << endl;
        cout << "5- MOSTRAR REGISTRO POR ID" << endl;
        cout<< "6- BUSCAR REGISTRO POR CUIL"<<endl;
        cout<< "7- CLIENTE QUE MAS GASTO"<<endl;
        cout <<endl<< "0- VOLVER AL MENU GENERAL. " << endl;
        cout <<endl<< "Ingrese Opcion: " << endl;
        cin >> opcion;
        if (cin.fail())
        {
         cin.clear(); //limpia error de cin
         cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
         opcion=-1;
        }
        switch(opcion){
            case 1:
                system("cls");
                if(comprador.Cargar()){
                    archi.agregarRegistro(comprador);
                }
                system("pause");
                break;

            case 2:
                system("cls");
                cout<<"Ingrese ID del perfil a dar De Baja: ";
                cin >> id;
                archi.bajaLogica(id);
                system("pause");
                break;

            case 3:
                system("cls");
                cin.ignore();
                cout<<"Ingrese ID de perfil a modificar: ";
                cin >> id;
                archi.menuModificarClienteFisico(id);
                system("pause");
                break;

            case 4:
                system("cls");
                if (!archi.listarRegistros()){
                    cout << "Archivo vacio." << '\n';
                }
                system("pause");
                break;
            case 5:
                system("cls");
                int id;
                cout<<"ingrese id: ";
                cin >> id;
                cin.ignore();
                archi.MostrarClienteFisicoPorID(id);
                system("pause");

            case 6:
                system("cls");
                char cuil[20];
                cout<<"ingrese CUIL para buscar: ";
                cin.getline(cuil,20);
                cin.ignore();
                archi.MostrarClienteporCUIL(cuil);
                system("pause");

            case 7:
                system("cls");
                archi.ClientequeMasGasto();
                system("pause");

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL..." << endl;
                system("pause");
                break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
                break;
        }
    }while(opcion != 0);
}
void subMenuClientesJuridicos(){
    int opcion;
    ArchivoClienteJuridico archi;
    ClienteJuridico comprador;
    char cuit[20];
    do
    {   int id=-1;
        system("cls");
        cout<<"BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS"<<endl;
        cout << "===== MENU DE CLIENTES JURIDICO =====" << endl; /// fisico
        cout << "1- ALTA " << endl;
        cout << "2- BAJA LOGICA " << endl;
        cout << "3- MODIFICAR " << endl;
        cout << "4- LISTAR TODOS LOS REGISTROS ACTIVOS/INACTIVOS" << endl;
        cout << "5- MOSTRAR REGISTRO POR ID" << endl;
        cout << "6- BUSCAR REGISTRO POR CUIT" << endl;
        cout << "7- CLIENTE QUE MAS GASTO" << endl;
        cout <<endl<< "0- VOLVER AL MENU GENERAL. " << endl;
        cout <<endl<< "Ingrese Opcion: " << endl;
        cin >> opcion;
        if (cin.fail())
        {
         cin.clear(); //limpia error de cin
         cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
         opcion=-1;
        }
        switch(opcion)
        {
            case 1:
                system("cls");
                if(comprador.cargar()){
                    archi.agregarRegistro(comprador);
                }
                system("pause");
                break;

            case 2:
                system("cls");
                cout<<"Ingrese ID del perfil a dar De Baja: ";
                cin >> id;
                archi.bajaLogica(id);
                system("pause");
                break;

            case 3:
                system("cls");
                cin.ignore();
                cout<<"Ingrese ID del cliente a modificar: ";
                cin >> id;
                archi.menuModificarClienteJuridico(id);
                system("pause");
                break;

            case 4:
                system("cls");
                if (!archi.listarRegistros())
                {
                    cout << "Archivo vacio." << '\n';
                }
                system("pause");
                break;

            case 5:
                system("cls");
                cout << "Ingrese id a buscar: ";
                cin >> id;
                cin.ignore();
                archi.mostrarClienteJuridicoPorID(id);
                system("pause");
                break;

            case 6:
                system("cls");
                char cuil[20];
                cout<<"ingrese CUIL para buscar: ";
                cin.getline(cuil,20);
                cin.ignore();
                archi.MostrarClienteporCUIT(cuit);
                system("pause");

            case 7:
                system("cls");
                archi.ClientequeMasGasto();
                system("pause");

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL..." << endl;
                system("pause");
                break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
                break;
        }
    }while(opcion != 0);
}
void subMenuVendedor(){
 int opcion;
 Vendedor vendedorcito;
 ///ArchivoVendedor obj;
 do
    {
        int legajo=-1;
        system("cls");
        cout<<"BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS"<<endl;
        cout << "===== MENU DE VENDEDORES =====" << endl;
        cout << "1- ALTA " << endl;
        cout << "2- BAJA " << endl;
        cout << "3- MODIFICAR " << endl;
        cout << "4- LISTAR TODOS ACTIVOS/INACTIVOS" << endl;
        cout << "5- LISTAR POR LEGAJO" << endl;
        cout << "6- VENDEDOR QUE MAS RECAUDO" << endl;
        cout << "7- PRODUCTO QUE MAS SE VENDIO POR VENDEDOR" << endl;
        cout <<endl<< "0- VOLVER AL MENU GENERAL. " << endl;
        cout <<endl<< "Ingrese Opcion: " << endl;
        cin >> opcion;
        if (cin.fail())
        {
         cin.clear(); //limpia error de cin
         cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
         opcion=-1;
        }
    switch(opcion)
        {
        case 1:
                system("cls");
                ///vendedorcito.Cargar();
                ///obj.AgregarRegistro(vendedorcito);
                system("pause");
                break;

            case 2:
                system("cls");
                cout<<"Ingresa Legajo a dar de baja: ";
                cin >> legajo;
                ///obj.BajaLogicaVendedor(legajo);
                system("pause");
                break;

            case 3:
                system("cls");
                cout<<"Ingresa id a modificar: ";
                cin >> legajo;
                ///obj.MenuModificarVendedor(legajo);
                system("pause");
                break;

            case 4:
                system("cls");
                ///obj.ListarRegistros();
                system("pause");
                break;

            case 5:
                system("cls");
                cout<<"Ingresa el legajo a buscar: ";
                cin >> legajo;
                ///obj.ListarPorLegajo(legajo);
                system("pause");
                break;

            case 6:
                system("cls");
                ///obj.VendedorqueMasRecaudo();
                system("pause");
                break;

            case 7:
                system("cls");
                cout<<"Ingrese el id del Equipo para buscar su vendedor estrel"<<endl;
                ///obj.VendedorqueMasVendioesteEquipo(id);
                system("pause");
                break;

            case 0:
                cout << "VOLVIENDO AL MENU GENERAL...." << endl;
                break;

            default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
                break;
        }
     }while(opcion != 0);
}
void subMenuVentas(){
 int opcion;
 Fecha anio;
 int anito;
 Venta ventita;
 ///ArchivoVenta obj;
 do
    {
        int id=-1;
        system("cls");
        cout<<"BIENVENIDO AL SISTEMA DE VENTA DE EQUIPOS"<<endl;
        cout << "===== MENU DE VENTAS =====" << endl;
        cout << "1- ALTA " << endl;
        cout << "2- BAJA " << endl;
        cout << "3- MODIFICAR " << endl;
        cout << "4- LISTAR VENTAS ACTIVOS/INACTIVOS" << endl;
        cout << "5- LISTAR VENTAS POR ANIO" << endl;
        cout << "6- RECAUDACION TOTAL POR A�O" << endl;
        cout <<endl<< "0- VOLVER AL MENU GENERAL. " << endl;
        cout <<endl<< "Ingrese Opcion: " << endl;
        cin >> opcion;
        if (cin.fail())
        {
         cin.clear(); //limpia error de cin
         cin.ignore(10000, '\n'); ///esto va ignorar palabras enteras limpiando el buffer
         opcion=-1;
        }
    switch(opcion)
        {
        case 1:
                system("cls");
                ///ventita.Cargar();
                ///obj.AgregarRegistro(ventita);
                system("pause");
                break;

        case 2:
                system("cls");
                cout<<"Ingresa Id de la venta a dar de baja: ";
                cin >> id;
                ///obj.BajaLogicaVendedor(id);
                system("pause");
                break;

        case 3:
                system("cls");
                cout<<"Ingresa id de la venta a modificar: ";
                cin >> id;
                ///obj.MenuModificarVenta(id);
                system("pause");
                break;

        case 4:
                system("cls");
                ///obj.ListarRegistros();
                system("pause");
                break;

        case 5:
                system("cls");
                cout<<"Ingresa el anio para listar las Ventas: ";
                cin >> anito;
                anio.SetAnio(anito);
                ///obj.ListarPorAnio(anio);
                system("pause");
                break;

        case 6:
                system("cls");
                cout<<"Ingresa el anio para listar las Ventas: ";
                cin >> anito;
                anio.SetAnio(anito);
                ///obj.RecaudacionTotalPorAnio(anio);
                system("pause");
                break;

        case 0:
                cout << "VOLVIENDO AL MENU GENERAL...." << endl;
                break;

        default:
                cout << "Opcion Incorrecta, Ingrese un Numero Valido Nuevamente" << endl;
                system("pause");
                break;
        }
    }while(opcion != 0);
}
