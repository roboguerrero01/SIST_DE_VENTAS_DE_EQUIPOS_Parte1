#ifndef VENDEDOR_H_INCLUDED
#define VENDEDOR_H_INCLUDED
#include "fecha.h"
class Vendedor : public Persona{
  private:
    Fecha fechadeingreso;
    float sueldo;
  public:
    Vendedor(){};
    void setIngreso(Fecha);
    void setSueldo();
    void Mostrar();
    void Cargar();
    Fecha getIngreso();
    float getSueldo();
};

#endif // VENDEDOR_H_INCLUDED
