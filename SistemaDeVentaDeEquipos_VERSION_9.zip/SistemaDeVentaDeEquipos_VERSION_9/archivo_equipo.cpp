#include <iostream>
#include <cstring>
#include "archivo_equipo.h"
#include "equipo.h"
using namespace std;

///CONSTRUCTOR
ArchivoEquipo::ArchivoEquipo(const char* n){
        strcpy(nombre, n);
        tamanioRegistro = sizeof(Equipo);
    }

int ArchivoEquipo::AgregarRegistro(Equipo equipo) {
    int escribio;
    FILE *pequipo = fopen(nombre, "ab");

    if (pequipo==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return 0;
    }

    escribio = fwrite(&equipo, tamanioRegistro, 1, pequipo);

    fclose(pequipo);

    if (escribio != 1)
    {
        cout << "Error al escribir el registro." << endl;
        return -1;
    }

    cout << "Registro agregado correctamente." <<endl<< endl;
    return escribio;
}

bool ArchivoEquipo::ListarRegistros() {

    bool flagTodosInactivos = true;
    bool flagTodosActivos = true;
    Equipo obj;
    FILE *p;

    p = fopen(nombre, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    int opc;
    bool salir=false;
    while(!salir)
    {
    cout<<"Quiere Listar:"<<endl<<"0. Inactivos"<<endl<<"1.Activos"<<endl<<"2. Volver"<<endl<<endl ;
    cout<<"Su opcion: "<<endl;
    cin.ignore(10000, '\n');
    cin>>opc;
    if (cin.fail())
    {
        opc=-1;
        cin.clear();
    }
    switch(opc)
    {
      case 0:
             system("pause");
             system("cls");
              while(fread(&obj, tamanioRegistro, 1, p))
              {
                  if (!obj.getEstado())
                  {
                      flagTodosActivos = false;
                      obj.Mostrar();
                  }
              }
              if (flagTodosActivos)
              {
                  cout << "Error: No hay registros inactivos" << endl;
              }
              salir=true;
              break;
      case 1:
            system("pause");
            system("cls");
            while(fread(&obj, tamanioRegistro, 1, p))
            {
                  if (obj.getEstado())
                  {
                      flagTodosInactivos = false;
                      obj.Mostrar();
                  }
            }
            if (flagTodosInactivos)
            {
             cout << "Error: No hay registros activos" << endl;
            }
            salir=true;
            break;
        case 2:
            cout<<"Volviendo"<<endl;
            salir=true;
            break;

        default:
               cout<<"Ingrese una opcion valida"<<endl;
               system("pause");
               system("cls");
               break;
    }
    }
   return 1;
}

void ArchivoEquipo::ListarPorTipo(int _tipo) {
    Equipo equipo;
    FILE *pequipo = fopen(nombre, "rb");

    if (pequipo == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    bool encontrado = false;

    while (fread(&equipo, tamanioRegistro, 1, pequipo) == 1) {
        //  Comparar tipo, evitar eliminados y registros inv�lidos (ID 0)
        if ( equipo.getTipo() == _tipo && equipo.getEstado())
        {
            equipo.Mostrar();
            encontrado = true;
        }
    }

    fclose(pequipo);

    if (!encontrado) {
        cout << "No se encontraron equipos del tipo \"" << _tipo << "\"." << endl;
    }
}

///METODOS

void ArchivoEquipo::ListarPorID(int id){
    Equipo obj;
    int pos;
    FILE *p;

    pos = BuscarPosicionPorId(id);
    if (pos == -1)
    {
        cout<<"registro no existe"<<endl;
        system("pause");
        return;
    }

    p = fopen(nombre, "rb");
    if (p==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    fseek(p, tamanioRegistro*pos, SEEK_CUR);
    fread(&obj, tamanioRegistro, 1, p);


    if(obj.getEstado())
    {
        obj.Mostrar();
    } else
    {
        cout << "Error: Registro inactivo" << endl;
    }

    fclose(p);
}

int ArchivoEquipo::BuscarPosicionPorId(int idBuscado) {
    Equipo equipo;
    FILE *pequipo = fopen(nombre, "rb");
    if (pequipo==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return 0;
    }

    int pos = 0;

    while (fread(&equipo, tamanioRegistro, 1, pequipo) == 1) {
        if (equipo.getIdEquipo() == idBuscado)
        {
            fclose(pequipo);
            return pos;
        }
        pos++;
    }

    fclose(pequipo);
    return -1;
}


bool ArchivoEquipo::MenuModificarEquipo(int id) {
    Equipo obj;

    int _tipo;
    char _marca[30];
    int _stock;
    float _precio;

    int opc;
    bool salir = false;

    FILE *p;

    p = fopen(nombre, "rb+");
    if (p==nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    fseek(p, tamanioRegistro*(id-1), SEEK_CUR);
    fread(&obj, tamanioRegistro, 1, p);


    if (!obj.getEstado()){
        cout << "Error: perfil dado de baja." << '\n';
        return false;
    }

    while(!salir){
        system("cls");
        cout<<"Elija el atributo a modificar: "<<endl<<endl;
        cout<<"1- Tipo"<<endl;
        cout<<"2- Marca"<<endl;
        cout<<"3- Stock"<<endl;
        cout<<"4- Precio"<<endl;

        cout<<"0- Salir"<<endl<<endl;
        cout<<"opcion: ";
        cin>>opc;
        cin.ignore();
        system("cls");
        switch(opc)
        {
        case 1:  //tipo
            cout<<"Ingrese nuevo tipo: ";
            cin >> _tipo;
            obj.setTipo(_tipo);
            break;
        case 2:  //marca
            cout<<"Ingrese nueva marca: ";
            cin.getline(_marca,30);
            obj.setMarca(_marca);
            break;
        case 3:  //stock
            cout<<"Ingrese nuevo stock: ";
            cin >> _stock;
            obj.setStock(_stock);
            break;
        case 4:  //precio
            cout<<"Ingrese nuevo precio: $";
            cin >> _precio;
            obj.setPrecio(_precio);
            break;
        case 0:
            cout<<"saliendo del modificar, muchas gracias"<<endl;
            salir = true;
            break;
        default: cout<<"ingrese opcion correcta"<<endl;
        }
        AgregarRegistroModificado(obj);
        cout<<endl;
        system("pause");
    }
    fclose(p);
    return true;
}

///GETTERS

//autogenerar id al agregar registro
int ArchivoEquipo::obtainNewID() {
    return CantidadRegistros() + 1;
}

int ArchivoEquipo::CantidadRegistros(){
    FILE *pfile;
    pfile=fopen(nombre, "rb");
    int cantidad;
    if(pfile==nullptr)
    {
        return 0;
    }
    fseek(pfile,0,SEEK_END);
    cantidad=ftell(pfile) / sizeof(Equipo);
    fclose(pfile);
    return cantidad;
}

void ArchivoEquipo::AgregarRegistroModificado(Equipo obj){
    FILE *p;

    p = fopen(nombre, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    fseek(p, tamanioRegistro*(obj.getIdEquipo() - 1), SEEK_SET);

    if(fwrite(&obj, tamanioRegistro, 1, p))
    {
        cout<<"Registro Modificado Exitosamente" << endl;
    }
    else
    {
        cout<<"Registro NO Modificado, ALGO SALIO MAL" << endl;
    }


    fclose(p);
}

bool ArchivoEquipo::BajaLogicaEquipo(int id){
    Equipo obj;
    FILE *p;
    p = fopen(nombre, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    fseek(p, tamanioRegistro*(id-1), 0);
    fread(&obj, tamanioRegistro, 1, p);

    if (!obj.getEstado())
    {
        cout << "Error: Equipo ya dado de baja" << '\n';
        return 0;
    }

    obj.setEstado(false);

    AgregarRegistroModificado(obj);

    fclose(p);

    return true;
}

void ArchivoEquipo::RankingdeEquiposMasVendidos(){cout<<"En Desarrollo"<<endl;}
void ArchivoEquipo::EquiposNoVendidos(){cout<<"En Desarrollo"<<endl;}
