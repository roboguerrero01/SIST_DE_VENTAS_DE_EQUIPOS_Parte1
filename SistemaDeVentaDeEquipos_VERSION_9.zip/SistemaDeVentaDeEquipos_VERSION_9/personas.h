#ifndef PERSONAS_H_INCLUDED
#define PERSONAS_H_INCLUDED
#include "fecha.h"

class Persona{
private:
    char Nombres[50];
    char Apellidos[50];
    char Dni[9];
    Fecha FechaNac;
    char Telefono[20];
    char Email[50];
    char Direccion[50];
    bool Estado;// 1-alta / 0-baja

public:
    //CONSTRUCTORES
    Persona();
    Persona(const char* nombres, const char* apellidos, const char* dni, Fecha fechaNac,
            const char* telefono, const char* email, const char* direccion, bool estado);
// SETTERS
    void setNombres(const char* nombres);
    void setApellidos(const char* apellidos);
    void SetFecha(Fecha fechaNac);
    void setTelefono(const char* telefono);
    void setEmail(const char* email);
    void setDireccion(const char* direccion);
    void setEstado(bool estado);
    void setDni(const char* dni);
    // GETTERS
    const char* getNombres();
    const char* getApellidos();
    Fecha GetFechaNac();
    const char* getTelefono();
    const char* getEmail();
    const char* getDireccion();
    bool getEstado();
    const char* getDni();
    //METODOS
    void mostrar();
    void cargar();
};

#endif // PERSONAS_H_INCLUDED
