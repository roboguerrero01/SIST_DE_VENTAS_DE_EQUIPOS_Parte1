#include<iostream>
#include<cstring>
#include"clienteJuridico.h"
#include"archivo_clienteJuridico.h"
using namespace std;

ClienteJuridico::ClienteJuridico(){
    Estado = true;
}

void ClienteJuridico::setIdClienteJuridico(int _id){
    IdClienteJuridico = _id;
}

void ClienteJuridico::setCuit(const char* _cuit){
    strcpy(Cuit, _cuit);
}

void ClienteJuridico::setNombreEmpresa(const char* _nombreEmpresa){
    strcpy(NombreEmpresa, _nombreEmpresa);
}

void ClienteJuridico::setDireccion(const char* _direccion){
    strcpy(Direccion, _direccion);
}

void ClienteJuridico::setEstado(bool _estado){
    Estado = _estado;
}

int ClienteJuridico::getIdClienteJuridico(){ return IdClienteJuridico; }
const char* ClienteJuridico::getCuit(){ return Cuit; }
const char* ClienteJuridico::getNombreEmpresa(){ return NombreEmpresa; }
const char* ClienteJuridico::getDireccion(){ return Direccion; }
bool ClienteJuridico::getEstado(){ return Estado; }

bool ClienteJuridico::cargar(){
    ArchivoClienteJuridico obj;

    cin.ignore();
    cout << "Ingresa Cuit: ";
    cin.getline(Cuit, 12);

    if (obj.cantidadRegistros()){
        if (obj.verificarDuplicado(Cuit)) {
            cout << "Ya existe el usuario." << endl;
            return false;
        }
    }

    cout << "Ingresa Nombre Empresa: ";
    cin.getline(NombreEmpresa, 50);
    cout << "Ingresa Direccion: ";
    cin.getline(Direccion, 100);    IdClienteJuridico = obj.obtainNewID();
    cout << "Su ID Cliente Juridico asignado es: " << IdClienteJuridico << endl;
    cout << "Cliente juridico cargado." << '\n';
    return true;
}


void ClienteJuridico::cargar(const char* _cuit, const char* _nombreEmpresa, const char* _direccion){
    ArchivoClienteJuridico obj;

    cout << "Cargando datos del cliente juridico" << '\n';
    setCuit(_cuit);
    setNombreEmpresa(_nombreEmpresa);
    setDireccion(_direccion);
    IdClienteJuridico = obj.obtainNewID();
    cout << "ID asignado: " << IdClienteJuridico << endl;
}
void ClienteJuridico::mostrar(){
    cout << endl << "--- Cliente Juridico --- " << '\n'<< '\n';
    cout << "ID: " << IdClienteJuridico << '\n';
    cout << "Cuit: " << Cuit << '\n';
    cout << "Nombre: " << NombreEmpresa << '\n';
    cout << "Direccion: " << Direccion << '\n';
    cout << "Estado: "<<Estado<<'\n';
}


