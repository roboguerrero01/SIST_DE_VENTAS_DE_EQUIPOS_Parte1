#ifndef MENUES_H_INCLUDED
#define MENUES_H_INCLUDED


void menuGeneral();
void subMenuEquipo();
void subMenuClientes();
void subMenuVendedor();
void subMenuVentas();
void subMenuClientesJuridicos();
void subMenuClientesFisicos();


#endif // MENUES_H_INCLUDED
