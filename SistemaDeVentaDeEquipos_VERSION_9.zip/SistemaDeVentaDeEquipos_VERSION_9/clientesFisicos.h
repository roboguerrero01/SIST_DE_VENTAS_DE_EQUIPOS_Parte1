#ifndef CLIENTESFISICOS_H_INCLUDED
#define CLIENTESFISICOS_H_INCLUDED

#include "personas.h"

class ClienteFisico : public Persona{
private:
    int IdClienteFisico;
    char Cuil[20];

public:
   ClienteFisico();
    //GETTERS Y SETTERS
    void setIdClienteFisico(int id);
    void setCUIL(const char* valor);

    int getIdClienteFisico();
    const char* getCUIL();

    bool Cargar();
    void Mostrar();
};

#endif // CLIENTESFISICOS_H_INCLUDED

