#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED

class Fecha {
private:
    int dia;
    int mes;
    int anio;
public:

    Fecha();
    Fecha(int _dia, int _mes, int _anio);

    int GetDia();
    int GetMes();
    int GetAnio();

    bool SetDia(int dia);
    bool SetMes(int mes);
    bool SetAnio(int anio);

    void cargar();
    void mostrar();
    void cargarconfechadehoy();


};

#endif // FECHA_H_INCLUDED
