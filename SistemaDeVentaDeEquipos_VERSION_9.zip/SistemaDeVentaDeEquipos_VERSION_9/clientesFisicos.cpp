#include "clientesFisicos.h"
#include "archivo_clienteFisico.h"
#include <iostream>
#include <cstring>

using namespace std;


ClienteFisico::ClienteFisico(){

}
// GETTERS
int ClienteFisico::getIdClienteFisico(){
    return IdClienteFisico;
}

const char* ClienteFisico::getCUIL(){
    return Cuil;
}

// SETTERS

void ClienteFisico::setIdClienteFisico(int id) {
    IdClienteFisico = id;
}

void ClienteFisico::setCUIL(const char* valor) {
    if(strlen(valor) > 9){
        strcpy(Cuil, valor);
    }
}

// M�TODOS
bool ClienteFisico::Cargar() {
    char cuil[20];

    cout << "\n--- Cargando datos del cliente fisico ---" << endl;
    archivoClienteFisico cli;

    cin.ignore();
    cout << "Ingrese su CUIL: ";
    cin >> cuil;

    if (cli.cantidadRegistros()){
        if (cli.verificarDuplicado(cuil)) {
            cout << "Ya existe el usuario." << endl;
            return false;
        }
    }
    strcpy(Cuil,cuil);

    Persona::cargar(); // m�todo heredado
    IdClienteFisico = cli.obtainNewID();
    cout << "Su ID Cliente Fisico asignado es: " << IdClienteFisico << endl;
    return true;
}


void ClienteFisico::Mostrar() {

    cout << "\n--- Datos del cliente ---" << endl;
    cout << "ID: " << IdClienteFisico << endl;
    cout << "CUIT: " << Cuil << endl;

    Persona::mostrar(); // Usamos el m�todo heredado de Persona
}
