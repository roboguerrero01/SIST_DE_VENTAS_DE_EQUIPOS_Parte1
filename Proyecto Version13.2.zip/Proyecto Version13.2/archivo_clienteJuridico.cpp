#include<iostream>
#include<cstring>
#include"archivo_clienteJuridico.h"
using namespace std;



ArchivoClienteJuridico::ArchivoClienteJuridico(){
    strcpy(nombreRuta, "archivoClienteJuridico.dat");
    tamanioRegistro = sizeof(ClienteJuridico);
}

bool ArchivoClienteJuridico::MostrarClientePorID(int id){
    ClienteJuridico obj;

    if (!BuscarClientePorID(id, obj))
    {
        cout<<"No hay registros cargados/guardados"<<endl;
        return false;
    }

    obj.Mostrar();
    return true;
}

void ArchivoClienteJuridico::MenuModificarClienteJuridico(int id){
    ClienteJuridico obj;
    char _cuit[12];
    char _nombreEmpresa[50];
    char _direccion[100];

    bool salir = false;

    if (!BuscarClientePorID(id, obj))
    {
        cout<<"No hay registros cargados/guardados"<<endl;
        return;
    }

    if (!obj.getEstado())
    {
        salir = true;
        cout << "Error: perfil dado de baja." << '\n';
    }

    while(!salir)
    {
        system ("cls");
        int opc;
        cout << "Perfil de " << obj.getNombreEmpresa() << '\n';
        cout<<"Elija el atributo a modificar: "<<endl<<endl;
        cout<<"1- Cuit"<<endl;
        cout<<"2- Nombre Empresa"<<endl;
        cout<<"3- Direccion"<<endl;

        cout<<"0- Salir"<<endl<<endl;
        cout<<"opcion: ";
        cin>>opc;
        cin.ignore();
        switch(opc)
        {
        case 1:  //Cuit
            cout << "Ingrese el cuit: ";
            cin.getline(_cuit, 30);
            obj.setCuit(_cuit);
            break;
        case 2:  //Nombre empresa
            cout << "Ingrese el cuit: ";
            cin.getline(_nombreEmpresa,30);
            obj.setNombreEmpresa(_nombreEmpresa);
            break;
        case 3:  //Direccion
            cin.getline(_direccion,9);
            obj.setDireccion(_direccion);
            break;
        case 0:
            cout<<"saliendo del modificar, muchas gracias"<<endl;
            salir = true;
            break;
        default: cout<<"ingrese opcion correcta"<<endl;
        }
        AgregarRegistroModificado(obj);
    system("cls");
    }
    return;
}

bool ArchivoClienteJuridico::BajaLogica(int id){
    ClienteJuridico obj;

    if (!BuscarClientePorID(id, obj))
    {
        cout<<"No hay registros cargados/guardados"<<endl;
        return false;
    }

    obj.setEstado(0);

    AgregarRegistroModificado(obj);

    return true;
}

bool ArchivoClienteJuridico::VerificarDuplicado(const char* _cuit){
    ClienteJuridico obj;

    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(!strcmp(obj.getCuit(), _cuit))
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}

bool ArchivoClienteJuridico::BuscarClientePorID(int id, ClienteJuridico& cli){
    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&cli, tamanioRegistro, 1, p))
    {
        if(cli.getIdClienteJuridico() == id)
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}

int ArchivoClienteJuridico::ObtainNewID(){
    ArchivoClienteFisico obj;
    return CantidadRegistros() + obj.CantidadRegistros() + 1;
}

int ArchivoClienteJuridico::CantidadRegistros(){
    FILE *pfile;
    pfile=fopen(nombreRuta, "rb");
    int cantidad;
    if(pfile==nullptr)
    {
        return 0;
    }
    fseek(pfile,0,SEEK_END);
    cantidad=ftell(pfile) / tamanioRegistro;
    fclose(pfile);
    return cantidad;
}

bool ArchivoClienteJuridico::ListarRegistros(){
        if (!CantidadRegistros())
    {
        return 0;
    }

    bool flagTodosInactivos = true;
    bool flagTodosActivos = true;
    ClienteJuridico obj;
    FILE *p;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        return false;
    }

    int opc;
    bool salir=false;
    while(!salir)
    {
    cout<<"Quiere Listar:"<<endl<<"0. Inactivos"<<endl<<"1.Activos"<<endl<<"2. Volver"<<endl<<endl ;
    cout<<"Su opcion: "<<endl;
    cin.ignore(10000, '\n');
    cin>>opc;
    if (cin.fail())
    {
        opc=-1;
        cin.clear();
    }
    switch(opc)
    {
      case 0:
             system("pause");
             system("cls");
              while(fread(&obj, tamanioRegistro, 1, p))
              {
                  if (!obj.getEstado())
                  {
                      flagTodosActivos = false;
                      obj.Mostrar();
                  }
              }
              if (flagTodosActivos)
              {
                  cout << "Error: No hay registros inactivos" << endl;
              }
              salir=true;
              break;
      case 1:
            system("pause");
            system("cls");
            while(fread(&obj, tamanioRegistro, 1, p))
            {
                  if (obj.getEstado())
                  {
                      flagTodosInactivos = false;
                      obj.Mostrar();
                  }
            }
            if (flagTodosInactivos)
            {
             cout << "Error: No hay registros activos" << endl;
            }
            salir=true;
            break;
        case 2:
            cout<<"Volviendo"<<endl;
            salir=true;
            break;

        default:
               cout<<"Ingrese una opcion valida"<<endl;
               system("pause");
               system("cls");
               break;
    }
    }
   return 1;
}

void ArchivoClienteJuridico::AgregarRegistro(ClienteJuridico& cli){
    FILE *p;
    int escribio;

    p = fopen(nombreRuta, "ab");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    escribio = fwrite(&cli, tamanioRegistro, 1, p);

    fclose(p);

    if (escribio != 1)
    {
        cout << "Error al escribir el registro." << endl;
        return;
    }
}

 void ArchivoClienteJuridico::AgregarRegistroModificado(ClienteJuridico& cli){
    ClienteJuridico obj;
    FILE *p;

    p = fopen(nombreRuta, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(cli.getIdClienteJuridico() == obj.getIdClienteJuridico())
        {
            break;
        }
    }

    fseek(p, -tamanioRegistro, SEEK_CUR);

    if(fwrite(&cli, tamanioRegistro, 1, p))
    {
        cout<<"Registro Modificado Exitosamente" << endl;
    }
    else
    {
        cout<<"Registro NO Modificado, ALGO SALIO MAL" << endl;
    }


    fclose(p);
}

void ArchivoClienteJuridico::MostrarClientePorCUIT(const char* cuit){
   ClienteJuridico obj;
   bool bandera=0;
    FILE* p;
    p=fopen(nombreRuta, "rb");
    if(p==nullptr)
    {
        cout<<"Error de Apertura";
        return;
    }
    while(fread(&obj, tamanioRegistro, 1, p))
    {
     if (strcmp(cuit, obj.getCuit())==0)
     {
      bandera=true;
      obj.Mostrar();
     }
    }
    if(!bandera){cout<<"El CUIT no coincide"<<endl;}
    return;
}

void ArchivoClienteJuridico::ClientequeMasGasto(){cout<<"A Desarrollar"<<endl;}
