#include "archivo_clienteFisico.h"
# include<iostream>
# include<cstring>
using namespace std;

ArchivoClienteFisico::ArchivoClienteFisico(){
    strcpy(nombreRuta, "archivoClienteFisico.dat");
    tamanioRegistro = sizeof(ClienteFisico);
}

void ArchivoClienteFisico::AgregarRegistro(ClienteFisico& cli){
    FILE *p;
    int escribio;

    p = fopen(nombreRuta, "ab");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    escribio = fwrite(&cli, tamanioRegistro, 1, p);

    fclose(p);

    if (escribio != 1)
    {
        cout << "Error al escribir el registro." << endl;
    }
}

bool ArchivoClienteFisico::ListarRegistros(){
    if (!CantidadRegistros())
    {
        return 0;
    }

    bool flagTodosInactivos = true;
    bool flagTodosActivos = true;
    ClienteFisico obj;
    FILE *p;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        return false;
    }

    int opc;
    bool salir=false;
    while(!salir)
    {
    cout<<"Quiere Listar:"<<endl<<"0. Inactivos"<<endl<<"1.Activos"<<endl<<"2. Volver"<<endl<<endl ;
    cout<<"Su opcion: "<<endl;
    cin.ignore(10000, '\n');
    cin>>opc;
    if (cin.fail())
    {
        opc=-1;
        cin.clear();
    }
    switch(opc)
    {
      case 0:
             system("pause");
             system("cls");
              while(fread(&obj, tamanioRegistro, 1, p))
              {
                  if (!obj.getEstado())
                  {
                      flagTodosActivos = false;
                      obj.Mostrar();
                  }
              }
              if (flagTodosActivos)
              {
                  cout << "Error: No hay registros inactivos" << endl;
              }
              salir=true;
              break;
      case 1:
            system("pause");
            system("cls");
            while(fread(&obj, tamanioRegistro, 1, p))
            {
                  if (obj.getEstado())
                  {
                      flagTodosInactivos = false;
                      obj.Mostrar();
                  }
            }
            if (flagTodosInactivos)
            {
             cout << "Error: No hay registros activos" << endl;
            }
            salir=true;
            break;
        case 2:
            cout<<"Volviendo"<<endl;
            salir=true;
            break;

        default:
               cout<<"Ingrese una opcion valida"<<endl;
               system("pause");
               system("cls");
               break;
    }
    }
   return 1;
}

bool ArchivoClienteFisico::VerificarDuplicado(const char* _cuil){
    ClienteFisico obj;

    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(!strcmp(obj.getCUIL(), _cuil))
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}

bool ArchivoClienteFisico::BuscarClientePorID(int id, ClienteFisico& cli){
    FILE *p;
    bool existe = false;

    p = fopen(nombreRuta, "rb");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return false;
    }

    while(fread(&cli, tamanioRegistro, 1, p))
    {
        if(cli.getIdClienteFisico() == id)
        {
            existe = true;
            break;
        }
    }

    fclose(p);

    return existe;
}

int ArchivoClienteFisico::CantidadRegistros(){
    FILE *pfile;
    pfile=fopen(nombreRuta, "rb");
    int cantidad;
    if(pfile==nullptr)
    {
        return 0;
    }
    fseek(pfile,0,SEEK_END);
    cantidad=ftell(pfile) / tamanioRegistro;
    fclose(pfile);
    return cantidad;
 }

int ArchivoClienteFisico::ObtainNewID(){
    ArchivoClienteJuridico obj;
    return CantidadRegistros() + obj.CantidadRegistros() + 1;
}

bool ArchivoClienteFisico::BajaLogica(int id){
    ClienteFisico obj;

    if (!BuscarClientePorID(id, obj))
        {
            cout<<"No hay registros cargados/guardados"<<endl;
            return false;
        }
    obj.setEstado(0);
    AgregarRegistroModificado(obj);
    return true;
}

void ArchivoClienteFisico::MenuModificarClienteFisico(int id){
    ClienteFisico obj;
    char _nombres[30];
    char _apellidos[30];
    char _dni[9];
    char _telefono[20];
    char _cuil[20];
    char _correo[50];
    char _direccion[50];
    Fecha _nacimiento;
    bool salir = false;

    if (!BuscarClientePorID(id, obj))
        {
            cout<<"No hay registros cargados/guardados"<<endl;
            return;
        }

    if (!obj.getEstado())
    {
        cout << "Error: perfil dado de baja." << '\n';
        salir = true;
    }

    while(!salir)
    {
        system ("cls");
        int opc;
        cout << "Perfil de " << obj.getNombres() << " " << obj.getApellidos() << '\n';
        cout<<"Elija el atributo a modificar: "<<endl<<endl;
        cout<<"1- Nombre"<<endl;
        cout<<"2- Apellido"<<endl;
        cout<<"3- Dni"<<endl;
        cout<<"4- Nacimiento"<<endl;
        cout<<"5- Telefono"<<endl;
        cout<<"6- Correo"<<endl;
        cout<<"7- Direccion"<<endl;
        cout<<"8- Cuil"<<endl<<endl;

        cout<<"0- Salir"<<endl<<endl;
        cout<<"opcion: ";
        cin>>opc;
        cin.ignore();
        switch(opc)
        {
        case 1:  //nombre
            cout<<"Ingrese Nuevo Nombre: ";
            cin.getline(_nombres, 30);
            obj.setNombres(_nombres);
            break;
        case 2:  //apellido
            cout<<"Ingrese Nuevo Apellido: ";
            cin.getline(_apellidos,30);
            obj.setApellidos(_apellidos);
            break;
        case 3:  //dni
            cout<<"Ingrese Nuevo DNI: ";
            cin.getline(_dni,9);
            obj.setDni(_dni);
            break;
        case 4:  //fecha
            cout<<"Ingrese Nueva Fecha de Nacimiento: ";
            _nacimiento.Cargar();
            obj.SetFecha(_nacimiento);
            break;
        case 5:  //telefono
            cout<<"Ingrese Nuevo Telefono:";
            cin.getline(_telefono,20);
            obj.setTelefono(_telefono);
            break;
        case 6:  //email
            cout<<"Ingrese Nuevo EMAIL:";
            cin.getline(_correo,50);
            obj.setEmail(_correo);
            break;
        case 7:  //direccion
            cout<<"Ingrese Nueva Direccion:";
            cin.getline(_direccion, 50);
            obj.setDireccion(_direccion);
            break;
        case 8:  //cuil
            cout<<"Ingrese Nuevo CUIL:";
            cin.getline(_cuil,20);
            obj.setCUIL(_cuil);
            break;
        case 0:
            cout<<"saliendo del modificar, muchas gracias"<<endl;
            salir = true;
            return;
        default: cout<<"ingrese opcion correcta"<<endl;
        }
        AgregarRegistroModificado(obj);
        system("pause");
    }

    return;
}

void ArchivoClienteFisico::AgregarRegistroModificado(ClienteFisico& cli){
    ClienteFisico obj;
    FILE *p;

    p = fopen(nombreRuta, "rb+");
    if (p == nullptr)
    {
        cout<<"error de apertura"<<endl;
        system("pause");
        return;
    }

    while(fread(&obj, tamanioRegistro, 1, p))
    {
        if(cli.getIdClienteFisico() == obj.getIdClienteFisico())
        {
            break;
        }
    }

    fseek(p, -tamanioRegistro, SEEK_CUR);

    if(fwrite(&cli, tamanioRegistro, 1, p))
    {
        cout<<"Registro Modificado Exitosamente" << endl;
    }
    else
    {
        cout<<"Registro NO Modificado, ALGO SALIO MAL" << endl;
    }


    fclose(p);
}

bool ArchivoClienteFisico::MostrarClientePorID(int id){
    ClienteFisico obj;
    if (!BuscarClientePorID(id, obj))
    {
        cout<<"No hay registros cargados/guardados con ese ID"<<endl;
        return false;
    }
    obj.Mostrar();
    return true;
}

void ArchivoClienteFisico::MostrarClientePorCUIL(const char* cuil){
   ClienteFisico obj;
   bool bandera=0;
    FILE* p;
    p=fopen(nombreRuta, "rb");
    if(p==nullptr)
    {
        cout<<"Error de Apertura";
        return;
    }
    while(fread(&obj, tamanioRegistro, 1, p))
    {
     if (strcmp(cuil, obj.getCUIL())==0)
     {
      bandera=true;
      obj.Mostrar();
     }
    }
    if(!bandera){cout<<"El CUIL no coincide"<<endl;}
    return;
}

void ArchivoClienteFisico::ClientequeMasGasto(){cout<<"A Desarrollar"<<endl;}
