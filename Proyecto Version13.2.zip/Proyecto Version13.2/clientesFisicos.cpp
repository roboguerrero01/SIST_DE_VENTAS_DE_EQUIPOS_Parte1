#include "clientesFisicos.h"
#include <iostream>
#include <cstring>

using namespace std;


ClienteFisico::ClienteFisico(){

}
// GETTERS
int ClienteFisico::getIdClienteFisico(){
    return IdClienteFisico;
}

const char* ClienteFisico::getCUIL(){
    return Cuil;
}

// SETTERS

void ClienteFisico::setIdClienteFisico(int id) {
    IdClienteFisico = id;
}

void ClienteFisico::setCUIL(const char* valor) {
    if(strlen(valor) > 9){
        strcpy(Cuil, valor);
    }
}

// M�TODOS
bool ClienteFisico::Cargar(const char* cuil, int id) {
    strcpy(Cuil,cuil);

    Persona::Cargar(); // m�todo heredado
    IdClienteFisico = id;
    cout << "Su ID Cliente Fisico asignado es: " << IdClienteFisico << endl;
    return true;
}


void ClienteFisico::Mostrar() {

    cout << "\n--- Datos del cliente ---" << endl;
    cout << "ID: " << IdClienteFisico << endl;
    cout << "CUIT: " << Cuil << endl;

    Persona::Mostrar(); // Usamos el m�todo heredado de Persona
}
